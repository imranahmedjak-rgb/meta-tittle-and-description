# Dev Global Jobs V37 Final Permanent Brand + Google Jobs Schema Safe Release

## V37 correction for the exact V35 rollback

V35 reached live step 12 and rolled back on job `/jobs/detail/130400150` because the deployment audit treated every non-empty database `job.url` as if it must also appear as `applicationContact.url`. That was stricter than the reviewed runtime itself. The runtime intentionally emits `applicationContact.url` only when the stored value is an absolute HTTP(S) URL. Relative or non-HTTP stored values therefore produced no `applicationContact.url`, and the audit created a false failure.

V37 fixes the validator, not the reviewed JobPosting runtime. It now requires `applicationContact.url` only for an absolute HTTP(S) source URL, requires `applicationContact.email` only for a syntactically valid application email, validates any emitted contact URL, and does not falsely fail on relative/non-HTTP stored apply values. An offline regression reproducing the V35 failure class plus a negative control is part of `preflight-final.sh`.

The reviewed server JobPosting runtime, browser Google Jobs companion, source schema builder, factual location/date/salary guards, employer sameAs rules and sitemap architecture are preserved in V37. The verifier alone is strengthened to test the correct conditional `validThrough` rule and avoid the observed false stop.

V35 was the correction for the exact live SAFE STOP observed during V34 step 11. The V34 reviewed runtime was valid, but its Google Jobs verifier scanned every historical `index-*.js` file in `dist/public/assets`. A stale inactive bundle could therefore trigger `legacy React JobPosting generator remains` even though the active SPA bundle referenced by `index.html` was already patched.

The inherited V35 layer changes the verification target, not the job schema: it validates exactly the one active SPA bundle referenced by `dist/public/index.html`. Stale unreferenced bundles are ignored; an active bundle containing the legacy generator is still rejected. The reviewed server `JobPosting` runtime, browser companion, source schema builder, applicationContact behavior, factual location/date/salary guards and sitemap logic are unchanged.

## What V35 fixes

Two separate safety stops were seen before V35:

1. The earlier runtime brand gate could be tripped by a legacy category-title formula in a hashed SPA bundle. The verifier now follows the single active `index-*.js` bundle referenced by `dist/public/index.html`, while historical inactive bundles do not create false failures.
2. A later outer preflight duplicated one exact Sponsored title string instead of reading the authoritative brand contract. That caused `Sponsored Jobs locked title missing` even though the route existed. V35 validation is contract-driven: `/jobs/sponsored` must be a dedicated Sponsored Jobs route, must not be Featured, and must remain distinct from `/jobs/all` and `/jobs/international` without duplicating a full title string in the launcher.

V35 also synchronizes the active SPA category metadata fallback with the same brand contract. The final Sponsored title is:

`Sponsored Jobs | Employer-Promoted Opportunities | Dev Global Jobs`

Featured remains a placement/status only, with no separate Featured SEO route and discovery destination `/jobs/all`.

## Permanent brand architecture

- Dev Global Jobs = International Careers Platform.
- One authoritative contract: `brand-lock/brand-contract.json`.
- Server-side metadata resolver reads the contract at runtime.
- Public `brand-contract.json`, preload JS, SPA head guard, Open Graph/Twitter metadata and source/build verification are tied to the same contract.
- All Jobs, International Jobs and Sponsored Jobs are separate search intents.
- UN and NGO remain specialist sections, not the overall brand identity.
- 45 explicit public static routes, 3 private routes, 17 countries, 50 cities and 32 known article records are covered by the contract.
- Unknown routes default to noindex until deliberately added.
- Future builds run synchronization/patch/verification gates and fail instead of silently shipping inconsistent brand metadata.

## Google Jobs schema safety

`JobPosting` is limited to eligible individual `/jobs/detail/{id}` pages. It requires factual job data and a usable application path. Physical roles require a factual `addressCountry`. Fully remote roles require `TELECOMMUTE` plus a factual applicant country. `validThrough` is only emitted when a real closing date exists. Salary markup is only emitted from explicit employer-posted salary data with recognized currency, numeric amount/range and pay period. Expired or materially incomplete jobs do not emit active JobPosting markup.

`applicationContact` is preserved as a supplementary Schema.org `JobPosting` property when a real application URL or valid application email exists. It is not treated as a Google-required property.

`hiringOrganization.sameAs` remains conditional and conservative: it is emitted only for employer-posted jobs when the stored destination can be safely treated as an employer-owned domain; imported job-board, ATS, form and unrelated domains are not copied into employer identity.

Google controls crawling, policy review, indexing and final appearance. This release is designed for factual eligibility and technical consistency; it cannot guarantee inclusion or ranking.

## Deployment safety

`deploy-final-safe.sh` recognizes only reviewed live baselines, backs up every touched file, installs the source lock idempotently, atomically installs the reviewed runtime/assets, reloads only the main `devglobaljobs` PM2 app, audits metadata and noindex rules, validates live eligible JobPosting samples, checks job sitemap shards, and rolls back automatically on a post-mutation failure.

It does not run `npm build`, `drizzle-kit push`, a database migration, or a full-site replacement.

Before upload/deployment, run:

```bash
./preflight-final.sh
```

The final ZIP SHA-256 published alongside the ZIP must be used by the GitHub launcher. A GitHub filename suffix such as `(1).zip` must never bypass checksum matching.

## V37 correction for the observed `validThrough` false stop
The reviewed JobPosting runtime already implements `validThrough` correctly and conditionally. V37 removes the erroneous idea that every sample JobPosting must contain the field. The package and live gates now verify: factual closing date => matching `validThrough`; unknown closing date => no invented `validThrough`; expired closing date => no active JobPosting. Do not use the old V36 external launcher/checker.
