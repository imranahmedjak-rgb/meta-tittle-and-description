import fs from "fs";import path from "path";
const root=process.cwd(),dist=process.argv.includes("--dist");
function die(s){console.error("DGJ GOOGLE JOBS V27 VERIFY FAIL:",s);process.exit(1)}
function read(p){if(!fs.existsSync(p))die(`missing ${p}`);return fs.readFileSync(p,"utf8")}
const server=read(path.join(root,"server","brandSeo.ts"));
for(const need of ["DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27","buildGoogleJobPostingSchema","datePosted","hiringOrganization","jobLocationType","applicantLocationRequirements","addressCountry","directApply","dgjJobPostalAddress","dgjJobCountryDisplayName","dgjSafeJsonLd","dgjEmployerSameAs","dgjJobHasApplyPath","dgjJobApplicationContact","applicationContact","sameAs","\"SERBIA\":\"RS\"","\"BULGARIA\":\"BG\"","\"CHINA\":\"CN\"","\"SLOVAKIA\":\"SK\""])if(!server.includes(need))die(`server schema missing ${need}`);
for(const bad of ['"name":"Worldwide"','Date.now() + 30','new Date()).toISOString().split("T")[0]','else if(/\\$/.test(s))currency='])if(server.includes(bad))die(`unsafe schema pattern ${bad}`);

if(!server.includes('dgjSafeJsonLd(jobSchema)'))die('safe JSON-LD serialization missing');
if(!server.includes('if(!description||!datePosted)return null'))die('required date/description guard missing');
if(!server.includes('if(validThrough && new Date(validThrough+"T23:59:59Z").getTime()<Date.now())return null'))die('expired guard missing');
if(!server.includes('if(!job.isEmployerPosted||!job.salary)return null'))die('salary provenance guard missing');
if(!server.includes('if(isRemote){if(!country)return null'))die('remote applicant-country guard missing');
if(!server.includes('else {if(!country)return null'))die('physical addressCountry guard missing');
const client=read(path.join(root,"client","public","dgj-google-jobs-v27.js"));
for(const need of ['DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27','if(!d||!posted)return null','function hasApply(j)','function applicationContact(j)','applicationContact','function sameAs(j)','jp.hiringOrganization.sameAs=sa','applicantLocationRequirements','addressCountry','function countryName(','\'SERBIA\':\'RS\'','\'BULGARIA\':\'BG\'','\'CHINA\':\'CN\'','\'SLOVAKIA\':\'SK\'',"'name':countryName(c)"])if(!client.includes(need))die(`client companion missing ${need}`);
if(client.includes("name:'Worldwide'")||client.includes("else if(/\\$/.test(s))"))die('client contains fake Worldwide or guessed dollar currency');

if(!server.includes('if(!dgjJobHasApplyPath(job))return null'))die('server apply-path guard missing');
if(!client.includes('if(!hasApply(j))return null'))die('client apply-path guard missing');
if(!server.includes('if(!job || !job.isEmployerPosted || !job.url) return null'))die('server sameAs must be factual employer-posted only');
if(!server.includes('if(employerSameAs)hiringOrganization.sameAs=employerSameAs'))die('server conditional hiringOrganization.sameAs missing');
if(!client.includes("if(!j||!j.isEmployerPosted||!j.url)return null"))die('client sameAs provenance guard missing');
// Execute the browser companion in an isolated VM and test conservative sameAs behavior plus core JobPosting fields.
const vm = await import('node:vm');
const fakeDoc={head:{appendChild(){}},querySelector(){return null},querySelectorAll(){return []},createElement(){return {setAttribute(){},remove(){}}},getElementById(){return null}};
const ctx={window:{},document:fakeDoc,URL,Intl,Date,JSON,console}; vm.createContext(ctx); vm.runInContext(client,ctx);
const B=ctx.window.DGJGoogleJobsV27&&ctx.window.DGJGoogleJobsV27.build;if(typeof B!=='function')die('client schema builder unavailable');
const base={id:123,title:'Senior Engineer',organization:'Acme Corporation',description:'Responsibilities and qualifications for this role.\n\nThree years of relevant experience required.',postedAt:'2026-08-01T12:00:00Z',country:'US',location:'New York, US',jobType:'Full-time',isEmployerPosted:true,url:'https://careers.acme.com/jobs/123'};
const ok=B(base);if(!ok)die('client schema unit test produced no JobPosting');
if(ok.hiringOrganization?.sameAs!=='https://careers.acme.com')die('verified employer sameAs unit test failed');
if(ok.applicationContact?.url!=='https://careers.acme.com/jobs/123')die('applicationContact URL preservation unit test failed');
if(ok.datePosted!=='2026-08-01'||ok.jobLocation?.address?.addressCountry!=='US'||ok.directApply!==false)die('core factual JobPosting unit test failed');
const imported=B({...base,id:124,isEmployerPosted:false});if(imported?.hiringOrganization?.sameAs)die('imported source URL must not become employer sameAs');
const form=B({...base,id:125,url:'https://forms.gle/example'});if(form?.hiringOrganization?.sameAs)die('form/third-party URL must not become employer sameAs');
const unrelated=B({...base,id:126,url:'https://example.org/apply'});if(unrelated?.hiringOrganization?.sameAs)die('unrelated domain must not become employer sameAs');
const emailOnly=B({...base,id:127,url:null,applyEmail:'apply@acme.example'});if(emailOnly?.applicationContact?.email!=='apply@acme.example')die('applicationContact email unit test failed');
const noApply=B({...base,id:128,isEmployerPosted:false,url:null,applyEmail:null});if(noApply)die('job without an application path must not emit JobPosting');
const idx=read(path.join(root,"client","index.html")); if(!idx.includes('/dgj-google-jobs-v27.js'))die('source job schema loader missing'); if(idx.includes('dgj-job-seo-engine'))die('legacy inline job SEO engine remains');
if(dist){const di=read(path.join(root,'dist','public','index.html'));if(!di.includes('/dgj-google-jobs-v27.js')||di.includes('dgj-job-seo-engine'))die('built index schema lock invalid');const ds=read(path.join(root,'dist','index.cjs'));if(!ds.includes('DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27')||!ds.includes('id="dgj-jobposting-v27"'))die('built server schema marker missing');const assets=path.join(root,'dist','public','assets');const apps=fs.readdirSync(assets).filter(f=>/^index-.*\.js$/.test(f)).map(f=>read(path.join(assets,f)));if(!apps.some(s=>s.includes('DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27')))die('built SPA patch marker missing');if(apps.some(s=>s.includes('document.getElementById("job-jsonld")')))die('legacy React JobPosting generator remains');}
console.log(`PASS: DGJ Google Jobs schema lock V27 verified${dist?' including built runtime':''}.`);
