#!/usr/bin/env bash
set -Eeuo pipefail
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SELF_DIR"

die(){ echo "V33 PREFLIGHT FAIL: $*" >&2; exit 1; }

sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || die "payload manifest mismatch"
node -c dist/index.cjs >/dev/null || die "dist/index.cjs syntax"
for f in dist/public/dgj-brand-contract-v27.js dist/public/dgj-brand-lock.js dist/public/dgj-google-jobs-v27.js source/script/*.mjs; do node --check "$f" >/dev/null || die "Node syntax: $f"; done
bash -n deploy-final-safe.sh || die "deploy Bash syntax"
bash -n preflight-final.sh || die "preflight Bash syntax"
PYTHONPYCACHEPREFIX=/tmp/dgj-v33-preflight-pycache python3 -m py_compile source/script/apply-brand-lock-source.py || die "Python installer syntax"

python3 - brand-lock/brand-contract.json <<'PYCHK'
import json,re,sys,hashlib
c=json.load(open(sys.argv[1],encoding='utf-8'))
assert c['lockId']=='DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27'
assert c['version']=='27.0.0'
assert len(c['staticRoutes'])==45
assert len(c['privateRoutes'])==3
assert len(c['countries'])==17
assert len(c['cities'])==50
assert len(c['blogArticles'])==32
s=c['staticRoutes']['/jobs/sponsored'];a=c['staticRoutes']['/jobs/all'];i=c['staticRoutes']['/jobs/international']
assert s['title'].startswith('Sponsored Jobs') and 'Featured' not in s['title']
assert c['brand']['sponsoredRule']['path']=='/jobs/sponsored' and c['brand']['sponsoredRule']['isDedicatedRoute'] is True
assert c['brand']['featuredRule']['hasSeparateSeoRoute'] is False
assert c['brand']['featuredRule']['discoveryDestination']=='/jobs/all'
assert len({a['title'],i['title'],s['title']})==3
seen={}
for r,m in {**c['staticRoutes'],**c['privateRoutes']}.items():
    assert m.get('title') and m.get('description'),r
    assert not re.search(r'\b(Jobs|Careers|Opportunities)\s+\1\b',m['title'],re.I),(r,m['title'])
    assert '—' not in m['title'] and '—' not in m['description'],r
    if not str(m.get('robots',c['indexRobots'])).startswith('noindex'):
        assert m['title'] not in seen,(r,seen.get(m['title']),m['title']);seen[m['title']]=r
print('PASS: contract semantics, coverage and route distinctions')
PYCHK

python3 - <<'PYCHK'
import hashlib,json,re
from pathlib import Path
D=Path('.')
raw=(D/'brand-lock/brand-contract.json').read_bytes(); c=json.loads(raw); sha=hashlib.sha256(raw).hexdigest()
for p in [D/'source/client/public/brand-contract.json',D/'dist/public/brand-contract.json']:
    assert hashlib.sha256(p.read_bytes()).hexdigest()==sha,p
for p in [D/'source/client/public/dgj-brand-contract-v27.js',D/'dist/public/dgj-brand-contract-v27.js']:
    s=p.read_text();m=re.search(r'window\.DGJ_BRAND_CONTRACT_V27=(.*);\s*$',s,re.S);assert m,p;assert json.loads(m.group(1))==c,p
idx=(D/'dist/public/index.html').read_text()
srcs=re.findall(r'<script[^>]+src=["\']([^"\']*/assets/index-[^"\']+\.js)["\'][^>]*>',idx,re.I)
assert len(srcs)==1,srcs
spa=(D/'dist/public'/srcs[0].lstrip('/')).read_text()
for route,m in c['staticRoutes'].items():
    if re.fullmatch(r'/jobs/(all|un|ngo|remote|international|technology|healthcare|business|education|engineering|creative|sales|gig|youth|sponsored)',route):
        assert m['title'] in spa,(route,'title');assert m['description'] in spa,(route,'description')
for bad in ['Jobs Jobs |','Jobs | International Careers - Dev Global Jobs','Sponsored Jobs | Employer-Promoted Roles | Dev Global Jobs']:
    assert bad not in spa,bad
assert 'JobPosting' not in idx
print('PASS: authoritative/public/preload/active-SPA synchronization')
PYCHK

# Exact preservation proof for reviewed Google Jobs implementation from V32.
[ "$(sha256sum dist/index.cjs | awk '{print $1}')" = "53b9ad828c2c3355498f58e227310ef7632ee7da99a1902c41db7c1c05663564" ] || die "server JobPosting runtime changed"
[ "$(sha256sum dist/public/dgj-google-jobs-v27.js | awk '{print $1}')" = "5a8aa9d3b0966b2d2021aee53dc194071b7bf1730e50a150c750f2e56c7c74d6" ] || die "Google Jobs companion changed"
[ "$(sha256sum source/server/brandSeo.ts | awk '{print $1}')" = "21b6001d127fdc1f9a82bca9eb9d06719eb502e2018df2136d73ffb6727e944e" ] || die "source JobPosting server changed"
[ "$(sha256sum source/script/verify-google-jobs-schema.mjs | awk '{print $1}')" = "f7d0a22a5d3366516097d07b53d711d57ea62d253ef340529607c08fd7d2e5d6" ] || die "Google Jobs verifier changed"
[ "$(sha256sum source/script/patch-job-schema-client.mjs | awk '{print $1}')" = "81f6a01fa502a3229ea5399f46f8098a0a832da8178e351d4a0ad0979b7c1d94" ] || die "Google Jobs client patcher changed"

grep -Fq 'DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27' dist/index.cjs || die "schema lock marker missing"
grep -Fq 'if(!description||!datePosted)return null' dist/index.cjs || die "required description/date guard missing"
grep -Fq 'if(!dgjJobHasApplyPath(job))return null' dist/index.cjs || die "application-path guard missing"
grep -Fq 'schema.jobLocationType="TELECOMMUTE"' dist/index.cjs || die "TELECOMMUTE guard missing"
grep -Fq 'applicantLocationRequirements' dist/index.cjs || die "remote applicant location missing"
grep -Fq 'addressCountry' dist/index.cjs || die "physical addressCountry missing"
grep -Fq 'if(!job.isEmployerPosted||!job.salary)return null' dist/index.cjs || die "salary provenance guard missing"

# Compile every embedded Python heredoc in the deploy script; catches errors Bash syntax cannot see.
python3 - <<'PYCHK'
from pathlib import Path
import re,subprocess,tempfile
lines=Path('deploy-final-safe.sh').read_text().splitlines();i=0;n=0
while i<len(lines):
    m=re.search(r"<<'([A-Z0-9_]+)'",lines[i])
    if not m:i+=1;continue
    token=m.group(1);j=i+1
    while j<len(lines) and lines[j].strip()!=token:j+=1
    assert j<len(lines),f'unclosed heredoc {token}'
    if 'python3' in lines[i]:
        n+=1
        with tempfile.NamedTemporaryFile('w',suffix='.py',delete=False) as f:f.write('\n'.join(lines[i+1:j])+'\n');name=f.name
        r=subprocess.run(['python3','-m','py_compile',name],capture_output=True,text=True)
        assert r.returncode==0,(token,r.stderr)
    i=j+1
assert n>=4,n
print('PASS: embedded deploy Python heredocs compile:',n)
PYCHK

if find . -type f \( -name '*.pyc' -o -path '*/__pycache__/*' \) | grep -q .; then die "transient Python bytecode present in payload"; fi

echo 'PASS: V33 FINAL OFFLINE PACKAGE PREFLIGHT COMPLETE'
