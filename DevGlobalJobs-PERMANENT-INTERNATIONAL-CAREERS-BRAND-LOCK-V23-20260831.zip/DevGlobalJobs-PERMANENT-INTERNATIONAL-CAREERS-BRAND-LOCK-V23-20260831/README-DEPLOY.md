# Dev Global Jobs V23 Permanent International Careers Brand Lock

This release turns the International Careers identity into a source-of-truth contract instead of a one-off compiled metadata patch.

## Locked identity

- Dev Global Jobs = **International Careers Platform**
- `/jobs/all` = complete jobs marketplace
- `/jobs/international` = international / work-abroad jobs
- `/jobs/sponsored` = sponsored employer-promoted jobs
- Featured = placement/status only; no separate SEO route; discovery remains `/jobs/all`
- UN and NGO = specialist categories only

## Permanent source layer

The authoritative file is `brand-lock/brand-contract.json` (SHA-256 `e0001535d4fa89ceaf5c376e9dc3d1c43f2e8233044dccded67c110377239044`). Server metadata and the SPA metadata guard resolve from this contract. The source installer also adds npm prebuild synchronization and a postbuild verification gate, so a normal future `npm run build` fails if the brand lock is missing or inconsistent.

## Immediate live layer

The package also contains a reviewed runtime based on the successful V19 application baseline with the V22 SEO architecture converted to the V23 contract-backed resolver. It does not run `npm build`, `drizzle-kit push`, or any database migration during deployment.

## Search / LLM identity files

`/brand-contract.json` and `/llms.txt` are public, factual machine-readable identity resources. They do not promise or guarantee search rankings or traffic.

## Safety

The deploy script collision-checks the exact current V19 runtime, backs up every touched runtime/source file, installs the source lock, validates it, atomically installs the V23 runtime, reloads only `devglobaljobs`, checks representative routes, private noindex, and public delivery, and rolls back on failure.
