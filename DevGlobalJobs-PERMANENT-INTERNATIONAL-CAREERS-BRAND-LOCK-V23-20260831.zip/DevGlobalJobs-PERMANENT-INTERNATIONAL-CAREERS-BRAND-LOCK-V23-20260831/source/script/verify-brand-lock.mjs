import fs from "fs";
import path from "path";
import crypto from "crypto";
const root=process.cwd(); const dist=process.argv.includes("--dist");
function die(s){console.error("DGJ BRAND LOCK FAIL:",s);process.exit(1)}
function read(p){if(!fs.existsSync(p))die(`missing ${p}`);return fs.readFileSync(p,"utf8")}
const contractPath=path.join(root,"brand-lock","brand-contract.json"); const raw=read(contractPath); let c;try{c=JSON.parse(raw)}catch(e){die("invalid contract JSON")}
if(c.lockId!=="DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23"||c.version!=="23.0.0")die("contract identity/version mismatch");
const sha=crypto.createHash("sha256").update(raw).digest("hex"); const shaFile=read(path.join(root,"brand-lock","BRAND-CONTRACT.sha256")).trim().split(/\s+/)[0];if(sha!==shaFile)die("contract checksum mismatch");
const all={...c.staticRoutes,...c.privateRoutes}; const titles=new Map();
const forbidden=['Jobs Jobs','Careers Careers','Opportunities Opportunities','EmploymentAgency',"World's #1 International Job Board",'#1 International Job Platform','International Job Board | UN, NGO, Remote & Global Careers'];
for(const [route,m] of Object.entries(all)){
  if(!m.title||!m.description)die(`metadata missing ${route}`);
  for(const bad of forbidden)if(m.title.includes(bad)||m.description.includes(bad))die(`forbidden phrase ${bad} at ${route}`);
  if(m.title.includes("—")||m.description.includes("—"))die(`em dash in locked metadata ${route}`);
  if(m.title.length>78)die(`title too long ${route}: ${m.title.length}`);
  if(!String(m.robots||c.indexRobots).startsWith("noindex")){
    if(titles.has(m.title))die(`duplicate authored title ${route} and ${titles.get(m.title)}`); titles.set(m.title,route);
  }
}
if(c.staticRoutes['/jobs/all'].title===c.staticRoutes['/jobs/international'].title)die('All Jobs and International Jobs overlap');
if(!c.staticRoutes['/jobs/sponsored'].title.startsWith('Sponsored Jobs')||c.staticRoutes['/jobs/sponsored'].title.includes('Featured'))die('Sponsored route semantics broken');
if(c.brand.featuredRule.hasSeparateSeoRoute!==false||c.brand.featuredRule.discoveryDestination!=='/jobs/all')die('Featured placement rule broken');
const facade=read(path.join(root,'server','seoMeta.ts'));if(!facade.includes('DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23')||!facade.includes('./brandSeo'))die('server SEO facade not locked');
const server=read(path.join(root,'server','brandSeo.ts'));if(!server.includes('brand-contract.json')||!server.includes('DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23'))die('server contract resolver missing');
const client=read(path.join(root,'client','public','dgj-brand-lock.js'));if(!client.includes('/brand-contract.json')||!client.includes('DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23'))die('client contract resolver missing');
const index=read(path.join(root,'client','index.html'));if(!index.includes('/dgj-brand-lock.js')||!index.includes('DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23'))die('source index brand lock missing');
for(const bad of ['EmploymentAgency','<meta name="keywords"',"World's #1 International Job Board",'#1 International Job Platform'])if(index.includes(bad))die(`source index forbidden: ${bad}`);
const pkg=JSON.parse(read(path.join(root,'package.json')));if(!String(pkg.scripts?.prebuild||'').includes('sync-brand-contract.mjs'))die('prebuild contract sync missing');if(!String(pkg.scripts?.postbuild||'').includes('verify-brand-lock.mjs --dist'))die('postbuild gate missing');
if(dist){
 const ds=read(path.join(root,'dist','index.cjs')); const di=read(path.join(root,'dist','public','index.html')); const dc=read(path.join(root,'dist','public','brand-contract.json')); const dj=read(path.join(root,'dist','public','dgj-brand-lock.js'));
 if(!ds.includes('DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23'))die('built server marker missing');
 if(!di.includes('DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23')&&!di.includes('/dgj-brand-lock.js'))die('built index lock loader missing');
 if(!dj.includes('DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23'))die('built client lock missing');
 if(crypto.createHash('sha256').update(dc).digest('hex')!==sha)die('public built contract differs from source contract');
 for(const bad of forbidden)if(ds.includes(bad)&&bad!=='EmploymentAgency')die(`built server forbidden phrase: ${bad}`);
}
console.log(`PASS: DGJ permanent brand lock verified${dist?' including built runtime':''}. Contract SHA ${sha}`);
