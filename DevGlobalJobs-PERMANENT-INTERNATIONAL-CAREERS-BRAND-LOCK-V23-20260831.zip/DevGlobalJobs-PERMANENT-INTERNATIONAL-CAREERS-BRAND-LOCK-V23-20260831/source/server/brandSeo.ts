// Generated from brand-lock/brand-contract.json. Do not hand-edit metadata here.
// @ts-nocheck
// server/brandSeo.ts - DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23
const BASE_URL = "https://devglobaljobs.com";
export const DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23 = "DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23";
import fs from "fs";
import path from "path";
const dgjBrandFs = fs;
const dgjBrandPath = path;
function dgjLoadBrandContract() {
  const contractPath = process.env.DGJ_BRAND_CONTRACT || dgjBrandPath.join(process.cwd(), "brand-lock", "brand-contract.json");
  let parsed;
  try { parsed = JSON.parse(dgjBrandFs.readFileSync(contractPath, "utf8")); }
  catch (error) { throw new Error(`DGJ Brand Lock: cannot load ${contractPath}: ${error instanceof Error ? error.message : String(error)}`); }
  if (!parsed || parsed.lockId !== DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23 || parsed.version !== "23.0.0") {
    throw new Error("DGJ Brand Lock: contract identity/version mismatch");
  }
  return parsed;
}
const DGJ_BRAND_CONTRACT = dgjLoadBrandContract();
function dgjTitleCaseSlug(slug) {
  return String(slug || "").replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
function dgjTrimTitle(value, max = 68) {
  const s = String(value || "").replace(/\s+/g, " ").trim();
  return s.length <= max ? s : s.slice(0, max - 1).replace(/\s+\S*$/, "") + "…";
}
function dgjStaticMeta(path) {
  return DGJ_BRAND_CONTRACT.staticRoutes[path] || DGJ_BRAND_CONTRACT.privateRoutes[path] || null;
}
export function getPageMeta(urlPath) {
  const path = String(urlPath || "/").split("?")[0] || "/";
  if (path === "/jobs") {
    const m = DGJ_BRAND_CONTRACT.staticRoutes["/jobs/all"];
    return { ...m, canonical: `${BASE_URL}/jobs/all`, ogType: "website", robots: m.robots || DGJ_BRAND_CONTRACT.indexRobots };
  }
  const exact = dgjStaticMeta(path);
  if (exact) return { ...exact, canonical: path === "/" ? BASE_URL : `${BASE_URL}${path}`, ogType: path.startsWith("/blog/") ? "article" : "website", robots: exact.robots || DGJ_BRAND_CONTRACT.indexRobots };
  const country = path.match(/^\/jobs\/country\/([a-z0-9-]+)$/);
  if (country) {
    const slug = country[1]; const name = DGJ_BRAND_CONTRACT.countries[slug] || dgjTitleCaseSlug(slug);
    const p = DGJ_BRAND_CONTRACT.dynamicPatterns.country;
    return { title:p.title.replace("{Country}",name), description:p.description.replaceAll("{Country}",name), canonical:`${BASE_URL}${path}`, ogType:"website", pageType:p.pageType, robots:DGJ_BRAND_CONTRACT.indexRobots, label:`Jobs in ${name}` };
  }
  const city = path.match(/^\/jobs\/city\/([a-z0-9-]+)$/);
  if (city) {
    const name=dgjTitleCaseSlug(city[1]); const p=DGJ_BRAND_CONTRACT.dynamicPatterns.city;
    return { title:p.title.replace("{City}",name), description:p.description.replaceAll("{City}",name), canonical:`${BASE_URL}${path}`, ogType:"website", pageType:p.pageType, robots:DGJ_BRAND_CONTRACT.indexRobots, label:`Jobs in ${name}` };
  }
  const job = path.match(/^\/jobs\/detail\/(\d+)$/);
  if (job) return { title:"Job Details | Dev Global Jobs", description:"Review the role, requirements and application information for this opportunity on Dev Global Jobs.", canonical:`${BASE_URL}${path}`, ogType:"article", pageType:"WebPage", robots:DGJ_BRAND_CONTRACT.indexRobots, label:"Job Details" };
  if (path.startsWith("/blog/")) {
    const slug=path.slice(6); const known=DGJ_BRAND_CONTRACT.blogArticles[slug];
    if (known) return { ...known, canonical:`${BASE_URL}${path}`, ogType:"article", pageType:"Article", robots:DGJ_BRAND_CONTRACT.indexRobots, label:dgjTitleCaseSlug(slug) };
    const label=dgjTitleCaseSlug(slug);
    return { title:dgjTrimTitle(`${label} | Dev Global Jobs`), description:`Read practical career guidance on ${label.toLowerCase()} from Dev Global Jobs, an international careers platform for global professionals.`, canonical:`${BASE_URL}${path}`, ogType:"article", pageType:"Article", robots:DGJ_BRAND_CONTRACT.indexRobots, label };
  }
  if (path === "/admin" || path.startsWith("/admin/") || path.startsWith("/api/")) return { title:"Private Area | Dev Global Jobs", description:"Private Dev Global Jobs platform area.", canonical:`${BASE_URL}${path}`, ogType:"website", pageType:"WebPage", robots:"noindex, nofollow", label:"Private Area" };
  return { title:"Page Not Found | Dev Global Jobs", description:"The requested page could not be found. Explore international careers and opportunities on Dev Global Jobs.", canonical:`${BASE_URL}${path}`, ogType:"website", pageType:"WebPage", robots:"noindex, nofollow", label:"Page Not Found" };
}
function dgjEscapeMeta(value) { return String(value || "").replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function dgjEscapeText(value) { return String(value || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function dgjPageLabel(path) {
  const m=dgjStaticMeta(path); if (m && m.label) return m.label;
  if (path.startsWith("/tools/")) return dgjTitleCaseSlug(path.slice(7));
  return dgjTitleCaseSlug(path.split("/").filter(Boolean).pop() || "Home");
}
export function generateBreadcrumbSchema(urlPath) {
  const path=String(urlPath||"/").split("?")[0]||"/"; if(path==="/") return null;
  const items=[{"@type":"ListItem","position":1,"name":"Home","item":BASE_URL}];
  if (/^\/jobs\/(all|un|ngo|remote|international|technology|healthcare|business|education|engineering|creative|sales|gig|youth|sponsored)$/.test(path)) {
    items.push({"@type":"ListItem","position":2,"name":"All Jobs","item":`${BASE_URL}/jobs/all`});
    if(path!=="/jobs/all") items.push({"@type":"ListItem","position":3,"name":dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  } else if (/^\/jobs\/(country|city)\//.test(path)) {
    items.push({"@type":"ListItem","position":2,"name":"All Jobs","item":`${BASE_URL}/jobs/all`});
    items.push({"@type":"ListItem","position":3,"name":getPageMeta(path).label || dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  } else if (/^\/jobs\/detail\//.test(path)) {
    items.push({"@type":"ListItem","position":2,"name":"All Jobs","item":`${BASE_URL}/jobs/all`});
    items.push({"@type":"ListItem","position":3,"name":"Job Details","item":`${BASE_URL}${path}`});
  } else if (path.startsWith("/tools/")) {
    items.push({"@type":"ListItem","position":2,"name":"Career Tools","item":`${BASE_URL}/tools/country-salary-calculator`});
    items.push({"@type":"ListItem","position":3,"name":dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  } else if (path.startsWith("/blog/")) {
    items.push({"@type":"ListItem","position":2,"name":"Career Insights","item":`${BASE_URL}/blog`});
    items.push({"@type":"ListItem","position":3,"name":getPageMeta(path).label || dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  } else items.push({"@type":"ListItem","position":2,"name":dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  return JSON.stringify({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":items});
}
function generatePageSchema(urlPath, meta) {
  return JSON.stringify({"@context":"https://schema.org","@type":meta.pageType||"WebPage","@id":`${meta.canonical}#webpage`,"url":meta.canonical,"name":meta.title,"description":meta.description,"isPartOf":{"@id":`${BASE_URL}/#website`},"about":{"@type":"Thing","name":meta.label||"International Careers"},"publisher":{"@id":`${BASE_URL}/#organization`},"inLanguage":"en"});
}
export function injectMetaTags(html, urlPath) {
  const meta=getPageMeta(urlPath), titleText=dgjEscapeText(meta.title), titleAttr=dgjEscapeMeta(meta.title), descAttr=dgjEscapeMeta(meta.description), canonicalAttr=dgjEscapeMeta(meta.canonical), robotsAttr=dgjEscapeMeta(meta.robots||DGJ_BRAND_CONTRACT.indexRobots);
  html=html.replace(/<title>[^<]*<\/title>/,`<title>${titleText}</title>`);
  html=html.replace(/<meta name="description" content="[^"]*"\s*\/?>/,`<meta name="description" content="${descAttr}" />`);
  html=html.replace(/<link rel="canonical" href="[^"]*"\s*\/?>/,`<link rel="canonical" href="${canonicalAttr}" />`);
  html=html.replace(/<meta property="og:type" content="[^"]*"\s*\/?>/,`<meta property="og:type" content="${dgjEscapeMeta(meta.ogType||"website")}" />`);
  html=html.replace(/<meta property="og:title" content="[^"]*"\s*\/?>/,`<meta property="og:title" content="${titleAttr}" />`);
  html=html.replace(/<meta property="og:description" content="[^"]*"\s*\/?>/,`<meta property="og:description" content="${descAttr}" />`);
  html=html.replace(/<meta property="og:url" content="[^"]*"\s*\/?>/,`<meta property="og:url" content="${canonicalAttr}" />`);
  html=html.replace(/<meta name="twitter:title" content="[^"]*"\s*\/?>/,`<meta name="twitter:title" content="${titleAttr}" />`);
  html=html.replace(/<meta name="twitter:description" content="[^"]*"\s*\/?>/,`<meta name="twitter:description" content="${descAttr}" />`);
  html=html.replace(/<meta name="robots" content="[^"]*"\s*\/?>/,`<meta name="robots" content="${robotsAttr}" />`);
  html=html.replace(/<meta name="googlebot" content="[^"]*"\s*\/?>/,`<meta name="googlebot" content="${robotsAttr}" />`);
  html=html.replace(/<meta name="bingbot" content="[^"]*"\s*\/?>/,`<meta name="bingbot" content="${robotsAttr}" />`);
  html=html.replace(/\s*<link rel="alternate" hreflang="[^"]+" href="[^"]+"\s*\/?>/g,"");
  html=html.replace(/\s*<script id="dgj-v23-page-schema"[\s\S]*?<\/script>/g,"").replace(/\s*<script id="dgj-v23-breadcrumb-schema"[\s\S]*?<\/script>/g,"");
  const hreflang=`\n    <link rel="alternate" hreflang="en" href="${canonicalAttr}" />\n    <link rel="alternate" hreflang="x-default" href="${canonicalAttr}" />`;
  const breadcrumb=generateBreadcrumbSchema(urlPath); let injections=`${hreflang}\n    <!-- DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23 -->\n    <script id="dgj-v23-page-schema" type="application/ld+json">${generatePageSchema(urlPath,meta)}</script>`;
  if(breadcrumb) injections+=`\n    <script id="dgj-v23-breadcrumb-schema" type="application/ld+json">${breadcrumb}</script>`;
  return html.replace("</head>",`${injections}\n</head>`);
}
export function injectJobDetailMeta(html, job) {
  const BASE=BASE_URL;
  const title=`${job.title} at ${job.organization} | Dev Global Jobs`;
  const descRaw=job.description?String(job.description).replace(/<[^>]*>/g,"").replace(/\s+/g," ").trim():"";
  const description=descRaw.length>160?descRaw.substring(0,157)+"...":descRaw||`Explore ${job.title} at ${job.organization}. ${job.location||"Worldwide"}. Review the opportunity and continue your career search on Dev Global Jobs.`;
  const canonical=`${BASE}/jobs/detail/${job.id}`; const safe=(s)=>dgjEscapeMeta(s);
  html=html.replace(/<title>[^<]*<\/title>/,`<title>${dgjEscapeText(title)}</title>`)
    .replace(/<meta name="description" content="[^"]*"\s*\/?>/,`<meta name="description" content="${safe(description)}" />`)
    .replace(/<link rel="canonical" href="[^"]*"\s*\/?>/,`<link rel="canonical" href="${canonical}" />`)
    .replace(/<meta property="og:title" content="[^"]*"\s*\/?>/,`<meta property="og:title" content="${safe(title)}" />`)
    .replace(/<meta property="og:description" content="[^"]*"\s*\/?>/,`<meta property="og:description" content="${safe(description)}" />`)
    .replace(/<meta property="og:url" content="[^"]*"\s*\/?>/,`<meta property="og:url" content="${canonical}" />`)
    .replace(/<meta property="og:type" content="[^"]*"\s*\/?>/,`<meta property="og:type" content="article" />`)
    .replace(/<meta name="twitter:title" content="[^"]*"\s*\/?>/,`<meta name="twitter:title" content="${safe(title)}" />`)
    .replace(/<meta name="twitter:description" content="[^"]*"\s*\/?>/,`<meta name="twitter:description" content="${safe(description)}" />`)
    .replace(/<meta name="robots" content="[^"]*"\s*\/?>/,`<meta name="robots" content="${DGJ_BRAND_CONTRACT.indexRobots}" />`);
  const jobSchema={"@context":"https://schema.org","@type":"JobPosting","title":job.title,"description":descRaw.substring(0,5000)||`${job.title} position at ${job.organization}. ${job.location||"Worldwide"}.`,"identifier":{"@type":"PropertyValue","name":job.organization,"value":String(job.id)},"hiringOrganization":{"@type":"Organization","name":job.organization},"employmentType":job.jobType||undefined,"url":canonical};
  if(job.postedAt){const d=new Date(job.postedAt);if(!Number.isNaN(d.getTime()))jobSchema.datePosted=d.toISOString().split("T")[0];}
  if(job.closingDate){const d=new Date(job.closingDate);if(!Number.isNaN(d.getTime()))jobSchema.validThrough=d.toISOString().split("T")[0];}
  const remote=job.category==="remote"||(job.location&&/remote|anywhere|worldwide|virtual/i.test(job.location));
  if(remote) jobSchema.jobLocationType="TELECOMMUTE"; else if(job.location) jobSchema.jobLocation={"@type":"Place","address":{"@type":"PostalAddress","addressLocality":job.location,"addressCountry":job.country||""}};
  const breadcrumb={"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":BASE},{"@type":"ListItem","position":2,"name":"All Jobs","item":`${BASE}/jobs/all`},{"@type":"ListItem","position":3,"name":job.title,"item":canonical}]};
  html=html.replace(/\s*<link rel="alternate" hreflang="[^"]+" href="[^"]+"\s*\/?>/g,"");
  const extra=`\n    <link rel="alternate" hreflang="en" href="${canonical}" />\n    <link rel="alternate" hreflang="x-default" href="${canonical}" />\n    <!-- DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23 -->\n    <script type="application/ld+json">${JSON.stringify(jobSchema)}</script>\n    <script type="application/ld+json">${JSON.stringify(breadcrumb)}</script>\n`;
  return html.replace("</head>",`${extra}</head>`);
}
