#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/var/www/devglobaljobs}"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-v17-${STAMP}"

TITLE='Dev Global Jobs | International Jobs, Remote Work & Global Careers'
DESC='Find international jobs, remote work, visa sponsored opportunities and global careers. Explore thousands of jobs worldwide and take the next step with Dev Global Jobs.'

# Exact successful V16 production baseline.
BASE_INDEX="4cece09802e595c6542cae517d126b709571b4e46eea63a6da490880179e5646"
V16_HTML="5b5c0b22697c49a3b4c6f8ecea327bf54f53a55bcb71beaf1efe7bae1e9e2324"
BASE_GROWTH="d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a"
BASE_CSS="4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51"
BASE_SPA="725d891d23a2567f0f880925d6080ea3633ded4ab67dac3178d6a33d7eebe42b"
BASE_EASY="3dae0f5f085e342e5095c0c09717ce7dad718503a433d0989eb3dcd0be7ac102"

# V17 changes only dist/public/index.html metadata.
NEW_HTML="36dad3e5dc5a2ffa81fb979c156de6fe46e8a8f77fbcbaaef7c7d502b8cecd1f"

say(){ printf '\n============================================================\n%s\n============================================================\n' "$1"; }
die(){ say "SAFE STOP: $*"; exit 1; }
sha(){ sha256sum "$1" | awk '{print $1}'; }
rollback(){
  echo "ROLLBACK: restoring pre-V17 homepage HTML..."
  if [ -f "$BACKUP/index.html" ]; then
    cp -a "$BACKUP/index.html" "$APP_DIR/dist/public/index.html"
    pm2 reload devglobaljobs --update-env >/dev/null 2>&1 || true
    sleep 4
  fi
}
trap 'rc=$?; if [ $rc -ne 0 ] && [ -d "$BACKUP" ]; then rollback; fi; exit $rc' EXIT

[ "$(id -u)" = "0" ] || die "Run as root."
[ -d "$APP_DIR" ] || die "$APP_DIR missing."
[ -f "$APP_DIR/.env" ] || die "Live .env missing."

say "1/8 CURRENT LIVE HEALTH"
PORT="$(cd "$APP_DIR" && node --env-file=.env -e 'process.stdout.write(process.env.PORT||"8080")')"
curl -fsS --max-time 12 "http://127.0.0.1:${PORT}/api/jobs/stats" >/dev/null || die "Current API unhealthy."
curl -fsS --max-time 20 "https://devglobaljobs.com/" >/dev/null || die "Current public site unhealthy."
echo "PASS: current website healthy."

say "2/8 COLLISION PROTECTION — EXACT SUCCESSFUL V16"
[ "$(sha "$APP_DIR/dist/index.cjs")" = "$BASE_INDEX" ] || die "Live server runtime differs from preserved V16 baseline."
[ "$(sha "$APP_DIR/dist/public/index.html")" = "$V16_HTML" ] || die "Live homepage HTML is not exact V16. Nothing changed."
[ "$(sha "$APP_DIR/dist/public/assets/growth-suite.js")" = "$BASE_GROWTH" ] || die "Live Growth Suite differs from V16 baseline."
[ "$(sha "$APP_DIR/dist/public/assets/growth-suite.css")" = "$BASE_CSS" ] || die "Live Growth CSS differs from V16 baseline."
[ "$(sha "$APP_DIR/dist/public/assets/index-DGJ45auth-v11.js")" = "$BASE_SPA" ] || die "Live V11 SPA differs from preserved baseline."
[ "$(sha "$APP_DIR/dist/public/assets/easy-apply-v8.js")" = "$BASE_EASY" ] || die "Live Easy Apply differs from preserved baseline."
echo "PASS: exact successful V16 baseline confirmed."

say "3/8 PACKAGE + HOMEPAGE META VALIDATION"
cd "$(dirname "$0")"
sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || die "Payload checksum failed."
grep -Fq '<!-- DGJ HOMEPAGE META SEO V17 -->' dist/public/index.html || die "V17 marker missing."
grep -Fq "<title>${TITLE}</title>" dist/public/index.html || die "Exact homepage meta title missing."
grep -Fq "<meta name=\"description\" content=\"${DESC}\" />" dist/public/index.html || die "Exact homepage meta description missing."
grep -Fq "title: '${TITLE}'," dist/public/index.html || die "SPA homepage title map not updated."
grep -Fq "desc: '${DESC}'," dist/public/index.html || die "SPA homepage description map not updated."
grep -Fq '<meta property="og:title" content="Dev Global Jobs | International Jobs, Remote Work &amp; Global Careers" />' dist/public/index.html || die "Open Graph title not aligned."
grep -Fq "<meta property=\"og:description\" content=\"${DESC}\" />" dist/public/index.html || die "Open Graph description not aligned."
grep -Fq '<meta name="twitter:title" content="Dev Global Jobs | International Jobs, Remote Work &amp; Global Careers" />' dist/public/index.html || die "Twitter title not aligned."
grep -Fq "<meta name=\"twitter:description\" content=\"${DESC}\" />" dist/public/index.html || die "Twitter description not aligned."
if printf '%s\n%s\n' "$TITLE" "$DESC" | grep -Eq '—|–'; then die "Em dash/en dash found in requested homepage metadata."; fi
echo "PASS: exact V17 homepage metadata validated; no em dash."

say "4/8 BACKUP TOUCHED V16 FILE"
mkdir -p "$BACKUP"
cp -a "$APP_DIR/dist/public/index.html" "$BACKUP/index.html"
echo "Backup: $BACKUP"

say "5/8 ATOMIC V17 HOMEPAGE HTML COPY"
cp -a dist/public/index.html "$APP_DIR/dist/public/index.html.new"
mv "$APP_DIR/dist/public/index.html.new" "$APP_DIR/dist/public/index.html"
[ "$(sha "$APP_DIR/dist/public/index.html")" = "$NEW_HTML" ] || die "Active V17 homepage HTML SHA mismatch."
echo "PASS: only homepage HTML metadata file copied."

say "6/8 PM2 RELOAD + API HEALTH"
pm2 reload devglobaljobs --update-env >/dev/null
sleep 6
curl -fsS --max-time 12 "http://127.0.0.1:${PORT}/api/jobs/stats" >/dev/null || die "API unhealthy after V17 reload."
echo "PASS: PM2 and API healthy."

say "7/8 PUBLIC HOMEPAGE META CHECK"
PUBLIC_HTML="/tmp/dgj-v17-meta-${STAMP}.html"
curl -fsS --max-time 20 -H 'Cache-Control: no-cache, no-store' "https://devglobaljobs.com/?v17meta=${STAMP}" -o "$PUBLIC_HTML" || die "Public homepage fetch failed."
grep -Fq "<title>${TITLE}</title>" "$PUBLIC_HTML" || die "Public homepage title is not V17."
grep -Fq "<meta name=\"description\" content=\"${DESC}\" />" "$PUBLIC_HTML" || die "Public homepage meta description is not V17."
grep -Fq '<!-- DGJ HOMEPAGE META SEO V17 -->' "$PUBLIC_HTML" || die "Public V17 marker missing."
echo "PASS: V17 homepage title and description publicly served."

say "8/8 PRESERVATION CHECK"
[ "$(sha "$APP_DIR/dist/index.cjs")" = "$BASE_INDEX" ] || die "Server runtime unexpectedly changed."
[ "$(sha "$APP_DIR/dist/public/assets/growth-suite.js")" = "$BASE_GROWTH" ] || die "V16 related cards/PayPal Growth Suite unexpectedly changed."
[ "$(sha "$APP_DIR/dist/public/assets/growth-suite.css")" = "$BASE_CSS" ] || die "V16 related cards CSS unexpectedly changed."
[ "$(sha "$APP_DIR/dist/public/assets/index-DGJ45auth-v11.js")" = "$BASE_SPA" ] || die "Featured-first SPA unexpectedly changed."
[ "$(sha "$APP_DIR/dist/public/assets/easy-apply-v8.js")" = "$BASE_EASY" ] || die "Easy Apply unexpectedly changed."
grep -Fq 'https://paypal.me/tnwdgj' "$APP_DIR/dist/public/assets/growth-suite.js" || die "PayPal support not preserved."
if grep -Eq 'Contribute with Google|swg-standard-button|CAow0-yiDA:openaccess|news\.google\.com/swg|dgj-google-contribution' "$APP_DIR/dist/public/assets/growth-suite.js"; then die "Removed Google contribution unexpectedly returned."; fi
curl -fsS --max-time 20 "https://devglobaljobs.com/sign-in?mode=signup&v17=${STAMP}" >/dev/null || die "Sign-In unhealthy."
pm2 save >/dev/null
rm -f "$PUBLIC_HTML"
trap - EXIT

say "SUCCESS: HOMEPAGE META SEO V17 IS LIVE"
echo "  ✓ Homepage title updated exactly"
echo "  ✓ Homepage meta description updated exactly"
echo "  ✓ Open Graph and Twitter homepage metadata aligned"
echo "  ✓ SPA homepage metadata map aligned"
echo "  ✓ No em dash/en dash in new title or description"
echo "  ✓ V16 3-card related Featured/Regular layout preserved"
echo "  ✓ Employer priority + PayPal + Wise + Trustpilot preserved"
echo "  ✓ Auth no-flash + server-native OTP + Featured-first + Easy Apply preserved"
echo "  ✓ Google contribution remains removed"
echo "  ✓ No npm build / no drizzle-kit push / no full-site replacement"
echo "Rollback backup: $BACKUP"
