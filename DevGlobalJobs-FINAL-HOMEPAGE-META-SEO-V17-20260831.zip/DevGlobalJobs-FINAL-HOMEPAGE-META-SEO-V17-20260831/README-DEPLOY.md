# Dev Global Jobs V17 — Homepage Meta Title + Description

This release is based on the successful V16 package and changes only homepage metadata in `dist/public/index.html`.

## Exact requested homepage metadata

**Meta Title**

`Dev Global Jobs | International Jobs, Remote Work & Global Careers`

**Meta Description**

`Find international jobs, remote work, visa sponsored opportunities and global careers. Explore thousands of jobs worldwide and take the next step with Dev Global Jobs.`

There is no em dash or en dash in either string.

## Metadata consistency

The same homepage title and description are also aligned in:

- the client-side homepage route metadata map, so SPA navigation does not restore the old metadata;
- Open Graph title/description;
- Twitter title/description.

No other page-specific SEO titles/descriptions were changed.

## Preserved from V16

- Related Featured Jobs: max 3 homepage-style Featured cards
- Related Regular Jobs: max 3 homepage-style Regular cards
- Employer-posted priority ordering
- PayPal `https://paypal.me/tnwdgj`
- Wise Buy a Coffee
- Trustpilot Review
- Google Contribution remains removed
- Auth no-flash and server-native OTP
- Featured-first homepage
- Easy Apply
- Developers API + RSS
- Mobile/admin fixes

## Safe deployment

The deploy script accepts only the exact successful V16 production baseline. If the live files differ, it stops without overwriting.

Run:

```bash
APP_DIR=/var/www/devglobaljobs bash deploy-final-safe.sh
```

The script backs up the current V16 homepage HTML, atomically replaces only `dist/public/index.html`, reloads only `devglobaljobs`, checks the public metadata, verifies all important V16 assets remain unchanged, and rolls back if validation fails.

It does **not** run npm build, drizzle-kit push, git pull over the live app, database migrations, or a full-site replacement.
