# Dev Global Jobs V20 - International Careers Brand Architecture

This release upgrades the server-side and SPA-facing brand architecture so Dev Global Jobs is consistently presented as an **international careers platform**, rather than allowing the generic fallback to frame the site as mainly UN/NGO.

## What changes

- Comprehensive server-side metadata for job categories, countries, cities, resources, tools, employer pages, legal pages, developers and account routes.
- UN and NGO remain specialist category pages only.
- Strong action-oriented meta descriptions and cleaner titles with no em dash in the new V20 metadata layer.
- Server Open Graph, Twitter, canonical, robots, WebPage/CollectionPage schema and breadcrumbs aligned.
- Incorrect cross-country hreflang linking removed; self English and x-default alternates used.
- Homepage WebSite/Organization schema rewritten around international careers.
- `EmploymentAgency` schema classification removed.
- Obsolete homepage meta keywords removed.
- Homepage FAQ schema rewritten around the global careers platform.
- Premium responsive CTA layer added across job discovery, resources, tools, employer and developer pages.
- Old fixed bottom "UN jobs, NGO careers..." first-visit banner removed.

## Preserved

V19 mobile auth, V18 homepage metadata, server-native OTP, Create Account no-flash, V16 related 3+3 cards, PayPal, Wise, Trustpilot, Easy Apply, employer priority, API/RSS and database behavior are preserved.

## Safe deployment

```bash
APP_DIR=/var/www/devglobaljobs bash deploy-final-safe.sh
```

The deploy script collision-checks the exact V19 live runtime/static baseline, backs up only the two touched files, atomically replaces them, reloads only `devglobaljobs`, verifies representative server-side routes and rolls back automatically on validation failure.
