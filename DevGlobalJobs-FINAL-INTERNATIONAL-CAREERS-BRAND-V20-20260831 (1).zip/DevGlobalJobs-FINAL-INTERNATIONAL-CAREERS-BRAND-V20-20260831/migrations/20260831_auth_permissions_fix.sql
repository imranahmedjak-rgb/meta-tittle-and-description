\set ON_ERROR_STOP on
BEGIN;

CREATE TABLE IF NOT EXISTS public.user_sessions (
  sid varchar NOT NULL COLLATE "default",
  sess json NOT NULL,
  expire timestamp(6) NOT NULL,
  CONSTRAINT user_sessions_pkey PRIMARY KEY (sid)
);
CREATE INDEX IF NOT EXISTS idx_user_sessions_expire ON public.user_sessions (expire);

GRANT USAGE ON SCHEMA public TO :"app_user";

SELECT format(
  'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE %I.%I TO %I',
  n.nspname,
  c.relname,
  :'app_user'
)
FROM pg_class c
JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE n.nspname='public'
  AND c.relkind IN ('r','p')
  AND c.relname IN (
    'job_seeker_accounts',
    'job_seeker_profiles',
    'job_seeker_email_verifications',
    'job_seeker_password_resets',
    'dgj_easy_apply_tokens',
    'user_sessions',
    'dgj_marketing_contacts',
    'dgj_employers',
    'dgj_employer_postings',
    'dgj_activity_events',
    'dgj_mail_send_log',
    'dgj_email_campaigns',
    'dgj_email_queue'
  )
\gexec

SELECT format('GRANT USAGE, SELECT ON SEQUENCE %I.%I TO %I', schemaname, sequencename, :'app_user')
FROM pg_sequences
WHERE schemaname='public'
  AND (
    sequencename LIKE 'job_seeker_%'
    OR sequencename LIKE 'dgj_%'
  )
\gexec

COMMIT;
