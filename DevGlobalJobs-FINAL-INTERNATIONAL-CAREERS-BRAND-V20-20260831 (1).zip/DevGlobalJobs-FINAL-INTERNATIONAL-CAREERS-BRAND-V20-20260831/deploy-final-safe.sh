#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${APP_DIR:-/var/www/devglobaljobs}"
SERVER="$APP_DIR/dist/index.cjs"
INDEX="$APP_DIR/dist/public/index.html"
GROWTH_JS="$APP_DIR/dist/public/assets/growth-suite.js"
GROWTH_CSS="$APP_DIR/dist/public/assets/growth-suite.css"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-brand-v20-${STAMP}"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD_SERVER="$SELF_DIR/dist/index.cjs"
PAYLOAD_INDEX="$SELF_DIR/dist/public/index.html"

V19_SERVER_SHA="96c833718aedcafa5b2d5cc777a24721731e86e155300c99e2bc79891329de79"
V19_INDEX_SHA="120bd1d247779dab7c027f453bb7701f7a91b57d787ffba3033b82705fb35bfa"
V16_GROWTH_JS_SHA="d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a"
V16_GROWTH_CSS_SHA="4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51"
HOME_TITLE='Dev Global Jobs | International Jobs, Remote Work & Global Careers'
HOME_DESC='Find international jobs, remote work, visa sponsored opportunities and global careers. Explore thousands of jobs worldwide and take the next step with Dev Global Jobs.'
COPIED=0
rollback(){
  if [ "$COPIED" = "1" ] && [ -d "$BACKUP" ]; then
    echo; echo "ROLLBACK: restoring pre-V20 server and static files..."
    cp -a "$BACKUP/index.cjs" "$SERVER"
    cp -a "$BACKUP/index.html" "$INDEX"
    pm2 reload devglobaljobs >/dev/null 2>&1 || true
    sleep 3
    echo "ROLLBACK COMPLETE."
  fi
}
fail(){ echo; echo "============================================================"; echo "SAFE STOP: $*"; echo "============================================================"; rollback; exit 1; }
trap 'fail "unexpected deployment error"' ERR

[ "$(id -u)" = "0" ] || fail "Run as root."
[ -f "$SERVER" ] || fail "Live server runtime missing."
[ -f "$INDEX" ] || fail "Live index.html missing."
[ -f "$PAYLOAD_SERVER" ] || fail "V20 payload server missing."
[ -f "$PAYLOAD_INDEX" ] || fail "V20 payload index missing."
for c in curl sha256sum node pm2 grep cp mkdir install stat mv awk python3; do command -v "$c" >/dev/null 2>&1 || fail "Missing command: $c"; done

echo "============================================================"
echo "1/9 CURRENT LIVE HEALTH"
echo "============================================================"
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy."
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy."
echo "PASS: current website healthy."

echo; echo "============================================================"; echo "2/9 COLLISION PROTECTION - EXACT SUCCESSFUL V19"; echo "============================================================"
[ "$(sha256sum "$SERVER" | awk '{print $1}')" = "$V19_SERVER_SHA" ] || fail "Live index.cjs is not exact successful V19 baseline. Nothing changed."
[ "$(sha256sum "$INDEX" | awk '{print $1}')" = "$V19_INDEX_SHA" ] || fail "Live index.html is not exact successful V19/V18 static baseline. Nothing changed."
[ "$(sha256sum "$GROWTH_JS" | awk '{print $1}')" = "$V16_GROWTH_JS_SHA" ] || fail "Growth Suite differs from preserved baseline."
[ "$(sha256sum "$GROWTH_CSS" | awk '{print $1}')" = "$V16_GROWTH_CSS_SHA" ] || fail "Growth CSS differs from preserved baseline."
echo "PASS: exact V19 baseline confirmed."

echo; echo "============================================================"; echo "3/9 PACKAGE + INTERNATIONAL CAREERS BRAND VALIDATION"; echo "============================================================"
cd "$SELF_DIR"
sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || fail "Payload checksum validation failed."
node -c "$PAYLOAD_SERVER" >/dev/null || fail "V20 server syntax invalid."
grep -Fq 'DGJ_AUTH_MOBILE_V19' "$PAYLOAD_SERVER" || fail "V19 mobile auth not preserved."
grep -Fq 'DGJ_GLOBAL_CAREER_BRAND_V20' "$PAYLOAD_SERVER" || fail "V20 server brand marker missing."
grep -Fq 'INTERNATIONAL_CAREERS_BRAND_V20' "$PAYLOAD_INDEX" || fail "V20 SPA brand marker missing."
grep -Fq "$HOME_TITLE" "$PAYLOAD_SERVER" || fail "V18 homepage title not preserved."
grep -Fq "$HOME_DESC" "$PAYLOAD_SERVER" || fail "V18 homepage description not preserved."
grep -Fq 'Ready for Your Next International Career Move?' "$PAYLOAD_INDEX" || fail "Premium global careers CTA missing."
! grep -Fq 'Dev Global Jobs - International Job Board | UN, NGO, Remote & Global Careers' "$PAYLOAD_SERVER" || fail "Old UN/NGO generic brand fallback still exists."
! grep -Fq 'What are UN jobs and how do I apply?' "$PAYLOAD_INDEX" || fail "Old UN-led homepage FAQ still exists."
! grep -Fq 'EmploymentAgency' "$PAYLOAD_INDEX" || fail "EmploymentAgency schema classification still exists."
! grep -Fq '<meta name="keywords"' "$PAYLOAD_INDEX" || fail "Obsolete meta keywords still exist."
! grep -Fq 'International job vacancies — updated daily' "$PAYLOAD_INDEX" || fail "Old fixed UN/NGO first-visit CTA still exists."
echo "PASS: V20 brand architecture validated."

echo; echo "============================================================"; echo "4/9 BACKUP ONLY TOUCHED V19 FILES"; echo "============================================================"
mkdir -p "$BACKUP"
cp -a "$SERVER" "$BACKUP/index.cjs"
cp -a "$INDEX" "$BACKUP/index.html"
echo "Backup: $BACKUP"

echo; echo "============================================================"; echo "5/9 ATOMIC V20 COPY"; echo "============================================================"
TMP_SERVER="$APP_DIR/dist/.index.cjs.v20.${STAMP}.tmp"
TMP_INDEX="$APP_DIR/dist/public/.index.html.v20.${STAMP}.tmp"
install -m "$(stat -c '%a' "$SERVER")" "$PAYLOAD_SERVER" "$TMP_SERVER"
install -m "$(stat -c '%a' "$INDEX")" "$PAYLOAD_INDEX" "$TMP_INDEX"
mv -f "$TMP_SERVER" "$SERVER"
mv -f "$TMP_INDEX" "$INDEX"
COPIED=1
echo "PASS: only dist/index.cjs and dist/public/index.html replaced."

echo; echo "============================================================"; echo "6/9 PM2 RELOAD + API HEALTH"; echo "============================================================"
pm2 reload devglobaljobs
sleep 4
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "API unhealthy after V20 reload."
echo "PASS: PM2 and API healthy."

echo; echo "============================================================"; echo "7/9 SERVER-SIDE ROUTE BRAND CHECK"; echo "============================================================"
verify(){
  local path="$1" expected="$2" file="/tmp/dgj-v20-${STAMP}-$(echo "$path"|tr '/?' '__').html"
  curl -fsS -H 'Host: devglobaljobs.com' "http://127.0.0.1:8080${path}?v20=${STAMP}" -o "$file" || fail "Direct Node fetch failed: $path"
  python3 - "$file" "$expected" <<'PY' || exit 1
import html,re,sys
p,e=sys.argv[1:]
s=open(p,encoding='utf-8',errors='ignore').read()
m=re.search(r'<title[^>]*>(.*?)</title>',s,re.I|re.S)
a=html.unescape(m.group(1).strip()) if m else ''
if a!=e:
 print('EXPECTED:',e);print('ACTUAL:',a);raise SystemExit(1)
PY
  rm -f "$file"
}
verify '/' "$HOME_TITLE" || fail "Homepage server title mismatch."
verify '/jobs/international' 'International Jobs | Careers Across Countries | Dev Global Jobs' || fail "International category title mismatch."
verify '/jobs/un' 'UN Jobs | United Nations Careers Worldwide | Dev Global Jobs' || fail "UN specialist category title mismatch."
verify '/jobs/country/uk' 'United Kingdom Jobs | International Careers and Opportunities | Dev Global Jobs' || fail "Country title mismatch."
verify '/online-courses' 'Free Online Courses | Build Career Skills Worldwide | Dev Global Jobs' || fail "Courses title mismatch."
verify '/tools/resume-checker' 'Free Resume Checker | Improve Your International CV | Dev Global Jobs' || fail "Tool title mismatch."
verify '/pricing' 'Employer Pricing | International Hiring Options | Dev Global Jobs' || fail "Employer title mismatch."
verify '/developers' 'Free Jobs API and RSS Feed | Dev Global Jobs Developers' || fail "Developer title mismatch."
echo "PASS: representative international careers routes verified server-side."

echo; echo "============================================================"; echo "8/9 PRIVATE ROUTE + PUBLIC DELIVERY CHECK"; echo "============================================================"
SIGNIN="/tmp/dgj-v20-signin-${STAMP}.html"
curl -fsS -H 'Host: devglobaljobs.com' "http://127.0.0.1:8080/sign-in?v20=${STAMP}" -o "$SIGNIN" || fail "Sign-in fetch failed."
grep -Fq 'content="noindex, nofollow"' "$SIGNIN" || fail "Sign-in noindex protection missing."
grep -Fq 'DGJ_AUTH_MOBILE_V19' "$SIGNIN" || fail "V19 mobile auth not publicly preserved."
PUBLIC="/tmp/dgj-v20-public-${STAMP}.html"
curl -fsS -H 'Cache-Control: no-cache, no-store, max-age=0' "https://devglobaljobs.com/?v20=${STAMP}" -o "$PUBLIC" || fail "Public homepage fetch failed."
grep -Fq 'INTERNATIONAL_CAREERS_BRAND_V20' "$PUBLIC" || fail "V20 client brand layer not publicly served."
python3 - "$PUBLIC" "$HOME_TITLE" <<'PY' || fail "Public homepage title mismatch."
import html,re,sys
s=open(sys.argv[1],encoding='utf-8',errors='ignore').read();e=sys.argv[2]
m=re.search(r'<title[^>]*>(.*?)</title>',s,re.I|re.S);a=html.unescape(m.group(1).strip()) if m else ''
raise SystemExit(0 if a==e else 1)
PY
rm -f "$SIGNIN" "$PUBLIC"
echo "PASS: private noindex, mobile auth and public V20 delivery verified."

echo; echo "============================================================"; echo "9/9 PRESERVATION + FINAL HEALTH"; echo "============================================================"
[ "$(sha256sum "$GROWTH_JS" | awk '{print $1}')" = "$V16_GROWTH_JS_SHA" ] || fail "Growth Suite changed unexpectedly."
[ "$(sha256sum "$GROWTH_CSS" | awk '{print $1}')" = "$V16_GROWTH_CSS_SHA" ] || fail "Growth CSS changed unexpectedly."
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy after V20."
pm2 save >/dev/null
COPIED=0
trap - ERR

echo
echo "============================================================"
echo "SUCCESS: INTERNATIONAL CAREERS BRAND V20 IS LIVE"
echo "============================================================"
echo "  ✓ Server-side brand now International Careers across public routes"
echo "  ✓ UN and NGO remain specialist categories only"
echo "  ✓ Countries, cities, categories, resources and tools upgraded"
echo "  ✓ Employer, developer, legal and account metadata upgraded"
echo "  ✓ Strong route-specific CTA descriptions"
echo "  ✓ Premium responsive CTA layer added across public discovery/resources"
echo "  ✓ Open Graph, Twitter, canonical, robots and schema aligned"
echo "  ✓ Incorrect cross-country hreflang removed"
echo "  ✓ Private/account/admin pages protected with noindex where appropriate"
echo "  ✓ Old generic UN/NGO brand fallback removed"
echo "  ✓ Old UN-led homepage FAQ and fixed bottom CTA removed"
echo "  ✓ V19 mobile auth and V18 homepage metadata preserved"
echo "  ✓ Related 3+3 cards, PayPal, Wise, Trustpilot, Easy Apply preserved"
echo "  ✓ Database untouched"
echo "  ✓ No npm build / no drizzle-kit push / no full-site replacement"
echo "Rollback backup: $BACKUP"
echo "============================================================"
