// Generated from brand-lock/brand-contract.json. Do not hand-edit metadata here.
// @ts-nocheck
// server/brandSeo.ts - DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27
const BASE_URL = "https://devglobaljobs.com";
const DGJ_SOCIAL_SHARE_IMAGE = `${BASE_URL}/devglobaljobs-social-share.png`;
const DGJ_SOCIAL_SHARE_ALT = "Dev Global Jobs | International Careers";
export const DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27 = "DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27";
import fs from "fs";
import path from "path";
const dgjBrandFs = fs;
const dgjBrandPath = path;
function dgjLoadBrandContract() {
  const contractPath = process.env.DGJ_BRAND_CONTRACT || dgjBrandPath.join(process.cwd(), "brand-lock", "brand-contract.json");
  let parsed;
  try { parsed = JSON.parse(dgjBrandFs.readFileSync(contractPath, "utf8")); }
  catch (error) { throw new Error(`DGJ Brand Lock: cannot load ${contractPath}: ${error instanceof Error ? error.message : String(error)}`); }
  if (!parsed || parsed.lockId !== DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27 || parsed.version !== "27.0.0") {
    throw new Error("DGJ Brand Lock: contract identity/version mismatch");
  }
  return parsed;
}
const DGJ_BRAND_CONTRACT = dgjLoadBrandContract();
function dgjTitleCaseSlug(slug) {
  return String(slug || "").replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
function dgjTrimTitle(value, max = 68) {
  const s = String(value || "").replace(/\s+/g, " ").trim();
  return s.length <= max ? s : s.slice(0, max - 1).replace(/\s+\S*$/, "") + "…";
}
function dgjStaticMeta(path) {
  return DGJ_BRAND_CONTRACT.staticRoutes[path] || DGJ_BRAND_CONTRACT.privateRoutes[path] || null;
}
export function getPageMeta(urlPath) {
  const path = String(urlPath || "/").split("?")[0] || "/";
  if (path === "/jobs") {
    const m = DGJ_BRAND_CONTRACT.staticRoutes["/jobs/all"];
    return { ...m, canonical: `${BASE_URL}/jobs/all`, ogType: "website", robots: m.robots || DGJ_BRAND_CONTRACT.indexRobots };
  }
  const exact = dgjStaticMeta(path);
  if (exact) return { ...exact, canonical: path === "/" ? BASE_URL : `${BASE_URL}${path}`, ogType: path.startsWith("/blog/") ? "article" : "website", robots: exact.robots || DGJ_BRAND_CONTRACT.indexRobots };
  const country = path.match(/^\/jobs\/country\/([a-z0-9-]+)$/);
  if (country) {
    const slug = country[1]; const name = DGJ_BRAND_CONTRACT.countries[slug] || dgjTitleCaseSlug(slug);
    const p = DGJ_BRAND_CONTRACT.dynamicPatterns.country;
    return { title:p.title.replace("{Country}",name), description:p.description.replaceAll("{Country}",name), canonical:`${BASE_URL}${path}`, ogType:"website", pageType:p.pageType, robots:DGJ_BRAND_CONTRACT.indexRobots, label:`Jobs in ${name}` };
  }
  const city = path.match(/^\/jobs\/city\/([a-z0-9-]+)$/);
  if (city) {
    const slug=city[1]; const name=DGJ_BRAND_CONTRACT.cities?.[slug] || dgjTitleCaseSlug(slug); const p=DGJ_BRAND_CONTRACT.dynamicPatterns.city;
    return { title:p.title.replace("{City}",name), description:p.description.replaceAll("{City}",name), canonical:`${BASE_URL}${path}`, ogType:"website", pageType:p.pageType, robots:DGJ_BRAND_CONTRACT.indexRobots, label:`Jobs in ${name}` };
  }
  const job = path.match(/^\/jobs\/detail\/(\d+)$/);
  if (job) return { title:"Job Details | Dev Global Jobs", description:"Review the role, requirements and application information for this opportunity on Dev Global Jobs.", canonical:`${BASE_URL}${path}`, ogType:"article", pageType:"WebPage", robots:DGJ_BRAND_CONTRACT.indexRobots, label:"Job Details" };
  if (path.startsWith("/blog/")) {
    const slug=path.slice(6); const known=DGJ_BRAND_CONTRACT.blogArticles[slug];
    if (known) return { ...known, canonical:`${BASE_URL}${path}`, ogType:"article", pageType:"Article", robots:DGJ_BRAND_CONTRACT.indexRobots, label:dgjTitleCaseSlug(slug) };
    const label=dgjTitleCaseSlug(slug);
    return { title:dgjTrimTitle(`${label} | Dev Global Jobs`), description:`Read practical career guidance on ${label.toLowerCase()} from Dev Global Jobs, an international careers platform for global professionals.`, canonical:`${BASE_URL}${path}`, ogType:"article", pageType:"Article", robots:DGJ_BRAND_CONTRACT.indexRobots, label };
  }
  if (path === "/admin" || path.startsWith("/admin/") || path.startsWith("/api/")) return { title:"Private Area | Dev Global Jobs", description:"Private Dev Global Jobs platform area.", canonical:`${BASE_URL}${path}`, ogType:"website", pageType:"WebPage", robots:"noindex, nofollow", label:"Private Area" };
  return { title:"Page Not Found | Dev Global Jobs", description:"The requested page could not be found. Explore international careers and opportunities on Dev Global Jobs.", canonical:`${BASE_URL}${path}`, ogType:"website", pageType:"WebPage", robots:"noindex, nofollow", label:"Page Not Found" };
}
function dgjEscapeMeta(value) { return String(value || "").replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function dgjEscapeText(value) { return String(value || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function dgjPageLabel(path) {
  const m=dgjStaticMeta(path); if (m && m.label) return m.label;
  if (path.startsWith("/tools/")) return dgjTitleCaseSlug(path.slice(7));
  return dgjTitleCaseSlug(path.split("/").filter(Boolean).pop() || "Home");
}
export function generateBreadcrumbSchema(urlPath) {
  const path=String(urlPath||"/").split("?")[0]||"/"; if(path==="/") return null;
  const items=[{"@type":"ListItem","position":1,"name":"Home","item":BASE_URL}];
  if (/^\/jobs\/(all|un|ngo|remote|international|technology|healthcare|business|education|engineering|creative|sales|gig|youth|sponsored)$/.test(path)) {
    items.push({"@type":"ListItem","position":2,"name":"All Jobs","item":`${BASE_URL}/jobs/all`});
    if(path!=="/jobs/all") items.push({"@type":"ListItem","position":3,"name":dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  } else if (/^\/jobs\/(country|city)\//.test(path)) {
    items.push({"@type":"ListItem","position":2,"name":"All Jobs","item":`${BASE_URL}/jobs/all`});
    items.push({"@type":"ListItem","position":3,"name":getPageMeta(path).label || dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  } else if (/^\/jobs\/detail\//.test(path)) {
    items.push({"@type":"ListItem","position":2,"name":"All Jobs","item":`${BASE_URL}/jobs/all`});
    items.push({"@type":"ListItem","position":3,"name":"Job Details","item":`${BASE_URL}${path}`});
  } else if (path.startsWith("/tools/")) {
    items.push({"@type":"ListItem","position":2,"name":"Career Tools","item":`${BASE_URL}/tools/country-salary-calculator`});
    items.push({"@type":"ListItem","position":3,"name":dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  } else if (path.startsWith("/blog/")) {
    items.push({"@type":"ListItem","position":2,"name":"Career Insights","item":`${BASE_URL}/blog`});
    items.push({"@type":"ListItem","position":3,"name":getPageMeta(path).label || dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  } else items.push({"@type":"ListItem","position":2,"name":dgjPageLabel(path),"item":`${BASE_URL}${path}`});
  return JSON.stringify({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":items});
}
function generatePageSchema(urlPath, meta) {
  return JSON.stringify({"@context":"https://schema.org","@type":meta.pageType||"WebPage","@id":`${meta.canonical}#webpage`,"url":meta.canonical,"name":meta.title,"description":meta.description,"isPartOf":{"@id":`${BASE_URL}/#website`},"about":{"@type":"Thing","name":meta.label||"International Careers"},"publisher":{"@id":`${BASE_URL}/#organization`},"inLanguage":"en"});
}
export function injectMetaTags(html, urlPath) {
  const meta=getPageMeta(urlPath), titleText=dgjEscapeText(meta.title), titleAttr=dgjEscapeMeta(meta.title), descAttr=dgjEscapeMeta(meta.description), canonicalAttr=dgjEscapeMeta(meta.canonical), robotsAttr=dgjEscapeMeta(meta.robots||DGJ_BRAND_CONTRACT.indexRobots);
  html=html.replace(/<title>[^<]*<\/title>/,`<title>${titleText}</title>`);
  html=html.replace(/<meta name="description" content="[^"]*"\s*\/?>/,`<meta name="description" content="${descAttr}" />`);
  html=html.replace(/<link rel="canonical" href="[^"]*"\s*\/?>/,`<link rel="canonical" href="${canonicalAttr}" />`);
  html=html.replace(/<meta property="og:type" content="[^"]*"\s*\/?>/,`<meta property="og:type" content="${dgjEscapeMeta(meta.ogType||"website")}" />`);
  html=html.replace(/<meta property="og:title" content="[^"]*"\s*\/?>/,`<meta property="og:title" content="${titleAttr}" />`);
  html=html.replace(/<meta property="og:description" content="[^"]*"\s*\/?>/,`<meta property="og:description" content="${descAttr}" />`);
  html=html.replace(/<meta property="og:url" content="[^"]*"\s*\/?>/,`<meta property="og:url" content="${canonicalAttr}" />`);
  html=html.replace(/<meta property="og:image" content="[^"]*"\s*\/?>/,`<meta property="og:image" content="${DGJ_SOCIAL_SHARE_IMAGE}" />`);
  html=html.replace(/<meta property="og:image:width" content="[^"]*"\s*\/?>/,`<meta property="og:image:width" content="1200" />`);
  html=html.replace(/<meta property="og:image:height" content="[^"]*"\s*\/?>/,`<meta property="og:image:height" content="630" />`);
  html=html.replace(/<meta property="og:image:alt" content="[^"]*"\s*\/?>/,`<meta property="og:image:alt" content="${DGJ_SOCIAL_SHARE_ALT}" />`);
  html=html.replace(/<meta name="twitter:title" content="[^"]*"\s*\/?>/,`<meta name="twitter:title" content="${titleAttr}" />`);
  html=html.replace(/<meta name="twitter:description" content="[^"]*"\s*\/?>/,`<meta name="twitter:description" content="${descAttr}" />`);
  html=html.replace(/<meta name="twitter:image" content="[^"]*"\s*\/?>/,`<meta name="twitter:image" content="${DGJ_SOCIAL_SHARE_IMAGE}" />`);
  html=html.replace(/<meta name="twitter:image:alt" content="[^"]*"\s*\/?>/,`<meta name="twitter:image:alt" content="${DGJ_SOCIAL_SHARE_ALT}" />`);
  html=html.replace(/<meta name="robots" content="[^"]*"\s*\/?>/,`<meta name="robots" content="${robotsAttr}" />`);
  html=html.replace(/<meta name="googlebot" content="[^"]*"\s*\/?>/,`<meta name="googlebot" content="${robotsAttr}" />`);
  html=html.replace(/<meta name="bingbot" content="[^"]*"\s*\/?>/,`<meta name="bingbot" content="${robotsAttr}" />`);
  html=html.replace(/\s*<link rel="alternate" hreflang="[^"]+" href="[^"]+"\s*\/?>/g,"");
  html=html.replace(/\s*<script id="dgj-v27-page-schema"[\s\S]*?<\/script>/g,"").replace(/\s*<script id="dgj-v27-breadcrumb-schema"[\s\S]*?<\/script>/g,"");
  const hreflang=`\n    <link rel="alternate" hreflang="en" href="${canonicalAttr}" />\n    <link rel="alternate" hreflang="x-default" href="${canonicalAttr}" />`;
  const breadcrumb=generateBreadcrumbSchema(urlPath); let injections=`${hreflang}\n    <!-- DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27 -->\n    <script id="dgj-v27-page-schema" type="application/ld+json">${generatePageSchema(urlPath,meta)}</script>`;
  if(breadcrumb) injections+=`\n    <script id="dgj-v27-breadcrumb-schema" type="application/ld+json">${breadcrumb}</script>`;
  return html.replace("</head>",`${injections}\n</head>`);
}
export const DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27 = "DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27";
function dgjJobIsoDate(value) { if (!value) return null; const d=new Date(value); return Number.isNaN(d.getTime()) ? null : d.toISOString().split("T")[0]; }
function dgjSafeJsonLd(value) { return JSON.stringify(value).replace(/</g,"\\u003c").replace(/>/g,"\\u003e").replace(/&/g,"\\u0026").replace(/\u2028/g,"\\u2028").replace(/\u2029/g,"\\u2029"); }
function dgjJobDescriptionHtml(raw) {
  if (!raw || !String(raw).trim()) return null;
  let s=String(raw).replace(/<script[^>]*>[\s\S]*?<\/script>/gi,"").replace(/<style[^>]*>[\s\S]*?<\/style>/gi,"").trim();
  if (/<(p|ul|li|br)\b/i.test(s)) return s;
  return s.split(/\n{2,}/).map((p)=>`<p>${dgjEscapeText(p.replace(/\n/g," "))}</p>`).join("");
}
const DGJ_JOB_COUNTRY_ALIASES={"US":"US","USA":"US","UNITED STATES":"US","UNITED STATES OF AMERICA":"US","GB":"GB","UK":"GB","UNITED KINGDOM":"GB","GREAT BRITAIN":"GB","CA":"CA","CANADA":"CA","AU":"AU","AUSTRALIA":"AU","NZ":"NZ","NEW ZEALAND":"NZ","DE":"DE","GERMANY":"DE","FR":"FR","FRANCE":"FR","NL":"NL","NETHERLANDS":"NL","CH":"CH","SWITZERLAND":"CH","IE":"IE","IRELAND":"IE","ES":"ES","SPAIN":"ES","IT":"IT","ITALY":"IT","PT":"PT","PORTUGAL":"PT","SE":"SE","SWEDEN":"SE","NO":"NO","NORWAY":"NO","DK":"DK","DENMARK":"DK","FI":"FI","FINLAND":"FI","AT":"AT","AUSTRIA":"AT","BE":"BE","BELGIUM":"BE","PL":"PL","POLAND":"PL","CZ":"CZ","CZECH REPUBLIC":"CZ","HU":"HU","HUNGARY":"HU","RO":"RO","ROMANIA":"RO","GR":"GR","GREECE":"GR","TR":"TR","TURKEY":"TR","UA":"UA","UKRAINE":"UA","AE":"AE","UAE":"AE","UNITED ARAB EMIRATES":"AE","QA":"QA","QATAR":"QA","SA":"SA","SAUDI ARABIA":"SA","KW":"KW","KUWAIT":"KW","BH":"BH","BAHRAIN":"BH","OM":"OM","OMAN":"OM","IN":"IN","INDIA":"IN","PK":"PK","PAKISTAN":"PK","BD":"BD","BANGLADESH":"BD","LK":"LK","SRI LANKA":"LK","NP":"NP","NEPAL":"NP","AF":"AF","AFGHANISTAN":"AF","SG":"SG","SINGAPORE":"SG","MY":"MY","MALAYSIA":"MY","ID":"ID","INDONESIA":"ID","PH":"PH","PHILIPPINES":"PH","TH":"TH","THAILAND":"TH","VN":"VN","VIETNAM":"VN","JP":"JP","JAPAN":"JP","KR":"KR","SOUTH KOREA":"KR","HK":"HK","HONG KONG":"HK","ZA":"ZA","SOUTH AFRICA":"ZA","NG":"NG","NIGERIA":"NG","KE":"KE","KENYA":"KE","GH":"GH","GHANA":"GH","ET":"ET","ETHIOPIA":"ET","UG":"UG","UGANDA":"UG","TZ":"TZ","TANZANIA":"TZ","EG":"EG","EGYPT":"EG","MA":"MA","MOROCCO":"MA","BR":"BR","BRAZIL":"BR","MX":"MX","MEXICO":"MX","AR":"AR","ARGENTINA":"AR","CO":"CO","COLOMBIA":"CO","CL":"CL","CHILE":"CL","PE":"PE","PERU":"PE","BG":"BG","BULGARIA":"BG","CN":"CN","CHINA":"CN","CY":"CY","CYPRUS":"CY","EE":"EE","ESTONIA":"EE","IL":"IL","ISRAEL":"IL","LT":"LT","LITHUANIA":"LT","LU":"LU","LUXEMBOURG":"LU","RS":"RS","SERBIA":"RS","SI":"SI","SLOVENIA":"SI","SK":"SK","SLOVAKIA":"SK"};
function dgjJobCountry(raw, location) {
  const invalid=new Set(["WORLDWIDE","GLOBAL","REMOTE","ANYWHERE","INTERNATIONAL"]);
  const r=String(raw||"").trim();
  if(r){const u=r.toUpperCase(); if(invalid.has(u))return null; if(DGJ_JOB_COUNTRY_ALIASES[u])return DGJ_JOB_COUNTRY_ALIASES[u]; if(/^[A-Z]{2}$/.test(u))return u; return r;}
  const loc=String(location||"").toUpperCase();
  const keys=Object.keys(DGJ_JOB_COUNTRY_ALIASES).filter((k)=>k.length>2).sort((a,b)=>b.length-a.length);
  for(const k of keys) if(loc.includes(k)) return DGJ_JOB_COUNTRY_ALIASES[k];
  return null;
}
function dgjJobCountryDisplayName(value) {
  const v=String(value||"").trim(); if(!v)return null;
  if(/^[A-Z]{2}$/i.test(v)){try{const n=new Intl.DisplayNames(["en"],{type:"region"}).of(v.toUpperCase()); if(n&&n!==v.toUpperCase())return n;}catch{} }
  return v;
}
function dgjJobPostalAddress(job,countryCode){
  const address={"@type":"PostalAddress","addressCountry":countryCode};
  const raw=String(job.location||"").trim(); if(!raw)return address;
  const parts=raw.split(",").map((x)=>x.trim()).filter(Boolean).filter((x)=>!/^(remote|worldwide|global|anywhere|virtual|telecommute)$/i.test(x));
  const clean=parts.filter((x)=>{const u=x.toUpperCase(); const mapped=DGJ_JOB_COUNTRY_ALIASES[u]||(/^[A-Z]{2}$/.test(u)?u:null); return !mapped || mapped!==countryCode;});
  if(clean[0])address.addressLocality=clean[0]; if(clean[1])address.addressRegion=clean[1]; return address;
}
function dgjJobHasApplyPath(job) { return !!(job && (job.url || job.applyEmail || job.isEmployerPosted)); }
function dgjJobApplicationContact(job) {
  if(!job)return null;
  const contact={"@type":"ContactPoint","contactType":"Application"};
  if(job.url){try{const u=new URL(String(job.url));if(/^https?:$/.test(u.protocol))contact.url=u.href;}catch{}}
  const email=String(job.applyEmail||"").trim();if(email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))contact.email=email;
  return contact.url||contact.email?contact:null;
}
function dgjEmployerSameAs(job) {
  if(!job || !job.isEmployerPosted || !job.url) return null;
  try {
    const u=new URL(String(job.url)); if(!/^https?:$/.test(u.protocol))return null;
    const host=String(u.hostname||"").toLowerCase().replace(/^www\./,""); if(!host || host==="devglobaljobs.com" || host.endsWith(".devglobaljobs.com"))return null;
    const blocked=["linkedin.com","indeed.com","indeed.co.uk","glassdoor.com","google.com","forms.gle","docs.google.com","greenhouse.io","lever.co","myworkdayjobs.com","ashbyhq.com","remoteok.com","remotive.com","jobicy.com","arbeitnow.com","themuse.com","himalayas.app","workingnomads.com","adzuna.com","usajobs.gov","reliefweb.int","weworkremotely.com","nofluffjobs.com"];
    if(blocked.some((d)=>host===d || host.endsWith("."+d)))return null;
    const stop=new Set(["the","and","company","co","corp","corporation","inc","llc","ltd","limited","group","holdings","services","solutions","international","global","careers","jobs"]);
    const tokens=String(job.organization||"").toLowerCase().replace(/[^a-z0-9]+/g," ").split(/\s+/).filter((x)=>x.length>=3&&!stop.has(x));
    const compactHost=host.replace(/[^a-z0-9]/g,""); if(tokens.length && !tokens.some((t)=>compactHost.includes(t.replace(/[^a-z0-9]/g,""))))return null;
    return u.origin;
  } catch { return null; }
}
function dgjJobEmploymentType(raw) { const t=String(raw||"").toLowerCase().trim(); if(!t)return null; if(/full[ -]?time|permanent/.test(t))return "FULL_TIME"; if(/part[ -]?time/.test(t))return "PART_TIME"; if(/contract|freelance|consult/.test(t))return "CONTRACTOR"; if(/temporary|temp|seasonal|casual/.test(t))return "TEMPORARY"; if(/intern|trainee|apprentice/.test(t))return "INTERN"; if(/volunteer|unpaid|pro.?bono/.test(t))return "VOLUNTEER"; if(/per.?diem/.test(t))return "PER_DIEM"; return "OTHER"; }
function dgjJobIsRemote(job) { if(String(job.category||"").toLowerCase()==="remote")return true; if(/remote/i.test(String(job.workplaceType||"")))return true; return /(^|\b)(remote|work from home|work from anywhere|anywhere|worldwide|virtual|telecommute)(\b|$)/i.test(String(job.location||"")); }
function dgjJobNumbers(s){return (String(s).toLowerCase().replace(/,/g,"").match(/\d+(?:\.\d+)?\s*k?/g)||[]).map((x)=>/k\s*$/i.test(x)?parseFloat(x)*1000:parseFloat(x)).filter((n)=>Number.isFinite(n)&&n>0);}
function dgjJobSalary(job,countryCode){
  if(!job.isEmployerPosted||!job.salary)return null;
  const s=String(job.salary); let currency=null,unit=null;
  if(/\bUSD\b|US\$/i.test(s))currency="USD"; else if(/\bEUR\b|€/i.test(s))currency="EUR"; else if(/\bGBP\b|£/i.test(s))currency="GBP"; else if(/\bCAD\b|CA\$/i.test(s))currency="CAD"; else if(/\bAUD\b|A\$/i.test(s))currency="AUD"; else if(/\bQAR\b/i.test(s))currency="QAR"; else if(/\bAED\b/i.test(s))currency="AED"; else if(/\bSAR\b/i.test(s))currency="SAR"; else if(/\bCHF\b/i.test(s))currency="CHF"; else if(/\bINR\b|₹/i.test(s))currency="INR"; else if(/\bPKR\b/i.test(s))currency="PKR"; else if(/\bSGD\b/i.test(s))currency="SGD";
  if(/per\s*hour|\/\s*(hr|hour)\b|hourly/i.test(s))unit="HOUR"; else if(/per\s*day|\/\s*day\b|daily/i.test(s))unit="DAY"; else if(/per\s*week|\/\s*(wk|week)\b|weekly/i.test(s))unit="WEEK"; else if(/per\s*month|\/\s*(mo|month)\b|monthly/i.test(s))unit="MONTH"; else if(/per\s*year|\/\s*(yr|year)\b|annual|annum|yearly/i.test(s))unit="YEAR";
  if(!currency||!unit)return null; const nums=dgjJobNumbers(s); if(!nums.length)return null; const value={"@type":"QuantitativeValue","unitText":unit}; if(nums.length>=2){value.minValue=Math.min(nums[0],nums[1]);value.maxValue=Math.max(nums[0],nums[1]);} else value.value=nums[0]; return {"@type":"MonetaryAmount","currency":currency,"value":value};
}
export function buildGoogleJobPostingSchema(job, canonical) {
  if(!job||!job.id||!job.title||!job.organization)return null; if(!dgjJobHasApplyPath(job))return null;
  const description=dgjJobDescriptionHtml(job.description),datePosted=dgjJobIsoDate(job.postedAt); if(!description||!datePosted)return null;
  const validThrough=dgjJobIsoDate(job.closingDate); if(validThrough && new Date(validThrough+"T23:59:59Z").getTime()<Date.now())return null;
  const country=dgjJobCountry(job.country,job.location),isRemote=dgjJobIsRemote(job);
  const hiringOrganization={"@type":"Organization","name":String(job.organization).trim()}; const employerSameAs=dgjEmployerSameAs(job); if(employerSameAs)hiringOrganization.sameAs=employerSameAs;
  const schema={"@context":"https://schema.org","@type":"JobPosting","@id":`${canonical}#jobposting`,"title":String(job.title).trim(),"description":description,"datePosted":datePosted,"hiringOrganization":hiringOrganization,"identifier":{"@type":"PropertyValue","name":String(job.organization).trim(),"value":String(job.sourceId||job.id)},"url":canonical,"directApply":false};
  const employmentType=dgjJobEmploymentType(job.jobType); if(employmentType)schema.employmentType=employmentType; if(validThrough)schema.validThrough=validThrough;
  if(isRemote){if(!country)return null; schema.jobLocationType="TELECOMMUTE"; schema.applicantLocationRequirements={"@type":"Country","name":dgjJobCountryDisplayName(country)};}
  else {if(!country)return null; schema.jobLocation={"@type":"Place","address":dgjJobPostalAddress(job,country)};}
  const baseSalary=dgjJobSalary(job,country); if(baseSalary)schema.baseSalary=baseSalary; const applicationContact=dgjJobApplicationContact(job); if(applicationContact)schema.applicationContact=applicationContact; return schema;
}
function injectJobDetailMeta(html, job) {
  const BASE=BASE_URL, canonical=`${BASE}/jobs/detail/${job.id}`, title=`${job.title} at ${job.organization} | Dev Global Jobs`;
  const descRaw=job.description?String(job.description).replace(/<[^>]*>/g,"").replace(/\s+/g," ").trim():""; const description=descRaw.length>160?descRaw.substring(0,157).replace(/\s+\S*$/,"")+"...":descRaw||`Review ${job.title} at ${job.organization} on Dev Global Jobs.`; const safe=(s)=>dgjEscapeMeta(s);
  const validThrough=dgjJobIsoDate(job.closingDate), expired=!!(validThrough && new Date(validThrough+"T23:59:59Z").getTime()<Date.now()); const robots=expired?"noindex, nofollow":DGJ_BRAND_CONTRACT.indexRobots;
  html=html.replace(/<title>[^<]*<\/title>/,`<title>${dgjEscapeText(title)}</title>`).replace(/<meta name="description" content="[^"]*"\s*\/?>/,`<meta name="description" content="${safe(description)}" />`).replace(/<link rel="canonical" href="[^"]*"\s*\/?>/,`<link rel="canonical" href="${canonical}" />`).replace(/<meta property="og:title" content="[^"]*"\s*\/?>/,`<meta property="og:title" content="${safe(title)}" />`).replace(/<meta property="og:description" content="[^"]*"\s*\/?>/,`<meta property="og:description" content="${safe(description)}" />`).replace(/<meta property="og:url" content="[^"]*"\s*\/?>/,`<meta property="og:url" content="${canonical}" />`).replace(/<meta property="og:type" content="[^"]*"\s*\/?>/,`<meta property="og:type" content="article" />`).replace(/<meta property="og:image" content="[^"]*"\s*\/?>/,`<meta property="og:image" content="${DGJ_SOCIAL_SHARE_IMAGE}" />`).replace(/<meta property="og:image:width" content="[^"]*"\s*\/?>/,`<meta property="og:image:width" content="1200" />`).replace(/<meta property="og:image:height" content="[^"]*"\s*\/?>/,`<meta property="og:image:height" content="630" />`).replace(/<meta property="og:image:alt" content="[^"]*"\s*\/?>/,`<meta property="og:image:alt" content="${DGJ_SOCIAL_SHARE_ALT}" />`).replace(/<meta name="twitter:title" content="[^"]*"\s*\/?>/,`<meta name="twitter:title" content="${safe(title)}" />`).replace(/<meta name="twitter:description" content="[^"]*"\s*\/?>/,`<meta name="twitter:description" content="${safe(description)}" />`).replace(/<meta name="twitter:image" content="[^"]*"\s*\/?>/,`<meta name="twitter:image" content="${DGJ_SOCIAL_SHARE_IMAGE}" />`).replace(/<meta name="twitter:image:alt" content="[^"]*"\s*\/?>/,`<meta name="twitter:image:alt" content="${DGJ_SOCIAL_SHARE_ALT}" />`).replace(/<meta name="robots" content="[^"]*"\s*\/?>/,`<meta name="robots" content="${robots}" />`).replace(/<meta name="googlebot" content="[^"]*"\s*\/?>/,`<meta name="googlebot" content="${robots}" />`);
  html=html.replace(/\s*<link rel="alternate" hreflang="[^"]+" href="[^"]+"\s*\/?>/g,"").replace(/\s*<script[^>]+id="(?:dgj-jobposting-v27|job-jsonld|dgj-job-graph|dgj-jobposting-schema)"[\s\S]*?<\/script>/g,"");
  const breadcrumb={"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":BASE},{"@type":"ListItem","position":2,"name":"All Jobs","item":`${BASE}/jobs/all`},{"@type":"ListItem","position":3,"name":job.title,"item":canonical}]}; const jobSchema=expired?null:buildGoogleJobPostingSchema(job,canonical);
  let extra=`\n    <link rel="alternate" hreflang="en" href="${canonical}" />\n    <link rel="alternate" hreflang="x-default" href="${canonical}" />\n    <!-- DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27 | DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27 -->\n`;
  if(jobSchema)extra+=`    <script id="dgj-jobposting-v27" type="application/ld+json">${dgjSafeJsonLd(jobSchema)}</script>\n`; extra+=`    <script id="dgj-job-breadcrumb-v27" type="application/ld+json">${dgjSafeJsonLd(breadcrumb)}</script>\n`;
  return html.replace("</head>",`${extra}</head>`);
}
