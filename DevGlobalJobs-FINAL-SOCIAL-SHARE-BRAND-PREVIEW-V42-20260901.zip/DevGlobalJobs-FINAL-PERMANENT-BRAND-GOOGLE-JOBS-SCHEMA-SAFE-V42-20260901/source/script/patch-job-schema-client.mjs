import fs from "fs";import path from "path";
const root=process.cwd(),assets=path.join(root,"dist","public","assets");
function die(s){console.error("DGJ GOOGLE JOBS V27 PATCH FAIL:",s);process.exit(1)}
if(!fs.existsSync(assets))die("dist/public/assets missing");
const files=fs.readdirSync(assets).filter(f=>/^index-.*\.js$/.test(f));let patched=0,already=0;
for(const f of files){const p=path.join(assets,f);let s=fs.readFileSync(p,"utf8");if(s.includes("DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27")){already++;continue;}if(!s.includes('document.getElementById("job-jsonld")'))continue;
 const start=s.indexOf('x.useEffect(()=>{if(!o)return;document.title='); const endToken='},[o]);const d=x.useCallback'; const end=s.indexOf(endToken,start);
 if(start<0||end<0)die(`legacy job SEO found in ${f} but safe patch anchors changed`);
 const rep='x.useEffect(()=>{if(!o)return;return window.DGJGoogleJobsV27&&window.DGJGoogleJobsV27.sync?window.DGJGoogleJobsV27.sync(o):void 0},[o]);const d=x.useCallback';
 s=s.slice(0,start)+rep+s.slice(end+endToken.length)+'\n;window.__DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27__="DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27";\n';fs.writeFileSync(p,s);patched++;
}
if(!patched&&!already)die("no application bundle with known job SEO anchors found");
console.log(`PASS: Google Jobs V27 client bundle gate patched=${patched} already=${already}`);
