import fs from "node:fs";
import path from "node:path";

const root=process.cwd();
const file=path.join(root,"dist","index.cjs");
if(!fs.existsSync(file)) throw new Error(`Missing built runtime: ${file}`);
let s=fs.readFileSync(file,"utf8");
const routeStart=s.indexOf('app2.get("/sitemap-jobs-:param.xml"');
const routeEnd=s.indexOf('app2.get("/sitemap.xml"',routeStart);
if(routeStart<0||routeEnd<0) throw new Error("Sitemap route block not found in built runtime");
let block=s.slice(routeStart,routeEnd);
const legacy=[
  ['const indexableJobs = latestJobs.filter((j) => j.isEmployerPosted);','const indexableJobs = latestJobs;'],
  ['const indexableJobs = jobIds.filter((j) => j.isEmployerPosted);','const indexableJobs = jobIds;'],
  ['const indexableJobs = allJobIds.filter((j) => j.isEmployerPosted);','const indexableJobs = allJobIds;'],
];
for(const [from,to] of legacy){ if(block.includes(from)) block=block.replace(from,to); }
for(const [,to] of legacy){ if(!block.includes(to)) throw new Error(`Expected sitemap indexing statement missing after patch: ${to}`); }
if(/indexableJobs\s*=\s*(latestJobs|jobIds|allJobIds)\.filter\(\(j\)\s*=>\s*j\.isEmployerPosted\)/.test(block)) throw new Error("Employer-only sitemap filter still present");
s=s.slice(0,routeStart)+block+s.slice(routeEnd);
fs.writeFileSync(file,s);
console.log("PASS: job sitemap indexing includes all canonical job-detail pages.");
