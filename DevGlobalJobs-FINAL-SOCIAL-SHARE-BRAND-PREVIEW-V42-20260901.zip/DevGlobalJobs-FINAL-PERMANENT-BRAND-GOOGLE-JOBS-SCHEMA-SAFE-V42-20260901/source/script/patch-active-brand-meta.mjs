import fs from "fs";
import path from "path";
const root=process.cwd();
function die(s){console.error("DGJ ACTIVE BRAND META PATCH FAIL:",s);process.exit(1)}
function read(p){if(!fs.existsSync(p))die(`missing ${p}`);return fs.readFileSync(p,"utf8")}
const c=JSON.parse(read(path.join(root,"brand-lock","brand-contract.json")));
const target=c.staticRoutes?.["/jobs/sponsored"];
if(!target||!target.title?.startsWith("Sponsored Jobs")||target.title.includes("Featured"))die("invalid Sponsored contract semantics");
const index=read(path.join(root,"dist","public","index.html"));
const srcs=[...index.matchAll(/<script[^>]+src=["']([^"']*\/assets\/index-[^"']+\.js)["'][^>]*>/gi)].map(m=>m[1]);
if(srcs.length!==1)die(`expected exactly one active SPA index bundle, found ${srcs.length}`);
const p=path.join(root,"dist","public",srcs[0].replace(/^\//,''));
let s=read(p);
const staleTitles=[
  "Sponsored Jobs | Employer-Promoted Roles | Dev Global Jobs",
  "Sponsored Jobs Jobs | International Careers - Dev Global Jobs",
  "Featured Jobs | Global Opportunities | Dev Global Jobs"
];
const staleDescs=[
  "Explore sponsored jobs promoted by employers for added visibility. Discover priority roles across industries, locations and career levels on Dev Global Jobs."
];
let changed=0;
for(const x of staleTitles){if(s.includes(x)){s=s.split(x).join(target.title);changed++;}}
for(const x of staleDescs){if(s.includes(x)){s=s.split(x).join(target.description);changed++;}}
for(const x of staleTitles)if(s.includes(x))die(`stale Sponsored title remains: ${x}`);
for(const x of staleDescs)if(s.includes(x))die("stale Sponsored description remains");
// The currently reviewed SPA contains category metadata. Keep its Sponsored fallback synchronized
// with the same source-of-truth contract used by SSR and the head MutationObserver.
if(!s.includes(target.title))die("active SPA does not contain contract Sponsored title after patch");
if(!s.includes(target.description))die("active SPA does not contain contract Sponsored description after patch");
fs.writeFileSync(p,s);
console.log(`PASS: active SPA Sponsored metadata synchronized from contract; replacements=${changed}`);
