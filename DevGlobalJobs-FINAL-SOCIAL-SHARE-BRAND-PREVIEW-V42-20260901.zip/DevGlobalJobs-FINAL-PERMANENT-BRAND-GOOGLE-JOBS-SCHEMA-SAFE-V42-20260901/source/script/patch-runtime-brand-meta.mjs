import fs from "fs";
import path from "path";
const root=process.cwd();
const p=path.join(root,"dist","index.cjs");
let s=fs.readFileSync(p,"utf8");
function fail(msg){console.error("DGJ V27 RUNTIME META PATCH FAIL:",msg);process.exit(1)}
const postTitle="Post a Job | Reach International Talent | Dev Global Jobs";
const postDesc="Post your vacancy on Dev Global Jobs, build employer visibility and connect with professionals exploring careers across international markets.";
const signTitle="Sign In or Create Account | Dev Global Jobs";

// Signed-out /post-job auth gate must carry the same public contract metadata.
if(!s.includes(postTitle)){
  const old='title: "Post a Job | Dev Global Jobs",';
  if(!s.includes(old)) fail("post-job title anchor changed");
  s=s.replace(old,'title: '+JSON.stringify(postTitle)+',\n      description: '+JSON.stringify(postDesc)+',\n      canonical: "https://devglobaljobs.com/post-job",\n      robots: "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1",');
}
// Signed-in /post-job branch must pass static HTML through the contract resolver.
const direct='return res.status(200).send(import_fs3.readFileSync(idxPath, "utf-8"));';
const injected='return res.status(200).send(injectMetaTags(import_fs3.readFileSync(idxPath, "utf-8"), "/post-job"));';
if(!s.includes(injected)){
  if(!s.includes(direct)) fail("post-job signed-in branch anchor changed");
  s=s.replace(direct,injected);
}
// /sign-in remains private/noindex but uses one stable professional title in the HTML response.
if(!s.includes('title: "Sign In or Create Account | Dev Global Jobs"')){
  const conditional='title: initialMode === "signup" ? "Create Account | Dev Global Jobs" : "Sign In | Dev Global Jobs",';
  if(!s.includes(conditional)) fail("sign-in title anchor changed");
  s=s.replace(conditional,'title: "Sign In or Create Account | Dev Global Jobs",');
}
fs.writeFileSync(p,s);
console.log("PASS: runtime special-route brand metadata patched and verified");
