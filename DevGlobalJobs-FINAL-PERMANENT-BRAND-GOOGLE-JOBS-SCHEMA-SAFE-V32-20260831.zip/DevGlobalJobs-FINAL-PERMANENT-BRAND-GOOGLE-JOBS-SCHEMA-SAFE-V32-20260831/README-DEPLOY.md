# Dev Global Jobs V32 Final Permanent Brand + Google Jobs Schema Safe Release

V32 is the final schema-preservation-corrected deployment release for the permanent International Careers source-of-truth brand contract and factual Google `JobPosting` schema lock.

## V32 correction

V32 fixes the exact final blocker that stopped the previous package safety check: `hiringOrganization.sameAs` support is restored without copying an imported job-board or ATS URL into employer identity. `sameAs` is emitted only for employer-posted jobs when the supplied destination is a credible employer-owned domain; otherwise it is omitted, which is safer than publishing false organization data.

V32 also keeps the factual Google Jobs safeguards already introduced in the prior reviewed package: no synthetic posting date, no synthetic 30-day expiry, no guessed Worldwide country, no guessed salary currency/pay period, and no `JobPosting` on list/category/content pages. A job also needs a usable application path before active `JobPosting` markup is emitted.

The deployment route validator uses Python's HTML parser, so apostrophes such as `beginner's` in double-quoted meta descriptions do not create false metadata mismatches.

## Permanent brand architecture

- Dev Global Jobs remains locked as an International Careers Platform.
- `/jobs/all`, `/jobs/international`, and `/jobs/sponsored` remain separate intents.
- Featured remains a placement/status only and is not turned into a fake SEO route.
- Static routes, industry/category routes, countries, cities, tools, resources, youth, employer/developer pages, known articles, canonical URLs, robots rules, Open Graph/Twitter metadata, and source/build guards remain contract-backed.
- Unknown routes default to noindex until deliberately added to the contract.

## Google Jobs schema policy

`JobPosting` is limited to eligible individual `/jobs/detail/{id}` pages. Eligible pages require a real job title, real complete description, original stored posting date, real hiring organization, and a factual location signal. Physical jobs require `jobLocation.address.addressCountry`. Fully remote jobs use `jobLocationType: TELECOMMUTE` and a factual `applicantLocationRequirements` country. `validThrough` appears only when a real closing date exists. Salary markup appears only when factual employer-posted salary data has a recognized currency, numeric amount, and pay period. Expired or materially incomplete jobs do not emit active `JobPosting` markup. Jobs without a usable application path (external URL, apply email, or the internal employer-posted flow) also do not emit active `JobPosting` markup.

This matches Google's core JobPosting requirements and remote-job guidance, but Google controls crawling, policy review, indexing, ranking, and final inclusion.

## Deployment safety

`hiringOrganization.sameAs` support is preserved conservatively: it is emitted only for employer-posted jobs when the supplied HTTPS/HTTP destination looks like the employer's own domain. Imported job-board/ATS/form URLs are not mislabeled as employer identity URLs. This preserves the useful V19 behavior without fabricating organization identity.

The included `deploy-final-safe.sh` accepts only the recognized V19 or exact V27-partial baseline, backs up every touched file, installs the source/build lock idempotently, atomically installs the reviewed runtime, reloads only the main PM2 app, audits all locked public metadata, checks private noindex, validates sampled live JobPosting JSON-LD, verifies job sitemap shards, and automatically rolls back on any post-mutation failure. It does not run `npm build`, `drizzle-kit push`, a database migration, or a full-site replacement.


## V32 packaging correction

V32 removes transient Python bytecode from the release payload and rebuilds the SHA-256 manifest after all offline validation, so the payload manifest is reproducible and self-consistent. Runtime brand logic remains contract-backed; the Google Jobs schema layer is V32-corrected for conservative employer `sameAs` preservation and the application-path eligibility guard.

## V32 deployment-gate correction

V32 fixes the only runtime SAFE STOP seen in V31. The brand verifier now audits the **single active SPA bundle referenced by `dist/public/index.html`** instead of scanning historical hashed `index-*.js` files that can remain on disk after older releases. Old unused bundles therefore cannot create a false brand failure, while the currently served bundle is still strictly blocked if it contains `Jobs Jobs` or the legacy category-title formula.

The JobPosting implementation itself is unchanged from the reviewed V31 schema-safe runtime. V32 changes the verifier/deployment gate, not factual job schema semantics.
