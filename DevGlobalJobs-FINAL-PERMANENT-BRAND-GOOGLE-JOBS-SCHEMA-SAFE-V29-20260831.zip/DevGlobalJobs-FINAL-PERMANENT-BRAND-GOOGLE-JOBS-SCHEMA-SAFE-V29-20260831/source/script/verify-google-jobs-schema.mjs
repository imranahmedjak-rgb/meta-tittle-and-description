import fs from "fs";import path from "path";
const root=process.cwd(),dist=process.argv.includes("--dist");
function die(s){console.error("DGJ GOOGLE JOBS V27 VERIFY FAIL:",s);process.exit(1)}
function read(p){if(!fs.existsSync(p))die(`missing ${p}`);return fs.readFileSync(p,"utf8")}
const server=read(path.join(root,"server","brandSeo.ts"));
for(const need of ["DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27","buildGoogleJobPostingSchema","datePosted","hiringOrganization","jobLocationType","applicantLocationRequirements","addressCountry","directApply","dgjJobPostalAddress","dgjJobCountryDisplayName","dgjSafeJsonLd","\"SERBIA\":\"RS\"","\"BULGARIA\":\"BG\"","\"CHINA\":\"CN\"","\"SLOVAKIA\":\"SK\""])if(!server.includes(need))die(`server schema missing ${need}`);
for(const bad of ['"name":"Worldwide"','Date.now() + 30','new Date()).toISOString().split("T")[0]','applicationContact','else if(/\\$/.test(s))currency='])if(server.includes(bad))die(`unsafe schema pattern ${bad}`);

if(!server.includes('dgjSafeJsonLd(jobSchema)'))die('safe JSON-LD serialization missing');
if(!server.includes('if(!description||!datePosted)return null'))die('required date/description guard missing');
if(!server.includes('if(validThrough && new Date(validThrough+"T23:59:59Z").getTime()<Date.now())return null'))die('expired guard missing');
if(!server.includes('if(!job.isEmployerPosted||!job.salary)return null'))die('salary provenance guard missing');
if(!server.includes('if(isRemote){if(!country)return null'))die('remote applicant-country guard missing');
if(!server.includes('else {if(!country)return null'))die('physical addressCountry guard missing');
const client=read(path.join(root,"client","public","dgj-google-jobs-v27.js"));
for(const need of ['DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27','if(!d||!posted)return null','applicantLocationRequirements','addressCountry','function countryName(','\'SERBIA\':\'RS\'','\'BULGARIA\':\'BG\'','\'CHINA\':\'CN\'','\'SLOVAKIA\':\'SK\'',"'name':countryName(c)"])if(!client.includes(need))die(`client companion missing ${need}`);
if(client.includes("name:'Worldwide'")||client.includes("else if(/\\$/.test(s))"))die('client contains fake Worldwide or guessed dollar currency');
const idx=read(path.join(root,"client","index.html")); if(!idx.includes('/dgj-google-jobs-v27.js'))die('source job schema loader missing'); if(idx.includes('dgj-job-seo-engine'))die('legacy inline job SEO engine remains');
if(dist){const di=read(path.join(root,'dist','public','index.html'));if(!di.includes('/dgj-google-jobs-v27.js')||di.includes('dgj-job-seo-engine'))die('built index schema lock invalid');const ds=read(path.join(root,'dist','index.cjs'));if(!ds.includes('DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27')||!ds.includes('id="dgj-jobposting-v27"'))die('built server schema marker missing');const assets=path.join(root,'dist','public','assets');const apps=fs.readdirSync(assets).filter(f=>/^index-.*\.js$/.test(f)).map(f=>read(path.join(assets,f)));if(!apps.some(s=>s.includes('DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27')))die('built SPA patch marker missing');if(apps.some(s=>s.includes('document.getElementById("job-jsonld")')))die('legacy React JobPosting generator remains');}
console.log(`PASS: DGJ Google Jobs schema lock V27 verified${dist?' including built runtime':''}.`);
