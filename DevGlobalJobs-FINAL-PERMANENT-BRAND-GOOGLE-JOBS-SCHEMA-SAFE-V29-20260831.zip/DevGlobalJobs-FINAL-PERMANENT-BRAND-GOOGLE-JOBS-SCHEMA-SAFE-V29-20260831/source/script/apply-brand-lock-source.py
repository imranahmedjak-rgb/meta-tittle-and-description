#!/usr/bin/env python3
from pathlib import Path
import json,re,shutil,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '/var/www/devglobaljobs').resolve()
pkg=Path(__file__).resolve().parents[2]
src=pkg/'source'
required=[root/'server/seoMeta.ts',root/'client/index.html',root/'package.json']
for p in required:
    if not p.exists(): raise SystemExit(f'SAFE STOP: source file missing: {p}')
seo=(root/'server/seoMeta.ts').read_text(encoding='utf-8',errors='ignore')
for anchor in ['injectMetaTags','injectJobDetailMeta']:
    if anchor not in seo: raise SystemExit(f'SAFE STOP: unexpected server/seoMeta.ts; missing {anchor}')
# Copy authoritative source files.
for rel in ['server/brandSeo.ts','client/public/dgj-brand-contract-v27.js','client/public/dgj-brand-lock.js','client/public/brand-contract.json','client/public/llms.txt','script/verify-brand-lock.mjs','script/sync-brand-contract.mjs','client/public/dgj-google-jobs-v27.js','script/patch-job-schema-client.mjs','script/verify-google-jobs-schema.mjs','script/patch-runtime-brand-meta.mjs']:
    a=src/rel;b=root/rel;b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)
(root/'brand-lock').mkdir(parents=True,exist_ok=True)
shutil.copy2(pkg/'brand-lock/brand-contract.json',root/'brand-lock/brand-contract.json')
shutil.copy2(pkg/'brand-lock/BRAND-CONTRACT.sha256',root/'brand-lock/BRAND-CONTRACT.sha256')
# Stable server facade: all future server metadata resolves from the contract-backed brandSeo module.
(root/'server/seoMeta.ts').write_text('''// DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27\n// Metadata is contract-backed. Update brand-lock/brand-contract.json deliberately, then run the verifier.\nexport { DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27, getPageMeta, injectMetaTags, generateBreadcrumbSchema, injectJobDetailMeta } from "./brandSeo";\n''',encoding='utf-8')
# Patch source index without replacing unrelated application HTML.
ip=root/'client/index.html';html=ip.read_text(encoding='utf-8',errors='ignore')
if '<head' not in html or '</head>' not in html: raise SystemExit('SAFE STOP: malformed client/index.html')
# Remove legacy subscription/contribution loader if old source still contains it.
html=re.sub(r'\s*<script[^>]+news\.google\.com/swg/js/v1/swg-basic\.js[^>]*></script>\s*<script>[\s\S]*?SWG_BASIC[\s\S]*?</script>','',html,flags=re.I)
html=re.sub(r'\s*<meta\s+name=["\']keywords["\'][^>]*>','',html,flags=re.I)
html=re.sub(r'\s*<script id=["\']dgj-job-seo-engine["\']>[\s\S]*?</script>','',html,flags=re.I)
html=re.sub(r'\s*<script[^>]+dgj-google-jobs-v(?:24|25|26|27)\.js[^>]*></script>','',html,flags=re.I)
html=re.sub(r'\s*<script[^>]+dgj-brand-contract-v(?:23|24|25|26|27)\.js[^>]*></script>','',html,flags=re.I)
html=html.replace('EmploymentAgency','Organization')
# Homepage fallback metadata.
TITLE='Dev Global Jobs | International Jobs, Remote Work & Global Careers'
DESC='Find international jobs, remote work, visa sponsored opportunities and global careers. Explore thousands of jobs worldwide and take the next step with Dev Global Jobs.'
html=re.sub(r'<title>[\s\S]*?</title>',f'<title>{TITLE.replace("&","&amp;")}</title>',html,count=1,flags=re.I)
def set_meta(h,selector,value):
    if selector=='description':
        pat=r'<meta\s+name=["\']description["\'][^>]*>'
        rep=f'<meta name="description" content="{value}" />'
    else:
        attr,name=selector.split(':',1); pat=rf'<meta\s+{attr}=["\']{re.escape(name)}["\'][^>]*>'; rep=f'<meta {attr}="{name}" content="{value}" />'
    if re.search(pat,h,re.I): return re.sub(pat,rep,h,count=1,flags=re.I)
    return h.replace('</head>',f'    {rep}\n</head>')
html=set_meta(html,'description',DESC)
for sel,val in [('property:og:title',TITLE),('property:og:description',DESC),('property:og:url','https://devglobaljobs.com'),('name:twitter:title',TITLE),('name:twitter:description',DESC),('name:robots','index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'),('name:googlebot','index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'),('name:bingbot','index, follow, max-image-preview:large, max-snippet:-1')]: html=set_meta(html,sel,val)
html=re.sub(r'<meta\s+name=["\']viewport["\'][^>]*>', '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5, viewport-fit=cover" />',html,count=1,flags=re.I)
if not re.search(r'<link\s+rel=["\']canonical["\']',html,re.I): html=html.replace('</head>','    <link rel="canonical" href="https://devglobaljobs.com" />\n</head>')
else: html=re.sub(r'<link\s+rel=["\']canonical["\'][^>]*>', '<link rel="canonical" href="https://devglobaljobs.com" />',html,count=1,flags=re.I)
# Replace generic WebSite/Organization JSON-LD blocks with clean brand entities.
html=re.sub(r'\s*<script\s+type=["\']application/ld\+json["\']>[\s\S]*?"@type"\s*:\s*"WebSite"[\s\S]*?</script>','',html,count=1,flags=re.I)
html=re.sub(r'\s*<script\s+type=["\']application/ld\+json["\']>[\s\S]*?"@type"\s*:\s*"Organization"[\s\S]*?</script>','',html,count=1,flags=re.I)
schema='''
    <meta name="dgj-brand-lock" content="DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27" />
    <script id="dgj-website-schema-v27" type="application/ld+json">{"@context":"https://schema.org","@type":"WebSite","@id":"https://devglobaljobs.com/#website","name":"Dev Global Jobs","alternateName":"DevGlobalJobs","url":"https://devglobaljobs.com","description":"International careers platform for global job discovery, remote work, jobs by category, industry, country and city, career tools, resources and employer hiring access.","inLanguage":"en","publisher":{"@id":"https://devglobaljobs.com/#organization"}}</script>
    <script id="dgj-organization-schema-v27" type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","@id":"https://devglobaljobs.com/#organization","name":"Dev Global Jobs","url":"https://devglobaljobs.com","logo":{"@type":"ImageObject","url":"https://devglobaljobs.com/logo.png"},"description":"Dev Global Jobs is an international careers platform bringing together global job discovery, remote opportunities, country and city job pages, career tools, resources and employer hiring access.","areaServed":"Worldwide","knowsAbout":["International Careers","Global Job Search","Remote Work","Jobs by Country","Jobs by City","Career Development","Work Visas","Salary Research","Resume Preparation","Interview Preparation","International Hiring"],"parentOrganization":{"@type":"Organization","name":"Trend Nova World Limited","url":"https://trendnovaworld.com"}}</script>
    <script id="dgj-brand-contract-v27" src="/dgj-brand-contract-v27.js"></script>
    <script id="dgj-brand-lock-loader-v27" src="/dgj-brand-lock.js"></script>
'''
# Remove any previous source lock loader then inject.
html=re.sub(r'\s*<meta\s+name=["\']dgj-brand-lock["\'][^>]*>','',html,flags=re.I)
html=re.sub(r'\s*<script[^>]+id=["\']dgj-website-schema-v27["\'][\s\S]*?</script>','',html,flags=re.I)
html=re.sub(r'\s*<script[^>]+id=["\']dgj-organization-schema-v27["\'][\s\S]*?</script>','',html,flags=re.I)
html=re.sub(r'\s*<script[^>]+id=["\']dgj-brand-contract-v27["\'][^>]*></script>','',html,flags=re.I)
html=re.sub(r'\s*<script[^>]+id=["\']dgj-google-jobs-v27-loader["\'][^>]*></script>','',html,flags=re.I)
html=re.sub(r'\s*<script[^>]+dgj-brand-lock\.js[^>]*></script>','',html,flags=re.I)
html=html.replace('</head>',schema+'    <script id="dgj-google-jobs-v27-loader" src="/dgj-google-jobs-v27.js"></script>\n  </head>')
ip.write_text(html,encoding='utf-8')
# Patch package lifecycle hooks. prebuild syncs the one contract into client/public; postbuild verifies generated output.
pp=root/'package.json';data=json.loads(pp.read_text(encoding='utf-8'));scripts=data.setdefault('scripts',{})
def chain(name,cmd,before=False):
    old=scripts.get(name,'').strip()
    if cmd in old:return
    scripts[name]=(cmd+' && '+old if before and old else old+' && '+cmd if old else cmd)
chain('prebuild','node script/sync-brand-contract.mjs',before=True)
guard_cmds={
    'node script/patch-runtime-brand-meta.mjs',
    'node script/patch-job-schema-client.mjs',
    'node script/verify-brand-lock.mjs --dist',
    'node script/verify-google-jobs-schema.mjs --dist',
}
old_parts=[part.strip() for part in scripts.get('postbuild','').split('&&') if part.strip()]
old_parts=[part for part in old_parts if part not in guard_cmds]
scripts['postbuild']=' && '.join([
    'node script/patch-runtime-brand-meta.mjs',
    'node script/patch-job-schema-client.mjs',
    *old_parts,
    'node script/verify-brand-lock.mjs --dist',
    'node script/verify-google-jobs-schema.mjs --dist',
])
scripts['jobs:schema:verify']='node script/verify-google-jobs-schema.mjs'
scripts['brand:verify']='node script/verify-brand-lock.mjs'
scripts['brand:audit']='node script/verify-brand-lock.mjs --dist'
pp.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
# Robots: retain existing rules; surface machine-readable identity without blocking crawlers.
rp=root/'client/public/robots.txt'
if rp.exists():
    r=rp.read_text(encoding='utf-8',errors='ignore')
    if 'llms.txt' not in r:r=r.rstrip()+'\n\n# Machine-readable platform identity\n# https://devglobaljobs.com/llms.txt\n# https://devglobaljobs.com/brand-contract.json\n'
    rp.write_text(r,encoding='utf-8')
print('PASS: source-of-truth brand lock installed into application source.')
