# Dev Global Jobs V28 Final Permanent Brand + Google Jobs Schema Safe Release

This package is the corrected final deployment wrapper for the permanent International Careers source-of-truth brand contract and the factual Google JobPosting schema lock.

## What V28 fixes

- Keeps the permanent brand contract as the single source of truth.
- Preserves the separate intent of `/jobs/all`, `/jobs/international`, and `/jobs/sponsored`.
- Keeps Featured as a placement/status only, not a separate SEO page.
- Adds an explicit professional display-name registry for all 50 routed city pages (including `Washington, DC`).
- Keeps Google `JobPosting` markup only on eligible individual `/jobs/detail/{id}` pages.
- Validates all 45 static public routes, 17 country routes, 50 city routes, and 32 locked article routes after deployment.
- Makes the source installer idempotent: running it again cannot duplicate brand/schema loaders.
- Fixes the V27 city-check false stop caused by `pipefail` + `grep -q` SIGPIPE behavior.
- Fixes rollback safety: any V28 failure after mutation restores the exact pre-V28 runtime and source files.
- Can safely start from either the exact successful V19 baseline or the exact V27 partial baseline left by the prior SAFE STOP.

## Google Jobs schema policy

The schema generator follows a factual-only policy. Eligible job pages require a real title, full description, original `datePosted`, hiring organization, and a real location signal. Physical jobs include `jobLocation.address.addressCountry`. Fully remote jobs use `jobLocationType: TELECOMMUTE` plus a factual `applicantLocationRequirements` country. `validThrough` is emitted only when a real closing date exists. Salary markup is emitted only for explicit employer-posted salary data with a recognized currency and pay period. Expired or materially incomplete jobs do not emit active `JobPosting` markup.

This makes eligible job pages technically suitable for Google Job Search, but Google controls crawling, indexing, policy review, and final inclusion; no package can guarantee that every job will appear.

## Deployment safety

The included `deploy-final-safe.sh` performs health checks, exact baseline detection, package checksums, source/build verification, idempotence verification, atomic runtime copy, PM2 health, all locked metadata routes, private noindex, public brand/LLM identity, live JobPosting samples, sitemap coverage, and final preservation checks. It does not run `npm build`, `drizzle-kit push`, or a full-site replacement.
