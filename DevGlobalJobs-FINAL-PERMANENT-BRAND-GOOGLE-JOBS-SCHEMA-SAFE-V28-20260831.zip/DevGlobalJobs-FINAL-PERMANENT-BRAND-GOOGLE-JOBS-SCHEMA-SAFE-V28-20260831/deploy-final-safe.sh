#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/var/www/devglobaljobs}"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-brand-googlejobs-v28-${STAMP}"
SERVER="$APP_DIR/dist/index.cjs"
INDEX="$APP_DIR/dist/public/index.html"
SPA="$APP_DIR/dist/public/assets/index-DGJ45auth-v11.js"
GJS="$APP_DIR/dist/public/assets/growth-suite.js"
GCS="$APP_DIR/dist/public/assets/growth-suite.css"
SUCCESS=0
MUTATED=0
BASELINE=""

fail(){
  echo
  echo "============================================================"
  echo "SAFE STOP: $*"
  echo "NOTHING WILL BE FORCED."
  echo "============================================================"
  exit 1
}

restore_rel(){
  local rel="$1"
  if grep -Fxq "$rel" "$BACKUP/existed.txt" 2>/dev/null; then
    mkdir -p "$(dirname "$APP_DIR/$rel")"
    cp -a "$BACKUP/files/$rel" "$APP_DIR/$rel"
  else
    rm -f "$APP_DIR/$rel"
  fi
}

rollback(){
  set +e
  if [ "$MUTATED" = "1" ] && [ -d "$BACKUP" ]; then
    echo
    echo "ROLLBACK: restoring the exact pre-V28 files..."
    while IFS= read -r rel; do
      [ -n "$rel" ] && restore_rel "$rel"
    done < "$BACKUP/touched.txt"
    pm2 reload devglobaljobs --update-env >/dev/null 2>&1 || true
    echo "ROLLBACK COMPLETE."
  fi
}

on_exit(){
  local rc=$?
  trap - EXIT
  if [ "$SUCCESS" != "1" ]; then rollback; fi
  exit "$rc"
}
trap on_exit EXIT

echo "============================================================"
echo "DEV GLOBAL JOBS"
echo "FINAL PERMANENT BRAND + GOOGLE JOBS SCHEMA SAFE V28"
echo "============================================================"

[ "$(id -u)" = "0" ] || fail "Run as root."
[ -d "$APP_DIR" ] || fail "$APP_DIR missing."
[ -f "$APP_DIR/.env" ] || fail "Production .env missing."
for x in curl python3 sha256sum node pm2 grep awk sed cp mkdir mv; do command -v "$x" >/dev/null || fail "Missing command: $x"; done

echo; echo "1/14 CURRENT PRODUCTION HEALTH"
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy."
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy."
echo "PASS: current production website healthy."

echo; echo "2/14 EXACT BASELINE DETECTION"
sha(){ sha256sum "$1" | awk '{print $1}'; }
for f in "$SERVER" "$INDEX" "$SPA" "$GJS" "$GCS"; do [ -f "$f" ] || fail "Baseline file missing: $f"; done
SERVER_SHA="$(sha "$SERVER")"; INDEX_SHA="$(sha "$INDEX")"; SPA_SHA="$(sha "$SPA")"; GJS_SHA="$(sha "$GJS")"; GCS_SHA="$(sha "$GCS")"
if [ "$SERVER_SHA" = "96c833718aedcafa5b2d5cc777a24721731e86e155300c99e2bc79891329de79" ] && \
   [ "$INDEX_SHA" = "120bd1d247779dab7c027f453bb7701f7a91b57d787ffba3033b82705fb35bfa" ] && \
   [ "$SPA_SHA" = "725d891d23a2567f0f880925d6080ea3633ded4ab67dac3178d6a33d7eebe42b" ] && \
   [ "$GJS_SHA" = "d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a" ] && \
   [ "$GCS_SHA" = "4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51" ]; then
  BASELINE="V19"
elif [ "$SERVER_SHA" = "1caf0bd60abf77ea759471bd18499dba8dd6659c31d402c7cc054d7011a0c5c3" ] && \
     [ "$INDEX_SHA" = "68c46e06e31e1547d4fc353ce066ccc52af78dc1102d0ab00172b23265c55753" ] && \
     [ "$SPA_SHA" = "bff1f8835e3aeb1be5dea39db3169a0c6a4fa2ae497dabe7a6ff8aa16a2ea352" ] && \
     [ "$GJS_SHA" = "d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a" ] && \
     [ "$GCS_SHA" = "4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51" ]; then
  for rec in \
    "17660b5d7fc13b1dcce75fa653c7409d71aa89ae188572a31cac6b7a0e60d25a|dist/public/brand-contract.json" \
    "1923b10423a8072568d40c289f14f28677514ff6f045f4d2113149a0045e4143|dist/public/dgj-brand-contract-v27.js" \
    "8e32e015dedb7b87a5b84e85c1e5f42e432be6c89d7ef8074929d50aa3f5f422|dist/public/dgj-brand-lock.js" \
    "1b4034732ed22da830c9ba1994863ab8b10dc4d075f0ffcd52dfeedb678a410b|dist/public/dgj-google-jobs-v27.js"; do
      exp="${rec%%|*}"; rel="${rec#*|}"; [ -f "$APP_DIR/$rel" ] || fail "Partial V27 baseline missing $rel"; [ "$(sha "$APP_DIR/$rel")" = "$exp" ] || fail "Partial V27 baseline mismatch at $rel";
  done
  BASELINE="V27-PARTIAL-SAFE-STOP"
else
  fail "Live runtime is neither exact V19 nor the exact V27 partial baseline. Nothing changed. Server SHA: $SERVER_SHA"
fi
echo "PASS: exact recognized baseline = $BASELINE"

echo; echo "3/14 PACKAGE INTEGRITY + SYNTAX"
cd "$SELF_DIR"
sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || fail "Payload checksum mismatch."
[ "$(sha256sum brand-lock/brand-contract.json | awk '{print $1}')" = "5ccf445396d7f42ca53503d9ea1009bc307d395dab6198365225ca074bb1ad09" ] || fail "Brand contract SHA mismatch."
node -c dist/index.cjs >/dev/null || fail "Server runtime syntax invalid."
node --check dist/public/dgj-brand-contract-v27.js >/dev/null || fail "Brand preload syntax invalid."
node --check dist/public/dgj-brand-lock.js >/dev/null || fail "Brand resolver syntax invalid."
node --check dist/public/dgj-google-jobs-v27.js >/dev/null || fail "Google Jobs client schema syntax invalid."
bash -n "$SELF_DIR/deploy-final-safe.sh" || fail "Deploy script syntax invalid."
python3 -m py_compile source/script/apply-brand-lock-source.py || fail "Source installer syntax invalid."
for f in source/script/*.mjs; do node --check "$f" >/dev/null || fail "Invalid source script: $f"; done
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYCONTRACT' || fail "Contract quality audit failed."
import json,re,sys
c=json.load(open(sys.argv[1]))
assert c['lockId']=='DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27'
assert c['version']=='27.0.0'
assert len(c['staticRoutes'])==45, len(c['staticRoutes'])
assert len(c['privateRoutes'])==3, len(c['privateRoutes'])
assert len(c['countries'])==17, len(c['countries'])
assert len(c['cities'])==50, len(c['cities'])
assert len(c['blogArticles'])==32, len(c['blogArticles'])
assert c['cities']['washington-dc']=='Washington, DC'
assert c['cities']['abu-dhabi']=='Abu Dhabi'
seen={}
for route,m in {**c['staticRoutes'],**c['privateRoutes']}.items():
    t=m['title']; d=m['description']
    assert not re.search(r'\b(Jobs|Careers|Opportunities)\s+\1\b',t,re.I), (route,t)
    assert '—' not in t and '—' not in d
    if not str(m.get('robots',c['indexRobots'])).startswith('noindex'):
        assert t not in seen,(route,seen.get(t),t);seen[t]=route
assert c['staticRoutes']['/jobs/all']['title'] != c['staticRoutes']['/jobs/international']['title']
assert c['staticRoutes']['/jobs/sponsored']['title'].startswith('Sponsored Jobs')
assert 'Featured' not in c['staticRoutes']['/jobs/sponsored']['title']
print('PASS: 45 static + 17 countries + 50 cities + 32 blog metadata records validated')
PYCONTRACT
echo "PASS: V28 package integrity, syntax and contract quality verified."

echo; echo "4/14 BACKUP EVERY TOUCHED FILE"
mkdir -p "$BACKUP/files"; :>"$BACKUP/existed.txt"; :>"$BACKUP/touched.txt"
TOUCHED=(
'dist/index.cjs' 'dist/public/index.html' 'dist/public/assets/index-DGJ45auth-v11.js'
'dist/public/dgj-brand-contract-v27.js' 'dist/public/dgj-brand-lock.js' 'dist/public/dgj-google-jobs-v27.js' 'dist/public/brand-contract.json' 'dist/public/llms.txt'
'server/seoMeta.ts' 'server/brandSeo.ts' 'client/index.html' 'client/public/robots.txt' 'package.json'
'client/public/dgj-brand-contract-v27.js' 'client/public/dgj-brand-lock.js' 'client/public/dgj-google-jobs-v27.js' 'client/public/brand-contract.json' 'client/public/llms.txt'
'script/apply-brand-lock-source.py' 'script/patch-job-schema-client.mjs' 'script/patch-runtime-brand-meta.mjs' 'script/sync-brand-contract.mjs' 'script/verify-brand-lock.mjs' 'script/verify-google-jobs-schema.mjs'
'brand-lock/brand-contract.json' 'brand-lock/BRAND-CONTRACT.sha256'
)
for rel in "${TOUCHED[@]}"; do
  echo "$rel" >> "$BACKUP/touched.txt"
  if [ -e "$APP_DIR/$rel" ]; then
    echo "$rel" >> "$BACKUP/existed.txt"
    mkdir -p "$BACKUP/files/$(dirname "$rel")"
    cp -a "$APP_DIR/$rel" "$BACKUP/files/$rel"
  fi
done
echo "Backup: $BACKUP"
MUTATED=1

echo; echo "5/14 INSTALL IDEMPOTENT SOURCE-OF-TRUTH LOCK"
cd "$APP_DIR"
python3 "$SELF_DIR/source/script/apply-brand-lock-source.py" "$APP_DIR" || fail "Source brand lock installer failed."
node script/verify-brand-lock.mjs || fail "Source brand verifier failed."
node script/verify-google-jobs-schema.mjs || fail "Source Google Jobs verifier failed."
# Run installer a second time as an idempotence test. It must not duplicate loaders or lifecycle gates.
python3 "$SELF_DIR/source/script/apply-brand-lock-source.py" "$APP_DIR" >/dev/null || fail "Source lock is not idempotent."
node script/verify-brand-lock.mjs || fail "Source lock failed after idempotence re-check."
node script/verify-google-jobs-schema.mjs || fail "Google Jobs source lock failed after idempotence re-check."
echo "PASS: permanent source/build gates installed and idempotent."

echo; echo "6/14 ATOMIC V28 RUNTIME INSTALL"
copy_atomic(){ local src="$1" dst="$2" tmp="${2}.v28tmp.$$"; mkdir -p "$(dirname "$dst")"; cp -a "$src" "$tmp"; mv -f "$tmp" "$dst"; }
copy_atomic "$SELF_DIR/dist/index.cjs" "$SERVER"
copy_atomic "$SELF_DIR/dist/public/index.html" "$INDEX"
copy_atomic "$SELF_DIR/dist/public/assets/index-DGJ45auth-v11.js" "$SPA"
for f in dgj-brand-contract-v27.js dgj-brand-lock.js dgj-google-jobs-v27.js brand-contract.json llms.txt; do copy_atomic "$SELF_DIR/dist/public/$f" "$APP_DIR/dist/public/$f"; done
node -c "$SERVER" >/dev/null || fail "Live server syntax invalid after atomic copy."
echo "PASS: reviewed runtime and SEO/schema assets installed atomically."

echo; echo "7/14 RELOAD ONLY MAIN APP + HEALTH"
pm2 reload devglobaljobs --update-env
sleep 2
PM2_DESC="$(pm2 describe devglobaljobs)"; grep -q 'online' <<<"$PM2_DESC" || fail "PM2 app not online."
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "API unhealthy after reload."
echo "PASS: PM2 and API healthy."

echo; echo "8/14 ALL LOCKED PUBLIC METADATA + NO LIST JOBPOSTING"
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYROUTES' || fail "Public route metadata audit failed."
import html,json,re,subprocess,sys
c=json.load(open(sys.argv[1])); base='http://127.0.0.1:8080'
def fetch(route):
    return subprocess.check_output(['curl','-fsS','--max-time','20','-H','Host: devglobaljobs.com',base+route+('?v28=1' if '?' not in route else '&v28=1')],text=True)
def parsedoc(b):
    mt=re.search(r'<title[^>]*>(.*?)</title>',b,re.I|re.S); title=html.unescape(mt.group(1).strip()) if mt else ''
    md=re.search(r'<meta\s+name=["\']description["\'][^>]+content=["\']([^"\']*)',b,re.I|re.S); desc=html.unescape(md.group(1).strip()) if md else ''
    mc=re.search(r'<link\s+rel=["\']canonical["\'][^>]+href=["\']([^"\']*)',b,re.I|re.S); can=html.unescape(mc.group(1).strip()) if mc else ''
    return title,desc,can
jp=re.compile(r'["\']@type["\']\s*:\s*["\']JobPosting["\']',re.I)
count=0
for route,exp in c['staticRoutes'].items():
    b=fetch(route); t,d,can=parsedoc(b)
    assert t==exp['title'],(route,'title',t,exp['title']); assert d==exp['description'],(route,'description')
    expected='https://devglobaljobs.com' if route=='/' else 'https://devglobaljobs.com'+route
    assert can==expected,(route,'canonical',can,expected); assert not jp.search(b),(route,'JobPosting on list/content page'); count+=1
for slug,name in c['countries'].items():
    route='/jobs/country/'+slug; p=c['dynamicPatterns']['country']; b=fetch(route); t,d,can=parsedoc(b)
    assert t==p['title'].replace('{Country}',name),(route,t); assert d==p['description'].replace('{Country}',name),(route,'description'); assert can=='https://devglobaljobs.com'+route; assert not jp.search(b),(route,'JobPosting'); count+=1
for slug,name in c['cities'].items():
    route='/jobs/city/'+slug; p=c['dynamicPatterns']['city']; b=fetch(route); t,d,can=parsedoc(b)
    assert t==p['title'].replace('{City}',name),(route,t); assert d==p['description'].replace('{City}',name),(route,'description'); assert can=='https://devglobaljobs.com'+route; assert not jp.search(b),(route,'JobPosting'); count+=1
for slug,exp in c['blogArticles'].items():
    route='/blog/'+slug; b=fetch(route); t,d,can=parsedoc(b)
    assert t==exp['title'],(route,t); assert d==exp['description'],(route,'description'); assert can=='https://devglobaljobs.com'+route; assert not jp.search(b),(route,'JobPosting'); count+=1
print('PASS:',count,'indexed public landing/content routes checked; JobPosting absent from all non-job pages')
PYROUTES

echo; echo "9/14 PRIVATE NOINDEX + V19 MOBILE AUTH"
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYPRIVATE' || fail "Private noindex audit failed."
import json,re,subprocess,sys
c=json.load(open(sys.argv[1]));base='http://127.0.0.1:8080'
for route in c['privateRoutes']:
 h=subprocess.run(['curl','-fsS','--max-time','20','-D','-','-H','Host: devglobaljobs.com',base+route+'?v28=1'],text=True,capture_output=True,check=True).stdout
 if not (re.search(r'X-Robots-Tag:\s*noindex,?\s*nofollow',h,re.I) or re.search(r'<meta\s+name=["\'](?:robots|googlebot)["\'][^>]+content=["\']noindex,?\s*nofollow',h,re.I)):
  raise SystemExit(f'{route} private noindex missing')
print('PASS:',len(c['privateRoutes']),'private routes noindex')
PYPRIVATE
curl -fsS --max-time 20 -H 'Host: devglobaljobs.com' http://127.0.0.1:8080/sign-in?v28=1 -o /tmp/dgj-v28-signin.html || fail "Sign-in fetch failed."
grep -Fq 'DGJ_AUTH_MOBILE_V19' /tmp/dgj-v28-signin.html || fail "V19 mobile auth marker missing."
rm -f /tmp/dgj-v28-signin.html
echo "PASS: private noindex and V19 mobile auth preserved."

echo; echo "10/14 PUBLIC BRAND + LLM IDENTITY"
BRAND_JSON="$(curl -fsS --max-time 20 https://devglobaljobs.com/brand-contract.json)"; grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27' <<<"$BRAND_JSON" || fail "Public brand contract missing."
BRAND_JS="$(curl -fsS --max-time 20 https://devglobaljobs.com/dgj-brand-contract-v27.js)"; grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27' <<<"$BRAND_JS" || fail "Public brand preload missing."
LLMS_TXT="$(curl -fsS --max-time 20 https://devglobaljobs.com/llms.txt)"; grep -Fq 'International Careers Platform' <<<"$LLMS_TXT" || fail "llms.txt identity missing."
echo "PASS: machine-readable International Careers identity served publicly."

echo; echo "11/14 GOOGLE JOBS SOURCE + RUNTIME GATES"
cd "$APP_DIR"
node script/verify-brand-lock.mjs --dist || fail "Runtime brand gate failed."
node script/verify-google-jobs-schema.mjs --dist || fail "Runtime Google Jobs gate failed."
echo "PASS: source and built Google Jobs architecture gates passed."

echo; echo "12/14 LIVE JOBPOSTING FACTUAL SAMPLE AUDIT"
curl -fsS --max-time 30 'http://127.0.0.1:8080/api/jobs/all?limit=100&offset=0' -o /tmp/dgj-v28-jobs.json || fail "Jobs API sample failed."
python3 - /tmp/dgj-v28-jobs.json <<'PYJOBS' || fail "Live JobPosting sample audit failed."
import datetime,html,json,re,subprocess,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
jobs=d.get('jobs',[]) if isinstance(d,dict) else d
bad={'worldwide','global','remote','anywhere','international',''}
def eligible(j):
    if not all(j.get(x) for x in ('id','title','organization','description','postedAt')): return False
    c=str(j.get('country') or '').strip().lower()
    if c in bad: return False
    closing=j.get('closingDate')
    if closing:
      try:
        dt=datetime.datetime.fromisoformat(str(closing).replace('Z','+00:00'))
        if dt.tzinfo is None:dt=dt.replace(tzinfo=datetime.timezone.utc)
        if dt < datetime.datetime.now(datetime.timezone.utc):return False
      except Exception: pass
    return True
samples=[j for j in jobs if eligible(j)][:12]
if not samples: raise SystemExit('No complete active sample job available')
remote_seen=physical_seen=0
for j in samples:
    route=f"/jobs/detail/{j['id']}"
    h=subprocess.check_output(['curl','-fsS','--max-time','20','-H','Host: devglobaljobs.com','http://127.0.0.1:8080'+route+'?v28=1'],text=True)
    blocks=re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',h,re.I|re.S)
    postings=[]
    def walk(v):
      if isinstance(v,dict):
        t=v.get('@type')
        if t=='JobPosting' or (isinstance(t,list) and 'JobPosting' in t):postings.append(v)
        for x in v.values():walk(x)
      elif isinstance(v,list):
        for x in v:walk(x)
    for raw in blocks:
      try:walk(json.loads(raw))
      except Exception:pass
    assert len(postings)==1,(route,'JobPosting count',len(postings))
    s=postings[0]
    assert s.get('title')==str(j['title']).strip(),(route,'title mismatch')
    assert s.get('description') and len(re.sub('<[^>]+>',' ',s['description']).strip())>0,(route,'description')
    expected_date=datetime.datetime.fromisoformat(str(j['postedAt']).replace('Z','+00:00')).date().isoformat()
    assert s.get('datePosted')==expected_date,(route,'datePosted',s.get('datePosted'),expected_date)
    assert s.get('hiringOrganization',{}).get('name')==str(j['organization']).strip(),(route,'hiringOrganization')
    assert s.get('identifier',{}).get('value')==str(j.get('sourceId') or j['id']),(route,'identifier')
    assert s.get('url')=='https://devglobaljobs.com'+route,(route,'url')
    assert s.get('directApply') is False,(route,'directApply')
    if s.get('jobLocationType')=='TELECOMMUTE':
      remote_seen+=1; assert s.get('applicantLocationRequirements',{}).get('name'),(route,'remote applicant location')
    else:
      physical_seen+=1; assert s.get('jobLocation',{}).get('address',{}).get('addressCountry'),(route,'physical addressCountry')
    if s.get('validThrough'):
      assert j.get('closingDate'),(route,'synthetic validThrough')
    if s.get('baseSalary'):
      assert j.get('isEmployerPosted') and j.get('salary'),(route,'salary provenance')
print(f'PASS: {len(samples)} live eligible jobs validated; physical={physical_seen}, remote={remote_seen}; exactly one factual JobPosting each')
PYJOBS
rm -f /tmp/dgj-v28-jobs.json

echo; echo "13/14 SITEMAP + GOOGLE JOB URL COVERAGE"
SM="$(curl -fsSL --max-time 30 https://devglobaljobs.com/sitemap.xml)" || fail "Master sitemap unavailable."
EXPECTED_SITEMAPS=(
 sitemap-pages.xml sitemap-cities.xml sitemap-blog.xml sitemap-jobs-latest.xml
 sitemap-jobs-ae.xml sitemap-jobs-ar.xml sitemap-jobs-at.xml sitemap-jobs-au.xml sitemap-jobs-bd.xml sitemap-jobs-be.xml sitemap-jobs-bg.xml sitemap-jobs-br.xml sitemap-jobs-ca.xml sitemap-jobs-ch.xml sitemap-jobs-cl.xml sitemap-jobs-cn.xml sitemap-jobs-co.xml sitemap-jobs-cy.xml sitemap-jobs-cz.xml sitemap-jobs-de.xml sitemap-jobs-dk.xml sitemap-jobs-ee.xml sitemap-jobs-eg.xml sitemap-jobs-es.xml sitemap-jobs-et.xml sitemap-jobs-fi.xml sitemap-jobs-fr.xml sitemap-jobs-gb.xml sitemap-jobs-gh.xml sitemap-jobs-gr.xml sitemap-jobs-hu.xml sitemap-jobs-id.xml sitemap-jobs-ie.xml sitemap-jobs-il.xml sitemap-jobs-in.xml sitemap-jobs-it.xml sitemap-jobs-jp.xml sitemap-jobs-ke.xml sitemap-jobs-kr.xml sitemap-jobs-lt.xml sitemap-jobs-lu.xml sitemap-jobs-ma.xml sitemap-jobs-mx.xml sitemap-jobs-my.xml sitemap-jobs-ng.xml sitemap-jobs-nl.xml sitemap-jobs-no.xml sitemap-jobs-nz.xml sitemap-jobs-ph.xml sitemap-jobs-pk.xml sitemap-jobs-pl.xml sitemap-jobs-pt.xml sitemap-jobs-qa.xml sitemap-jobs-ro.xml sitemap-jobs-rs.xml sitemap-jobs-sa.xml sitemap-jobs-se.xml sitemap-jobs-sg.xml sitemap-jobs-si.xml sitemap-jobs-sk.xml sitemap-jobs-th.xml sitemap-jobs-tz.xml sitemap-jobs-ug.xml sitemap-jobs-us.xml sitemap-jobs-vn.xml sitemap-jobs-za.xml
 sitemap-jobs-remote-worldwide.xml sitemap-jobs-1.xml sitemap-jobs-2.xml sitemap-jobs-3.xml
)
for needle in "${EXPECTED_SITEMAPS[@]}"; do grep -Fq "$needle" <<<"$SM" || fail "Sitemap index missing $needle"; done
for shard in sitemap-jobs-latest.xml sitemap-jobs-qa.xml sitemap-jobs-us.xml sitemap-jobs-remote-worldwide.xml sitemap-jobs-1.xml; do
  XML="$(curl -fsSL --max-time 30 "https://devglobaljobs.com/$shard")" || fail "$shard unavailable."
  grep -Eq 'https://devglobaljobs.com/jobs/detail/[0-9]+' <<<"$XML" || fail "$shard has no canonical job detail URLs."
done
echo "PASS: master sitemap and representative Google Jobs URL shards verified."

echo; echo "14/14 PRESERVATION + SAVE"
[ "$(sha "$GJS")" = "d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a" ] || fail "Growth JS changed unexpectedly."
[ "$(sha "$GCS")" = "4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51" ] || fail "Growth CSS changed unexpectedly."
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy at final check."
pm2 save >/dev/null
SUCCESS=1
MUTATED=0
trap - EXIT

echo
echo "============================================================"
echo "SUCCESS: PERMANENT BRAND + GOOGLE JOBS SCHEMA SAFE V28 IS LIVE"
echo "============================================================"
echo "  ✓ Permanent International Careers source-of-truth brand contract"
echo "  ✓ 45 static routes + 17 countries + 50 cities + 32 article metadata checks"
echo "  ✓ All Jobs / International Jobs / Sponsored Jobs remain separate"
echo "  ✓ Featured remains placement/status only"
echo "  ✓ Google JobPosting only on eligible individual job-detail pages"
echo "  ✓ Required factual title, description, datePosted, employer and location guarded"
echo "  ✓ Remote jobs require TELECOMMUTE + factual applicant country"
echo "  ✓ No fake Worldwide country, synthetic posting date or synthetic expiry"
echo "  ✓ Salary markup only from explicit employer-posted currency + pay period data"
echo "  ✓ Exactly one JobPosting checked on live eligible samples"
echo "  ✓ Job sitemap architecture preserved"
echo "  ✓ V19 mobile auth / OTP / application functionality preserved"
echo "  ✓ Database untouched; no npm build; no drizzle-kit push"
echo "Rollback backup: $BACKUP"
echo "============================================================"
