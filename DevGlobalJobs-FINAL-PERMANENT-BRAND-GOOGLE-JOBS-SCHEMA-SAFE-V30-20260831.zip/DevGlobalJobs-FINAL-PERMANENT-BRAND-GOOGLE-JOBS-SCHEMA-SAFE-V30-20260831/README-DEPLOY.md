# Dev Global Jobs V30 Final Permanent Brand + Google Jobs Schema Safe Release

V30 is the final packaging-corrected deployment release for the permanent International Careers source-of-truth brand contract and factual Google `JobPosting` schema lock.

## V30 correction

The prior V28 live deployment correctly rolled back at its validation gate. The failing route was `/blog/un-jobs-application-guide-beginners`; the page metadata itself was not proven wrong. The V28 validator used a regular expression that incorrectly truncated a double-quoted meta description at the apostrophe in `beginner's`, causing a false mismatch. V30 replaces that parser with Python's HTML parser and includes a regression test for apostrophes and HTML entities before live route checks begin.

The user's second V28 launcher also stopped before deployment because duplicate ZIP names existed in GitHub. For V30, the launcher should select the candidate by exact SHA-256 rather than by filename uniqueness.

## Permanent brand architecture

- Dev Global Jobs remains locked as an International Careers Platform.
- `/jobs/all`, `/jobs/international`, and `/jobs/sponsored` remain separate intents.
- Featured remains a placement/status only and is not turned into a fake SEO route.
- Static routes, industry/category routes, countries, cities, tools, resources, youth, employer/developer pages, known articles, canonical URLs, robots rules, Open Graph/Twitter metadata, and source/build guards remain contract-backed.
- Unknown routes default to noindex until deliberately added to the contract.

## Google Jobs schema policy

`JobPosting` is limited to eligible individual `/jobs/detail/{id}` pages. Eligible pages require a real job title, real complete description, original stored posting date, real hiring organization, and a factual location signal. Physical jobs require `jobLocation.address.addressCountry`. Fully remote jobs use `jobLocationType: TELECOMMUTE` and a factual `applicantLocationRequirements` country. `validThrough` appears only when a real closing date exists. Salary markup appears only when factual employer-posted salary data has a recognized currency, numeric amount, and pay period. Expired or materially incomplete jobs do not emit active `JobPosting` markup.

This matches Google's core JobPosting requirements and remote-job guidance, but Google controls crawling, policy review, indexing, ranking, and final inclusion.

## Deployment safety

The included `deploy-final-safe.sh` accepts only the recognized V19 or exact V27-partial baseline, backs up every touched file, installs the source/build lock idempotently, atomically installs the reviewed runtime, reloads only the main PM2 app, audits all locked public metadata, checks private noindex, validates sampled live JobPosting JSON-LD, verifies job sitemap shards, and automatically rolls back on any post-mutation failure. It does not run `npm build`, `drizzle-kit push`, a database migration, or a full-site replacement.


## V30 packaging correction

V30 removes transient Python bytecode from the release payload and rebuilds the SHA-256 manifest after all offline validation, so the payload manifest is reproducible and self-consistent. Runtime brand and Google Jobs schema logic is unchanged from the reviewed V29 code.
