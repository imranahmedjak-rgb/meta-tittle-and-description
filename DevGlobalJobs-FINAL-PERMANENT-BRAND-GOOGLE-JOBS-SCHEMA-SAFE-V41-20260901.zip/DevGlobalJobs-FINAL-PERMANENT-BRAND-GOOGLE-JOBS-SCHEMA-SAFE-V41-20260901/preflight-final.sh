#!/usr/bin/env bash
set -Eeuo pipefail
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SELF_DIR"

die(){ echo "V41 PREFLIGHT FAIL: $*" >&2; exit 1; }

sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || die "payload manifest mismatch"
node -c dist/index.cjs >/dev/null || die "dist/index.cjs syntax"
for f in dist/public/dgj-brand-contract-v27.js dist/public/dgj-brand-lock.js dist/public/dgj-google-jobs-v27.js source/script/*.mjs; do node --check "$f" >/dev/null || die "Node syntax: $f"; done
bash -n deploy-final-safe.sh || die "deploy Bash syntax"
bash -n preflight-final.sh || die "preflight Bash syntax"
PYTHONPYCACHEPREFIX=/tmp/dgj-v41-preflight-pycache python3 -m py_compile source/script/apply-brand-lock-source.py || die "Python installer syntax"

python3 - brand-lock/brand-contract.json <<'PYCHK'
import json,re,sys,hashlib
c=json.load(open(sys.argv[1],encoding='utf-8'))
assert c['lockId']=='DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27'
assert c['version']=='27.0.0'
assert len(c['staticRoutes'])==45
assert len(c['privateRoutes'])==3
assert len(c['countries'])==17
assert len(c['cities'])==50
assert len(c['blogArticles'])==32
s=c['staticRoutes']['/jobs/sponsored'];a=c['staticRoutes']['/jobs/all'];i=c['staticRoutes']['/jobs/international']
assert s['title'].startswith('Sponsored Jobs') and 'Featured' not in s['title']
assert c['brand']['sponsoredRule']['path']=='/jobs/sponsored' and c['brand']['sponsoredRule']['isDedicatedRoute'] is True
assert c['brand']['featuredRule']['hasSeparateSeoRoute'] is False
assert c['brand']['featuredRule']['discoveryDestination']=='/jobs/all'
assert len({a['title'],i['title'],s['title']})==3
seen={}
for r,m in {**c['staticRoutes'],**c['privateRoutes']}.items():
    assert m.get('title') and m.get('description'),r
    assert not re.search(r'\b(Jobs|Careers|Opportunities)\s+\1\b',m['title'],re.I),(r,m['title'])
    assert '—' not in m['title'] and '—' not in m['description'],r
    if not str(m.get('robots',c['indexRobots'])).startswith('noindex'):
        assert m['title'] not in seen,(r,seen.get(m['title']),m['title']);seen[m['title']]=r
print('PASS: contract semantics, coverage and route distinctions')
PYCHK

python3 - <<'PYCHK'
import hashlib,json,re
from pathlib import Path
D=Path('.')
raw=(D/'brand-lock/brand-contract.json').read_bytes(); c=json.loads(raw); sha=hashlib.sha256(raw).hexdigest()
for p in [D/'source/client/public/brand-contract.json',D/'dist/public/brand-contract.json']:
    assert hashlib.sha256(p.read_bytes()).hexdigest()==sha,p
for p in [D/'source/client/public/dgj-brand-contract-v27.js',D/'dist/public/dgj-brand-contract-v27.js']:
    s=p.read_text();m=re.search(r'window\.DGJ_BRAND_CONTRACT_V27=(.*);\s*$',s,re.S);assert m,p;assert json.loads(m.group(1))==c,p
idx=(D/'dist/public/index.html').read_text()
srcs=re.findall(r'<script[^>]+src=["\']([^"\']*/assets/index-[^"\']+\.js)["\'][^>]*>',idx,re.I)
assert len(srcs)==1,srcs
spa=(D/'dist/public'/srcs[0].lstrip('/')).read_text()
for route,m in c['staticRoutes'].items():
    if re.fullmatch(r'/jobs/(all|un|ngo|remote|international|technology|healthcare|business|education|engineering|creative|sales|gig|youth|sponsored)',route):
        assert m['title'] in spa,(route,'title');assert m['description'] in spa,(route,'description')
for bad in ['Jobs Jobs |','Jobs | International Careers - Dev Global Jobs','Sponsored Jobs | Employer-Promoted Roles | Dev Global Jobs']:
    assert bad not in spa,bad
assert 'JobPosting' not in idx
print('PASS: authoritative/public/preload/active-SPA synchronization')
PYCHK

# Exact preservation proof for reviewed Google Jobs implementation from V32.
[ "$(sha256sum dist/public/dgj-google-jobs-v27.js | awk '{print $1}')" = "efd02864b5ea0703465ab7d62a6b8dc43d7a48e0ea074082a45f6a7adc23ddf6" ] || die "Google Jobs companion changed"
[ "$(sha256sum source/server/brandSeo.ts | awk '{print $1}')" = "0c88170236662028228526d7b5ac566f87afa0635047b09fb05d09bd8975bfe7" ] || die "source JobPosting server changed"
[ "$(sha256sum source/script/verify-google-jobs-schema.mjs | awk '{print $1}')" = "8211622dceccfb6fa9ea8f6149c86e7532cb50e00bb5ed501927046be4668d60" ] || die "Google Jobs verifier changed"
[ "$(sha256sum source/script/patch-job-schema-client.mjs | awk '{print $1}')" = "81f6a01fa502a3229ea5399f46f8098a0a832da8178e351d4a0ad0979b7c1d94" ] || die "Google Jobs client patcher changed"

# V41 sitemap indexing fix: sitemap count and emitted URLs now use the same all-job population.
grep -Fq 'const indexableJobs = latestJobs;' dist/index.cjs || die "latest sitemap still employer-only"
grep -Fq 'const indexableJobs = jobIds;' dist/index.cjs || die "country sitemap still employer-only"
grep -Fq 'const indexableJobs = allJobIds;' dist/index.cjs || die "numbered sitemap still employer-only"
if grep -Fq 'const indexableJobs = latestJobs.filter((j) => j.isEmployerPosted);' dist/index.cjs; then die "legacy latest employer-only sitemap filter remains"; fi
node --check source/script/patch-job-sitemap-indexing.mjs >/dev/null || die "sitemap postbuild patcher syntax"
grep -Fq 'node script/patch-job-sitemap-indexing.mjs' source/script/apply-brand-lock-source.py || die "future-build sitemap patch lifecycle missing"

grep -Fq 'DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27' dist/index.cjs || die "schema lock marker missing"
grep -Fq 'if(!description||!datePosted)return null' dist/index.cjs || die "required description/date guard missing"
grep -Fq 'if(!dgjJobHasApplyPath(job))return null' dist/index.cjs || die "application-path guard missing"
grep -Fq 'schema.jobLocationType="TELECOMMUTE"' dist/index.cjs || die "TELECOMMUTE guard missing"
grep -Fq 'applicantLocationRequirements' dist/index.cjs || die "remote applicant location missing"
grep -Fq 'addressCountry' dist/index.cjs || die "physical addressCountry missing"
grep -Fq 'if(!job.isEmployerPosted||!job.salary)return null' dist/index.cjs || die "salary provenance guard missing"
grep -Fq 'if(validThrough)schema.validThrough=validThrough' dist/index.cjs || die "conditional validThrough capability missing"
grep -Fq 'dgjJobApplicationContact' dist/index.cjs || die "applicationContact helper missing"
grep -Fq 'schema.applicationContact=applicationContact' dist/index.cjs || die "applicationContact server property missing"
grep -Fq 'function applicationContact(j)' dist/public/dgj-google-jobs-v27.js || die "applicationContact client helper missing"
grep -Fq 'jp.applicationContact=ac' dist/public/dgj-google-jobs-v27.js || die "applicationContact client property missing"

# Compile every embedded Python heredoc in the deploy script; catches errors Bash syntax cannot see.
python3 - <<'PYCHK'
from pathlib import Path
import re,subprocess,tempfile
lines=Path('deploy-final-safe.sh').read_text().splitlines();i=0;n=0
while i<len(lines):
    m=re.search(r"<<'([A-Z0-9_]+)'",lines[i])
    if not m:i+=1;continue
    token=m.group(1);j=i+1
    while j<len(lines) and lines[j].strip()!=token:j+=1
    assert j<len(lines),f'unclosed heredoc {token}'
    if 'python3' in lines[i]:
        n+=1
        with tempfile.NamedTemporaryFile('w',suffix='.py',delete=False) as f:f.write('\n'.join(lines[i+1:j])+'\n');name=f.name
        r=subprocess.run(['python3','-m','py_compile',name],capture_output=True,text=True)
        assert r.returncode==0,(token,r.stderr)
    i=j+1
assert n>=4,n
print('PASS: embedded deploy Python heredocs compile:',n)
PYCHK

# Regression for the exact V34 live failure: stale inactive hashed bundles must not fail the runtime gate.
TMPREG="$(mktemp -d /tmp/dgj-v41-stale-bundle.XXXXXX)"
cleanup_reg(){ rm -rf "$TMPREG"; }
trap cleanup_reg EXIT
mkdir -p "$TMPREG/server" "$TMPREG/client/public" "$TMPREG/script" "$TMPREG/dist/public/assets"
cp source/server/brandSeo.ts "$TMPREG/server/brandSeo.ts"
cp source/client/public/dgj-google-jobs-v27.js "$TMPREG/client/public/dgj-google-jobs-v27.js"
printf '%s\n' '<html><head><script src="/dgj-google-jobs-v27.js"></script><script src="/assets/index-ACTIVE.js"></script></head><body></body></html>' > "$TMPREG/client/index.html"
cp source/script/verify-google-jobs-schema.mjs "$TMPREG/script/verify-google-jobs-schema.mjs"
cp dist/index.cjs "$TMPREG/dist/index.cjs"
cp dist/public/dgj-google-jobs-v27.js "$TMPREG/dist/public/dgj-google-jobs-v27.js"
printf '%s\n' '<html><head><script src="/dgj-google-jobs-v27.js"></script><script src="/assets/index-ACTIVE.js"></script></head><body></body></html>' > "$TMPREG/dist/public/index.html"
printf '%s\n' '/* DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27 */' > "$TMPREG/dist/public/assets/index-ACTIVE.js"
printf '%s\n' 'document.getElementById("job-jsonld"); /* stale inactive historical bundle */' > "$TMPREG/dist/public/assets/index-STALE-OLD.js"
( cd "$TMPREG" && node script/verify-google-jobs-schema.mjs --dist >/dev/null ) || die "inactive stale SPA bundle incorrectly fails Google Jobs gate"
printf '%s\n' '/* DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27 */ document.getElementById("job-jsonld");' > "$TMPREG/dist/public/assets/index-ACTIVE.js"
if ( cd "$TMPREG" && node script/verify-google-jobs-schema.mjs --dist >/dev/null 2>&1 ); then die "active legacy JobPosting negative control was not rejected"; fi
cleanup_reg
trap - EXIT
echo 'PASS: stale inactive bundle ignored; active legacy JobPosting still rejected'

# Regression for the exact V35 live step-12 failure: a truthy stored job.url is not
# automatically an applicationContact URL. The runtime emits applicationContact.url only
# for absolute HTTP(S) URLs. Relative/non-HTTP apply values must not trigger a false rollback.
python3 - <<'PYCHK'
import re
from urllib.parse import urlsplit

def absolute_http_url(raw):
    value=str(raw or '').strip()
    if not value:return None
    try:u=urlsplit(value)
    except Exception:return None
    return u if u.scheme.lower() in ('http','https') and u.netloc else None

def canonical_http_key(u):
    try:
        host=(u.hostname or '').lower(); port=u.port
    except Exception:
        return None
    if not host:return None
    scheme=u.scheme.lower()
    if (scheme=='https' and port==443) or (scheme=='http' and port==80):port=None
    authority=host if port is None else f'{host}:{port}'
    return (scheme,authority,u.path or '/',u.query,u.fragment)

def valid_email(raw):
    return bool(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',str(raw or '').strip()))

def check(job,ac):
    expected=absolute_http_url(job.get('url'))
    if expected:
        assert ac and ac.get('url')
        actual=absolute_http_url(ac.get('url')); assert actual
        ek=canonical_http_key(expected); ak=canonical_http_key(actual)
        assert ek and ak and ak==ek
    if valid_email(job.get('applyEmail')):
        assert ac and ac.get('email')==str(job.get('applyEmail')).strip()
    if ac and ac.get('url'):assert absolute_http_url(ac.get('url'))

check({'url':'/apply/130400150','applyEmail':None},None)
check({'url':'www.example.com/jobs/130400150','applyEmail':None},None)
check({'url':'mailto:jobs@example.com','applyEmail':None},None)
check({'url':'https://careers.example.com/jobs/130400150','applyEmail':None},{'url':'https://careers.example.com/jobs/130400150'})
# Exact V37 live false-stop class: browser URL serialization removes HTTPS default :443.
check({'url':'https://www.usajobs.gov:443/job/880996800','applyEmail':None},{'url':'https://www.usajobs.gov/job/880996800'})
check({'url':'http://example.com:80/jobs/1','applyEmail':None},{'url':'http://example.com/jobs/1'})
check({'url':'https://careers.example.com','applyEmail':'apply@example.com'},{'url':'https://careers.example.com/','email':'apply@example.com'})
check({'url':None,'applyEmail':'apply@example.com'},{'email':'apply@example.com'})
failed=False
try:check({'url':'https://careers.example.com/jobs/1','applyEmail':None},None)
except AssertionError:failed=True
assert failed,'negative control did not fail'
port_failed=False
try:check({'url':'https://careers.example.com:8443/jobs/1','applyEmail':None},{'url':'https://careers.example.com/jobs/1'})
except AssertionError:port_failed=True
assert port_failed,'non-default port mismatch was incorrectly normalized'
print('PASS: applicationContact URL normalization regressions covered, including default-port equivalence')
PYCHK

# Regression for the exact V36 launcher false stop: validThrough is conditional.
node --input-type=module <<'NODECHK' || die "conditional validThrough regression failed"
import fs from 'node:fs';
import vm from 'node:vm';
const client=fs.readFileSync('dist/public/dgj-google-jobs-v27.js','utf8');
const fakeDoc={head:{appendChild(){}},querySelector(){return null},querySelectorAll(){return []},createElement(){return {setAttribute(){},remove(){}}},getElementById(){return null}};
const ctx={window:{},document:fakeDoc,URL,Intl,Date,JSON,console};vm.createContext(ctx);vm.runInContext(client,ctx);
const B=ctx.window.DGJGoogleJobsV27?.build;if(typeof B!=='function')throw new Error('builder unavailable');
const base={id:991,title:'Systems Analyst',organization:'Example Employer',description:'<p>Complete role description with responsibilities, qualifications and experience requirements.</p>',postedAt:'2026-08-20T12:00:00Z',country:'US',location:'New York, US',jobType:'Full-time',isEmployerPosted:true,url:'https://careers.example.com/jobs/991'};
const noExpiry=B(base);if(!noExpiry)throw new Error('no-expiry job unexpectedly suppressed');if(Object.prototype.hasOwnProperty.call(noExpiry,'validThrough'))throw new Error('synthetic validThrough');
const future=B({...base,id:992,closingDate:'2027-01-15T23:59:59Z'});if(!future||future.validThrough!=='2027-01-15')throw new Error('future validThrough missing/mismatch');
const expired=B({...base,id:993,closingDate:'2026-01-15T23:59:59Z'});if(expired)throw new Error('expired JobPosting not suppressed');
console.log('PASS: validThrough omitted when unknown, emitted when factual, expired job suppressed');
NODECHK


# Regression for V39/V40 sitemap failures: origin is authoritative immediately after reload,
# and actual job-bearing sitemap generation must not be restricted to employer-posted rows.
python3 - <<'PYCHK'
from pathlib import Path
import re
runtime=Path('dist/index.cjs').read_text()
deploy=Path('deploy-final-safe.sh').read_text()
installer=Path('source/script/apply-brand-lock-source.py').read_text()
assert 'const indexableJobs = latestJobs;' in runtime
assert 'const indexableJobs = jobIds;' in runtime
assert 'const indexableJobs = allJobIds;' in runtime
assert 'latestJobs.filter((j) => j.isEmployerPosted)' not in runtime
assert 'jobIds.filter((j) => j.isEmployerPosted)' not in runtime
assert 'allJobIds.filter((j) => j.isEmployerPosted)' not in runtime
assert 'LATEST_COUNT' in deploy and 'NUMBERED_COUNT' in deploy
assert 'Fresh origin latest-job sitemap contains zero canonical job-detail URLs.' in deploy
assert 'Fresh origin numbered job sitemap contains zero canonical job-detail URLs.' in deploy
assert 'WARN: public CDN latest-job sitemap is still cached/empty' in deploy
assert 'node script/patch-job-sitemap-indexing.mjs' in installer
# Simulate a population where every row is imported/non-employer: old logic yields zero; V41 yields all.
rows=[{'id':1,'isEmployerPosted':False},{'id':2,'isEmployerPosted':False},{'id':3,'isEmployerPosted':False}]
assert len([x for x in rows if x['isEmployerPosted']])==0
assert len(rows)==3
print('PASS: V40 zero-job-sitemap failure fixed at generation + origin-validation layers')
PYCHK

if find . -type f \( -name '*.pyc' -o -path '*/__pycache__/*' \) | grep -q .; then die "transient Python bytecode present in payload"; fi

echo 'PASS: V41 FINAL OFFLINE PACKAGE PREFLIGHT COMPLETE'
