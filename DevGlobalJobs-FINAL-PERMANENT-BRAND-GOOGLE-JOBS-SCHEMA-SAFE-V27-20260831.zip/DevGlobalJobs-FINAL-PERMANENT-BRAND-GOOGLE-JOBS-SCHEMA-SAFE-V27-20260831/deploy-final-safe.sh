#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${APP_DIR:-/var/www/devglobaljobs}"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-brand-googlejobs-v27-${STAMP}"
SERVER="$APP_DIR/dist/index.cjs"; INDEX="$APP_DIR/dist/public/index.html"; SPA="$APP_DIR/dist/public/assets/index-DGJ45auth-v11.js"
GJS="$APP_DIR/dist/public/assets/growth-suite.js"; GCS="$APP_DIR/dist/public/assets/growth-suite.css"
COPIED=0; SOURCE_PATCHED=0
fail(){ echo; echo "============================================================"; echo "SAFE STOP: $*"; echo "============================================================"; exit 1; }
restore_rel(){ local rel="$1"; if grep -Fxq "$rel" "$BACKUP/existed.txt" 2>/dev/null; then mkdir -p "$(dirname "$APP_DIR/$rel")"; cp -a "$BACKUP/files/$rel" "$APP_DIR/$rel"; else rm -f "$APP_DIR/$rel"; fi; }
rollback(){ set +e; if [ -d "$BACKUP" ]; then echo; echo "ROLLBACK: restoring pre-V27 touched files..."; while IFS= read -r rel; do [ -n "$rel" ] && restore_rel "$rel"; done < "$BACKUP/touched.txt"; pm2 reload devglobaljobs --update-env >/dev/null 2>&1 || true; echo "ROLLBACK COMPLETE."; fi; }
trap 'rc=$?; echo "ERROR at line $LINENO (exit $rc)"; rollback; exit $rc' ERR

echo "============================================================"; echo "DEV GLOBAL JOBS - PERMANENT BRAND + GOOGLE JOBS V27"; echo "============================================================"
[ "$(id -u)" = 0 ] || fail "Run as root."; [ -d "$APP_DIR" ] || fail "$APP_DIR missing."; [ -f "$APP_DIR/.env" ] || fail "Production .env missing."
for x in curl python3 sha256sum node pm2 grep awk sed cp mkdir mv; do command -v "$x" >/dev/null || fail "Missing command: $x"; done

echo; echo "1/13 CURRENT LIVE HEALTH"; curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy."; curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy."; echo "PASS: production healthy."

echo; echo "2/13 EXACT V19 COLLISION PROTECTION"
checks=(
"96c833718aedcafa5b2d5cc777a24721731e86e155300c99e2bc79891329de79|$SERVER"
"120bd1d247779dab7c027f453bb7701f7a91b57d787ffba3033b82705fb35bfa|$INDEX"
"725d891d23a2567f0f880925d6080ea3633ded4ab67dac3178d6a33d7eebe42b|$SPA"
"d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a|$GJS"
"4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51|$GCS"
)
for rec in "${checks[@]}"; do exp="${rec%%|*}"; file="${rec#*|}"; [ -f "$file" ] || fail "Baseline file missing: $file"; got="$(sha256sum "$file"|awk '{print $1}')"; [ "$got" = "$exp" ] || fail "Unknown/newer live baseline at $file. Expected V19 $exp, got $got. Nothing changed."; done; echo "PASS: exact successful V19 baseline confirmed."

echo; echo "3/13 PACKAGE INTEGRITY + SYNTAX"
cd "$SELF_DIR"; sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || fail "Payload checksum mismatch."; [ "$(sha256sum brand-lock/brand-contract.json|awk '{print $1}')" = "17660b5d7fc13b1dcce75fa653c7409d71aa89ae188572a31cac6b7a0e60d25a" ] || fail "Brand contract SHA mismatch."; node -c dist/index.cjs >/dev/null || fail "Server runtime syntax invalid."; node --check dist/public/dgj-brand-contract-v27.js >/dev/null; node --check dist/public/dgj-brand-lock.js >/dev/null; node --check dist/public/dgj-google-jobs-v27.js >/dev/null; bash -n "$SELF_DIR/deploy-final-safe.sh"; python3 -m py_compile source/script/apply-brand-lock-source.py; for f in source/script/*.mjs; do node --check "$f" >/dev/null; done; grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27' dist/index.cjs || fail "Brand lock missing."; grep -Fq 'DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27' dist/index.cjs || fail "Google Jobs lock missing."; echo "PASS: exact reviewed V27 package validated."

echo; echo "4/13 BACKUP EVERY TOUCHED FILE"
mkdir -p "$BACKUP/files"; :>"$BACKUP/existed.txt"; :>"$BACKUP/touched.txt"
TOUCHED=(
'dist/index.cjs' 'dist/public/index.html' 'dist/public/assets/index-DGJ45auth-v11.js'
'dist/public/dgj-brand-contract-v27.js' 'dist/public/dgj-brand-lock.js' 'dist/public/dgj-google-jobs-v27.js' 'dist/public/brand-contract.json' 'dist/public/llms.txt'
'server/seoMeta.ts' 'server/brandSeo.ts' 'client/index.html' 'client/public/robots.txt' 'package.json'
'client/public/dgj-brand-contract-v27.js' 'client/public/dgj-brand-lock.js' 'client/public/dgj-google-jobs-v27.js' 'client/public/brand-contract.json' 'client/public/llms.txt'
'script/apply-brand-lock-source.py' 'script/patch-job-schema-client.mjs' 'script/patch-runtime-brand-meta.mjs' 'script/sync-brand-contract.mjs' 'script/verify-brand-lock.mjs' 'script/verify-google-jobs-schema.mjs'
'brand-lock/brand-contract.json' 'brand-lock/BRAND-CONTRACT.sha256'
)
for rel in "${TOUCHED[@]}"; do echo "$rel" >> "$BACKUP/touched.txt"; if [ -e "$APP_DIR/$rel" ]; then echo "$rel" >> "$BACKUP/existed.txt"; mkdir -p "$BACKUP/files/$(dirname "$rel")"; cp -a "$APP_DIR/$rel" "$BACKUP/files/$rel"; fi; done; echo "Backup: $BACKUP"

echo; echo "5/13 INSTALL SOURCE-OF-TRUTH LOCK"
cd "$APP_DIR"; python3 "$SELF_DIR/source/script/apply-brand-lock-source.py" "$APP_DIR" || fail "Source brand lock installer failed."; SOURCE_PATCHED=1; node script/verify-brand-lock.mjs || fail "Source brand verifier failed."; node script/verify-google-jobs-schema.mjs || fail "Source Google Jobs verifier failed."; echo "PASS: permanent source/build gates installed."

echo; echo "6/13 ATOMIC RUNTIME COPY"
copy_atomic(){ local src="$1" dst="$2" tmp="${2}.v27tmp.$$"; mkdir -p "$(dirname "$dst")"; cp -a "$src" "$tmp"; mv -f "$tmp" "$dst"; }
copy_atomic "$SELF_DIR/dist/index.cjs" "$SERVER"; copy_atomic "$SELF_DIR/dist/public/index.html" "$INDEX"; copy_atomic "$SELF_DIR/dist/public/assets/index-DGJ45auth-v11.js" "$SPA"; for f in dgj-brand-contract-v27.js dgj-brand-lock.js dgj-google-jobs-v27.js brand-contract.json llms.txt; do copy_atomic "$SELF_DIR/dist/public/$f" "$APP_DIR/dist/public/$f"; done; COPIED=1; node -c "$SERVER" >/dev/null || fail "Live server syntax invalid after copy."; echo "PASS: only reviewed runtime/SEO assets installed."

echo; echo "7/13 RELOAD ONLY MAIN APP + HEALTH"
pm2 reload devglobaljobs --update-env; sleep 2; pm2 describe devglobaljobs | grep -q 'online' || fail "PM2 app not online."; curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "API unhealthy after reload."; echo "PASS: PM2 and API healthy."

echo; echo "8/13 EVERY STATIC PUBLIC ROUTE"
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYROUTES'
import json,html,re,subprocess,sys
c=json.load(open(sys.argv[1])); routes=c['staticRoutes']
for route,exp in routes.items():
 b=subprocess.check_output(['curl','-fsS','-H','Host: devglobaljobs.com','http://127.0.0.1:8080'+route+'?v27=1'],text=True)
 mt=re.search(r'<title[^>]*>(.*?)</title>',b,re.I|re.S); title=html.unescape(mt.group(1).strip()) if mt else ''
 md=re.search(r'<meta\s+name=["\']description["\']\s+content=["\']([^"\']*)',b,re.I|re.S); desc=html.unescape(md.group(1).strip()) if md else ''
 if title!=exp['title']: raise SystemExit(f'{route} title mismatch: {title!r}')
 if desc!=exp['description']: raise SystemExit(f'{route} description mismatch')
 if re.search(r'\b(Jobs|Careers|Opportunities)\s+\1\b',title,re.I): raise SystemExit(f'{route} duplicate wording')
 if re.search(r'["\']@type["\']\s*:\s*["\']JobPosting["\']',b,re.I): raise SystemExit(f'{route} must not contain JobPosting JSON-LD')
print('PASS:',len(routes),'static public routes; no JobPosting found on list/content routes')
PYROUTES

echo; echo "9/13 COUNTRIES + CITY + PRIVATE NOINDEX"
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYLOC'
import json,html,re,subprocess,sys
c=json.load(open(sys.argv[1])); p=c['dynamicPatterns']['country']
for slug,name in c['countries'].items():
 route='/jobs/country/'+slug; b=subprocess.check_output(['curl','-fsS','-H','Host: devglobaljobs.com','http://127.0.0.1:8080'+route+'?v27=1'],text=True); mt=re.search(r'<title[^>]*>(.*?)</title>',b,re.I|re.S); title=html.unescape(mt.group(1).strip()) if mt else ''; exp=p['title'].replace('{Country}',name)
 if title!=exp: raise SystemExit(f'{route} country title mismatch: {title!r} != {exp!r}')
print('PASS:',len(c['countries']),'explicit country landing routes')
PYLOC
CITY="$(curl -fsS -H 'Host: devglobaljobs.com' http://127.0.0.1:8080/jobs/city/dubai?v27=1)"; printf '%s' "$CITY" | grep -Fq 'Jobs in Dubai | Career Opportunities | Dev Global Jobs' || fail "City metadata mismatch."; printf '%s' "$CITY" | grep -Eiq '["'"'"']@type["'"'"'] *: *["'"'"']JobPosting["'"'"']' && fail "City list page contains JobPosting JSON-LD."
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYPRIVATE'
import json,re,subprocess,sys
c=json.load(open(sys.argv[1]))
for route in c['privateRoutes']:
 h=subprocess.run(['curl','-fsS','-D','-','-H','Host: devglobaljobs.com','http://127.0.0.1:8080'+route+'?v27=1'],text=True,capture_output=True,check=True).stdout
 if not (re.search(r'X-Robots-Tag:\s*noindex,?\s*nofollow',h,re.I) or re.search(r'<meta\s+name=["\'](?:robots|googlebot)["\'][^>]+content=["\']noindex,?\s*nofollow',h,re.I)):
  raise SystemExit(f'{route} private noindex missing')
print('PASS:',len(c['privateRoutes']),'private contract routes noindex')
PYPRIVATE
curl -fsS -H 'Host: devglobaljobs.com' http://127.0.0.1:8080/sign-in?v27=1 -o /tmp/dgj-v27-signin.html; grep -Fq 'DGJ_AUTH_MOBILE_V19' /tmp/dgj-v27-signin.html || fail "V19 mobile auth missing."; rm -f /tmp/dgj-v27-signin.html; echo "PASS: location metadata + private noindex + mobile auth preserved."

echo; echo "10/13 PUBLIC BRAND / LLM IDENTITY"
curl -fsS https://devglobaljobs.com/brand-contract.json | grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27' || fail "Public contract missing."; curl -fsS https://devglobaljobs.com/dgj-brand-contract-v27.js | grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27' || fail "Preloaded contract missing."; curl -fsS https://devglobaljobs.com/llms.txt | grep -Fq 'International Careers Platform' || fail "llms.txt identity missing."; echo "PASS: machine-readable identity served."

echo; echo "11/13 GOOGLE JOBS STRUCTURED DATA"
cd "$APP_DIR"
node script/verify-brand-lock.mjs --dist || fail "Runtime brand gate failed."
node script/verify-google-jobs-schema.mjs --dist || fail "Runtime Google Jobs gate failed."
curl -fsS --max-time 20 'http://127.0.0.1:8080/api/jobs/all?limit=100&offset=0' -o /tmp/dgj-v27-jobs.json || fail "Jobs API sample failed."
SAMPLE_ID="$(python3 - /tmp/dgj-v27-jobs.json <<'PYSAMPLE'
import datetime,json,sys
with open(sys.argv[1],encoding='utf-8') as f: d=json.load(f)
jobs=d.get('jobs',[]) if isinstance(d,dict) else d
now=datetime.datetime.now(datetime.timezone.utc)
bad={'worldwide','global','remote','anywhere','international'}
for j in jobs:
    c=str(j.get('country') or '').strip().lower()
    if not (j.get('id') and j.get('title') and j.get('organization') and j.get('description') and j.get('postedAt') and c and c not in bad):
        continue
    closing=j.get('closingDate')
    if closing:
        try:
            dt=datetime.datetime.fromisoformat(str(closing).replace('Z','+00:00'))
            if dt.tzinfo is None: dt=dt.replace(tzinfo=datetime.timezone.utc)
            if dt < now: continue
        except Exception:
            pass
    print(j['id'])
    break
PYSAMPLE
)"
rm -f /tmp/dgj-v27-jobs.json
[ -n "$SAMPLE_ID" ] || fail "No complete active sample job available for schema smoke test."
curl -fsS -H 'Host: devglobaljobs.com' "http://127.0.0.1:8080/jobs/detail/${SAMPLE_ID}?v27=1" -o /tmp/dgj-v27-job.html || fail "Job detail fetch failed."
python3 - /tmp/dgj-v27-job.html <<'PYSCHEMA' || fail "JobPosting JSON-LD validation failed."
import json,re,sys
h=open(sys.argv[1],encoding='utf-8',errors='ignore').read()
blocks=re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',h,re.I|re.S)
jobpostings=[]
def walk(v):
 if isinstance(v,dict):
  t=v.get('@type')
  if t=='JobPosting' or (isinstance(t,list) and 'JobPosting' in t): jobpostings.append(v)
  for x in v.values(): walk(x)
 elif isinstance(v,list):
  for x in v: walk(x)
for raw in blocks:
 try: walk(json.loads(raw))
 except Exception: pass
assert len(jobpostings)==1, f'expected exactly 1 JobPosting across all JSON-LD, got {len(jobpostings)}'
s=jobpostings[0]
assert s.get('title') and s.get('description') and s.get('datePosted')
assert s.get('hiringOrganization',{}).get('name')
assert s.get('url','').startswith('https://devglobaljobs.com/jobs/detail/')
assert s.get('directApply') is False
loc=(s.get('jobLocation',{}).get('address',{}).get('addressCountry') or s.get('applicantLocationRequirements',{}).get('name'))
assert loc and str(loc).lower() not in {'worldwide','global','anywhere','remote','international'}
if s.get('jobLocation'):
 assert s['jobLocation'].get('address',{}).get('addressCountry'), 'physical JobPosting missing addressCountry'
if s.get('jobLocationType')=='TELECOMMUTE':
 assert s.get('applicantLocationRequirements',{}).get('name'), 'remote JobPosting missing applicantLocationRequirements'
print('PASS: exactly one complete factual JobPosting validated across all JSON-LD')
PYSCHEMA
rm -f /tmp/dgj-v27-job.html
echo "PASS: one and only one server-rendered JobPosting verified on job ID $SAMPLE_ID."

echo; echo "12/13 SITEMAP PRESERVATION"
SM="$(curl -fsSL --max-time 30 https://devglobaljobs.com/sitemap.xml)" || fail "Master sitemap unavailable."
EXPECTED_SITEMAPS=(
 sitemap-pages.xml sitemap-cities.xml sitemap-blog.xml sitemap-jobs-latest.xml
 sitemap-jobs-ae.xml sitemap-jobs-ar.xml sitemap-jobs-at.xml sitemap-jobs-au.xml sitemap-jobs-bd.xml sitemap-jobs-be.xml sitemap-jobs-bg.xml sitemap-jobs-br.xml sitemap-jobs-ca.xml sitemap-jobs-ch.xml sitemap-jobs-cl.xml sitemap-jobs-cn.xml sitemap-jobs-co.xml sitemap-jobs-cy.xml sitemap-jobs-cz.xml sitemap-jobs-de.xml sitemap-jobs-dk.xml sitemap-jobs-ee.xml sitemap-jobs-eg.xml sitemap-jobs-es.xml sitemap-jobs-et.xml sitemap-jobs-fi.xml sitemap-jobs-fr.xml sitemap-jobs-gb.xml sitemap-jobs-gh.xml sitemap-jobs-gr.xml sitemap-jobs-hu.xml sitemap-jobs-id.xml sitemap-jobs-ie.xml sitemap-jobs-il.xml sitemap-jobs-in.xml sitemap-jobs-it.xml sitemap-jobs-jp.xml sitemap-jobs-ke.xml sitemap-jobs-kr.xml sitemap-jobs-lt.xml sitemap-jobs-lu.xml sitemap-jobs-ma.xml sitemap-jobs-mx.xml sitemap-jobs-my.xml sitemap-jobs-ng.xml sitemap-jobs-nl.xml sitemap-jobs-no.xml sitemap-jobs-nz.xml sitemap-jobs-ph.xml sitemap-jobs-pk.xml sitemap-jobs-pl.xml sitemap-jobs-pt.xml sitemap-jobs-qa.xml sitemap-jobs-ro.xml sitemap-jobs-rs.xml sitemap-jobs-sa.xml sitemap-jobs-se.xml sitemap-jobs-sg.xml sitemap-jobs-si.xml sitemap-jobs-sk.xml sitemap-jobs-th.xml sitemap-jobs-tz.xml sitemap-jobs-ug.xml sitemap-jobs-us.xml sitemap-jobs-vn.xml sitemap-jobs-za.xml
 sitemap-jobs-remote-worldwide.xml sitemap-jobs-1.xml sitemap-jobs-2.xml sitemap-jobs-3.xml
)
for needle in "${EXPECTED_SITEMAPS[@]}"; do printf '%s' "$SM" | grep -Fq "$needle" || fail "Sitemap index missing $needle"; done
for shard in sitemap-jobs-latest.xml sitemap-jobs-qa.xml sitemap-jobs-us.xml sitemap-jobs-remote-worldwide.xml sitemap-jobs-1.xml; do
 XML="$(curl -fsSL --max-time 30 "https://devglobaljobs.com/$shard")" || fail "$shard unavailable."
 printf '%s' "$XML" | grep -Eq 'https://devglobaljobs.com/jobs/detail/[0-9]+' || fail "$shard has no canonical job detail URLs."
done
echo "PASS: sitemap index contains all supplied shards; representative job shards contain canonical detail URLs."

echo; echo "13/13 PRESERVATION + SAVE"
[ "$(sha256sum "$GJS"|awk '{print $1}')" = "d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a" ] || fail "Growth JS changed unexpectedly."; [ "$(sha256sum "$GCS"|awk '{print $1}')" = "4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51" ] || fail "Growth CSS changed unexpectedly."; curl -fsS https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy."; pm2 save >/dev/null; COPIED=0; SOURCE_PATCHED=0; trap - ERR

echo; echo "============================================================"; echo "SUCCESS: PERMANENT BRAND + GOOGLE JOBS V27 IS LIVE"; echo "============================================================"; echo "  ✓ Source-of-truth International Careers brand contract"; echo "  ✓ All reviewed main routes have explicit titles/descriptions"; echo "  ✓ All Jobs, International Jobs and Sponsored Jobs remain distinct"; echo "  ✓ Featured remains placement/status only"; echo "  ✓ Exactly one factual JobPosting on eligible individual job pages"; echo "  ✓ No JobPosting on category/country/city/list pages"; echo "  ✓ No fake Worldwide country, synthetic datePosted or synthetic 30-day expiry"; echo "  ✓ No guessed bare-dollar salary currency"; echo "  ✓ Sitemap architecture preserved"; echo "  ✓ V19 auth / OTP / app functionality preserved"; echo "  ✓ Database untouched; no npm build; no drizzle-kit push"; echo "Rollback backup: $BACKUP"; echo "============================================================"
