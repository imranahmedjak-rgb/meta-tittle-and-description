# Dev Global Jobs V27 Permanent Brand + Google Jobs Schema Safe Final

V27 supersedes V20-V26 and is designed for the exact successful V19 live runtime baseline.

## Permanent source-of-truth brand lock

- One authoritative `brand-lock/brand-contract.json` controls public route metadata.
- `/jobs/all`, `/jobs/international`, and `/jobs/sponsored` are permanently separate search intents.
- Sponsored remains Sponsored. Featured remains a placement/status only and has no standalone SEO route.
- The actual V19 SPA router was audited: 72 route patterns, with 0 missing from the contract/policy layer.
- Main categories, industries, youth, tools, resources, employer, developer, legal, country and city routes are covered.
- Normal future source builds run prebuild synchronization and postbuild verification gates so brand drift causes build failure instead of silent SEO regression.

## Google Jobs structured-data lock

The JobPosting layer follows Google Search Central's current JobPosting requirements as a technical eligibility safeguard:

- `JobPosting` is emitted only on a single individual `/jobs/detail/{id}` leaf page.
- Required factual data: stored job title, complete stored description, stored original `postedAt`, stored hiring organization, and a valid physical or remote geographic location.
- Physical jobs include `PostalAddress.addressCountry`.
- Fully remote jobs use `jobLocationType: TELECOMMUTE` and a real `applicantLocationRequirements` country. `Worldwide`, `Global`, `Anywhere`, `Remote` and `International` are never fabricated as a Country.
- `validThrough` is emitted only when a real stored closing date exists. No synthetic 30-day expiry.
- Expired jobs receive no active JobPosting markup and are noindexed on the detail response.
- `baseSalary` is emitted only for employer-posted jobs with an explicit supported currency and explicit HOUR/DAY/WEEK/MONTH/YEAR pay period. A bare `$` is never guessed.
- `directApply` remains `false` because the current application journey can include an apply action/authentication.
- Exactly one server-visible JobPosting is allowed; legacy duplicate client/server generators are blocked.
- Server JSON-LD uses safe serialization for job-controlled text.

A job missing Google's required factual fields is deliberately not given fabricated structured data. This protects the domain from invalid or misleading JobPosting markup. Google controls final crawl, indexing, ranking and Google Jobs inclusion.

## Sitemap / freshness

V27 preserves the separate sitemap service and validates the existing page, city, blog, latest-job, country-job, remote-worldwide and paginated job shards after deployment. For job URLs, Google also recommends the Indexing API for faster add/update/removal discovery while still recommending sitemaps for site-wide coverage.

Contract SHA-256: `17660b5d7fc13b1dcce75fa653c7409d71aa89ae188572a31cac6b7a0e60d25a`
