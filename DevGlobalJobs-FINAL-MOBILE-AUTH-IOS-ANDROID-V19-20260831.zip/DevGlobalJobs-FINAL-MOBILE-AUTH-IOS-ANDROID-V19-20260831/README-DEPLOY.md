# Dev Global Jobs V19 — Mobile Auth iOS + Android

This is a surgical production patch based on the exact successful V18 live baseline.

## Requested change

The `/sign-in` and `/sign-in?mode=signup` experience is polished for iPhone and Android without changing the desktop site or unrelated features.

- Compact mobile header, hero, logo, spacing, tabs, inputs and buttons.
- 16px input/select text on mobile to prevent Safari auto-zoom.
- `viewport-fit=cover`, safe-area padding and `100dvh` support.
- Responsive Google Identity button width instead of a fixed 360px width.
- English Google button rendering on the English auth page to avoid mixed RTL/LTR presentation.
- 320px, 360px, 390px, 430px and landscape-safe responsive rules.
- Server-native OTP, no-flash account creation and forgot-password flows remain intact.

## Preservation

The package reconstructs and preserves the successful V18 homepage metadata:

Title: `Dev Global Jobs | International Jobs, Remote Work & Global Careers`

Description: `Find international jobs, remote work, visa sponsored opportunities and global careers. Explore thousands of jobs worldwide and take the next step with Dev Global Jobs.`

It also preserves V16 related 3+3 job cards, employer priority, PayPal, Wise, Trustpilot, Easy Apply, API/RSS, mobile/admin fixes and all prior auth behavior.

## Safe deployment

```bash
APP_DIR=/var/www/devglobaljobs bash deploy-final-safe.sh
```

The deployment script collision-checks the exact successful V18 `dist/index.cjs` and `dist/public/index.html`, backs up only the server runtime, atomically replaces only `dist/index.cjs`, reloads only `devglobaljobs`, checks the public sign-in HTML and verifies the V18 homepage metadata remains live. It rolls back automatically on failure.

No `npm build`, no `drizzle-kit push`, no full-site replacement.
