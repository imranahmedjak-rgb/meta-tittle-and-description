#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/var/www/devglobaljobs}"
SERVER="$APP_DIR/dist/index.cjs"
INDEX="$APP_DIR/dist/public/index.html"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-mobile-auth-v19-${STAMP}"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD_SERVER="$SELF_DIR/dist/index.cjs"

V18_SERVER_SHA="a452a4cc479e209bfbbf877aecd8dd165821694706a31a5e73f8b908a37e1900"
V18_INDEX_SHA="120bd1d247779dab7c027f453bb7701f7a91b57d787ffba3033b82705fb35bfa"
V16_GROWTH_JS_SHA="d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a"
V16_GROWTH_CSS_SHA="4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51"

NEW_TITLE='Dev Global Jobs | International Jobs, Remote Work & Global Careers'
NEW_DESC='Find international jobs, remote work, visa sponsored opportunities and global careers. Explore thousands of jobs worldwide and take the next step with Dev Global Jobs.'

COPIED=0
rollback(){
  if [ "$COPIED" = "1" ] && [ -f "$BACKUP/index.cjs" ]; then
    echo
    echo "ROLLBACK: restoring pre-V19 server runtime..."
    cp -a "$BACKUP/index.cjs" "$SERVER"
    pm2 reload devglobaljobs >/dev/null 2>&1 || true
    sleep 3
    echo "ROLLBACK COMPLETE."
  fi
}
fail(){ echo; echo "============================================================"; echo "SAFE STOP: $*"; echo "============================================================"; rollback; exit 1; }
trap 'fail "unexpected deployment error"' ERR

[ "$(id -u)" = "0" ] || fail "Run as root."
[ -f "$SERVER" ] || fail "Live server runtime missing."
[ -f "$INDEX" ] || fail "Live homepage index missing."
[ -f "$PAYLOAD_SERVER" ] || fail "V19 payload server missing."
for c in curl sha256sum node pm2 grep cp mkdir install stat mv awk; do command -v "$c" >/dev/null 2>&1 || fail "Missing command: $c"; done

echo "============================================================"
echo "1/8 CURRENT LIVE HEALTH"
echo "============================================================"
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy."
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy."
echo "PASS: current website healthy."

echo; echo "============================================================"; echo "2/8 COLLISION PROTECTION — EXACT SUCCESSFUL V18"; echo "============================================================"
LIVE_SERVER_SHA="$(sha256sum "$SERVER" | awk '{print $1}')"
LIVE_INDEX_SHA="$(sha256sum "$INDEX" | awk '{print $1}')"
[ "$LIVE_SERVER_SHA" = "$V18_SERVER_SHA" ] || fail "Live index.cjs is not the exact successful V18 baseline. Nothing changed."
[ "$LIVE_INDEX_SHA" = "$V18_INDEX_SHA" ] || fail "Live homepage index.html is not the exact successful V18 baseline. Nothing changed."
[ "$(sha256sum "$APP_DIR/dist/public/assets/growth-suite.js" | awk '{print $1}')" = "$V16_GROWTH_JS_SHA" ] || fail "Growth Suite differs from preserved V16/V18 baseline."
[ "$(sha256sum "$APP_DIR/dist/public/assets/growth-suite.css" | awk '{print $1}')" = "$V16_GROWTH_CSS_SHA" ] || fail "Growth CSS differs from preserved V16/V18 baseline."
echo "PASS: exact V18 baseline confirmed."

echo; echo "============================================================"; echo "3/8 PACKAGE + MOBILE AUTH VALIDATION"; echo "============================================================"
cd "$SELF_DIR"
sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || fail "Payload checksum validation failed."
node -c "$PAYLOAD_SERVER" >/dev/null || fail "V19 server syntax invalid."
grep -Fq 'DGJ_AUTH_MOBILE_V19' "$PAYLOAD_SERVER" || fail "V19 responsive auth marker missing."
grep -Fq 'viewport-fit=cover' "$PAYLOAD_SERVER" || fail "iPhone safe-area viewport support missing."
grep -Fq 'font-size:16px' "$PAYLOAD_SERVER" || fail "iPhone anti-zoom input sizing missing."
grep -Fq "var buttonWidth=Math.max(220,Math.min(360,available))" "$PAYLOAD_SERVER" || fail "Responsive Google button sizing missing."
grep -Fq "locale:'en'" "$PAYLOAD_SERVER" || fail "Consistent English Google button locale missing."
grep -Fq "$NEW_TITLE" "$PAYLOAD_SERVER" || fail "V18 homepage meta title not preserved in V19 payload."
grep -Fq "$NEW_DESC" "$PAYLOAD_SERVER" || fail "V18 homepage meta description not preserved in V19 payload."
echo "PASS: iPhone/Android auth package validated."

echo; echo "============================================================"; echo "4/8 BACKUP TOUCHED V18 FILE"; echo "============================================================"
mkdir -p "$BACKUP"
cp -a "$SERVER" "$BACKUP/index.cjs"
echo "Backup: $BACKUP"

echo; echo "============================================================"; echo "5/8 ATOMIC V19 SERVER COPY"; echo "============================================================"
TMP_SERVER="$APP_DIR/dist/.index.cjs.v19.${STAMP}.tmp"
install -m "$(stat -c '%a' "$SERVER")" "$PAYLOAD_SERVER" "$TMP_SERVER"
mv -f "$TMP_SERVER" "$SERVER"
COPIED=1
echo "PASS: only dist/index.cjs replaced."

echo; echo "============================================================"; echo "6/8 PM2 RELOAD + API HEALTH"; echo "============================================================"
pm2 reload devglobaljobs
sleep 4
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "API unhealthy after V19 reload."
echo "PASS: PM2 and API healthy."

echo; echo "============================================================"; echo "7/8 SIGN-IN MOBILE DELIVERY CHECK"; echo "============================================================"
BUST="$(date +%s)"
NODE_AUTH="/tmp/dgj-v19-node-${STAMP}.html"
PUBLIC_AUTH="/tmp/dgj-v19-public-${STAMP}.html"
curl -fsS -H 'Host: devglobaljobs.com' "http://127.0.0.1:8080/sign-in?v19=${BUST}" -o "$NODE_AUTH" || fail "Direct Node sign-in fetch failed."
grep -Fq 'DGJ_AUTH_MOBILE_V19' "$NODE_AUTH" || fail "Direct Node does not serve V19 mobile auth."
grep -Fq 'viewport-fit=cover' "$NODE_AUTH" || fail "Direct Node auth missing iPhone viewport-fit."
grep -Fq 'font-size:16px' "$NODE_AUTH" || fail "Direct Node auth missing mobile input size."
curl -fsS -H 'Cache-Control: no-cache, no-store, max-age=0' "https://devglobaljobs.com/sign-in?v19=${BUST}" -o "$PUBLIC_AUTH" || fail "Public sign-in fetch failed."
grep -Fq 'DGJ_AUTH_MOBILE_V19' "$PUBLIC_AUTH" || fail "Public sign-in does not serve V19 mobile auth."
grep -Fq "locale:'en'" "$PUBLIC_AUTH" || fail "Public auth Google button locale not updated."
rm -f "$NODE_AUTH" "$PUBLIC_AUTH"
echo "PASS: V19 responsive sign-in is publicly served."

echo; echo "============================================================"; echo "8/8 V18 META + PRESERVATION CHECK"; echo "============================================================"
HOME="/tmp/dgj-v19-home-${STAMP}.html"
curl -fsS -H 'Cache-Control: no-cache, no-store, max-age=0' "https://devglobaljobs.com/?v19=${BUST}" -o "$HOME" || fail "Public homepage fetch failed."
grep -Fq "$NEW_TITLE" "$HOME" || fail "V18 homepage meta title was not preserved."
grep -Fq "$NEW_DESC" "$HOME" || fail "V18 homepage meta description was not preserved."
[ "$(sha256sum "$INDEX" | awk '{print $1}')" = "$V18_INDEX_SHA" ] || fail "V18 static homepage metadata file changed unexpectedly."
[ "$(sha256sum "$APP_DIR/dist/public/assets/growth-suite.js" | awk '{print $1}')" = "$V16_GROWTH_JS_SHA" ] || fail "Related jobs/PayPal Growth Suite changed unexpectedly."
rm -f "$HOME"
pm2 save >/dev/null
COPIED=0
trap - ERR

echo
echo "============================================================"
echo "SUCCESS: MOBILE AUTH IOS + ANDROID V19 IS LIVE"
echo "============================================================"
echo "  ✓ iPhone and Android responsive auth layout"
echo "  ✓ Compact mobile hero and spacing"
echo "  ✓ 16px mobile inputs prevent iPhone auto-zoom"
echo "  ✓ Google button width adapts to phone width"
echo "  ✓ English Google button on English sign-in page"
echo "  ✓ iOS safe-area and dynamic viewport support"
echo "  ✓ 320px+ mobile widths protected from horizontal overflow"
echo "  ✓ V18 homepage meta title/description preserved"
echo "  ✓ Server-native OTP and Create Account no-flash preserved"
echo "  ✓ V16 related 3+3 cards, PayPal, Wise and Trustpilot preserved"
echo "  ✓ Database untouched"
echo "  ✓ No npm build / no drizzle-kit push / no full-site replacement"
echo "Rollback backup: $BACKUP"
echo "============================================================"
