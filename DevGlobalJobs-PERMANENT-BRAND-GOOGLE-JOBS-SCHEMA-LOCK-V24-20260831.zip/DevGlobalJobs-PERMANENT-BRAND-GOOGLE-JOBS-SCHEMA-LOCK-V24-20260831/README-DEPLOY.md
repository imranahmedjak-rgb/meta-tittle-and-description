# Dev Global Jobs V24 Permanent Brand + Google Jobs Schema Lock

V24 supersedes V22 and V23. It keeps the V23 source-of-truth International Careers brand contract and adds a separate permanent Google Jobs schema lock for individual job-detail pages.

## Google JobPosting design

- `JobPosting` appears only on individual `/jobs/detail/{id}` pages, never category/list/search pages.
- Required Google fields are generated only from real stored job data: `title`, full `description`, original `datePosted`, and `hiringOrganization`.
- Physical jobs require a real `addressCountry`; fully remote jobs require a real applicant country before JobPosting markup is emitted. No fake `Worldwide` country is created.
- `validThrough` is included only when a real closing date exists; no synthetic 30-day expiry is created.
- Employer-provided salary markup is emitted only for employer-posted jobs and only when currency + pay period can be parsed without guessing.
- `employmentType` maps to Google's accepted values.
- `directApply` remains `false` to avoid overstating the application experience.
- Expired jobs are noindex and do not receive active JobPosting markup.
- The old React JSON-LD generator, imported-job `noindex` override, and legacy inline Premium Job SEO Engine are removed/disabled so rendered pages do not contain conflicting JobPosting schemas.

## Permanent source/build lock

`server/brandSeo.ts` is the server source of truth. `client/public/dgj-google-jobs-v24.js` mirrors the rules for SPA navigation. A postbuild patcher disables the legacy bundle generator, and a postbuild verifier fails the build if the Google Jobs contract is missing or inconsistent.

## Important

Correct JobPosting markup makes eligible job pages easier for Google to understand, but Google does not guarantee inclusion in Google Jobs. New/updated job URLs should also be kept crawlable and submitted through Google's Indexing API plus sitemap/Search Console workflow.
