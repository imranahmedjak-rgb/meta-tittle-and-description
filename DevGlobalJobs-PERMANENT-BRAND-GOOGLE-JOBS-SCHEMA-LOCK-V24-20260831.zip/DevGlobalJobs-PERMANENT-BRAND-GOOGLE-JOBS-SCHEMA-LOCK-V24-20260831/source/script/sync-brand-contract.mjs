import fs from "fs";
import path from "path";
const root=process.cwd();
const src=path.join(root,"brand-lock","brand-contract.json");
const dest=path.join(root,"client","public","brand-contract.json");
if(!fs.existsSync(src))throw new Error(`DGJ Brand Lock: missing ${src}`);
fs.mkdirSync(path.dirname(dest),{recursive:true});
fs.copyFileSync(src,dest);
console.log("DGJ Brand Lock: client contract synchronized.");
