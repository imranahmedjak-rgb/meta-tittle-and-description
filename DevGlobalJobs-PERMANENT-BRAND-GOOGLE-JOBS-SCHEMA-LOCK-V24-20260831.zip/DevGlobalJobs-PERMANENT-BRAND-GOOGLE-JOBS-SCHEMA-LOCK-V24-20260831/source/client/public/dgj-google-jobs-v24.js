/* DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V24
   One authoritative client-side companion for Google JobPosting metadata.
   Server-rendered JSON-LD remains the primary crawler-facing source. This file
   keeps SPA navigation consistent and replaces only the V24-owned schema IDs.
*/
(function(){
'use strict';
var MARK='DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V24';
var BASE='https://devglobaljobs.com';
var COUNTRY_ALIASES={
 'US':'US','USA':'US','UNITED STATES':'US','UNITED STATES OF AMERICA':'US',
 'GB':'GB','UK':'GB','UNITED KINGDOM':'GB','GREAT BRITAIN':'GB',
 'CA':'CA','CANADA':'CA','AU':'AU','AUSTRALIA':'AU','NZ':'NZ','NEW ZEALAND':'NZ',
 'DE':'DE','GERMANY':'DE','FR':'FR','FRANCE':'FR','NL':'NL','NETHERLANDS':'NL','CH':'CH','SWITZERLAND':'CH',
 'IE':'IE','IRELAND':'IE','ES':'ES','SPAIN':'ES','IT':'IT','ITALY':'IT','PT':'PT','PORTUGAL':'PT',
 'SE':'SE','SWEDEN':'SE','NO':'NO','NORWAY':'NO','DK':'DK','DENMARK':'DK','FI':'FI','FINLAND':'FI','AT':'AT','AUSTRIA':'AT','BE':'BE','BELGIUM':'BE',
 'PL':'PL','POLAND':'PL','CZ':'CZ','CZECH REPUBLIC':'CZ','HU':'HU','HUNGARY':'HU','RO':'RO','ROMANIA':'RO','GR':'GR','GREECE':'GR','TR':'TR','TURKEY':'TR','UA':'UA','UKRAINE':'UA',
 'AE':'AE','UAE':'AE','UNITED ARAB EMIRATES':'AE','QA':'QA','QATAR':'QA','SA':'SA','SAUDI ARABIA':'SA','KW':'KW','KUWAIT':'KW','BH':'BH','BAHRAIN':'BH','OM':'OM','OMAN':'OM',
 'IN':'IN','INDIA':'IN','PK':'PK','PAKISTAN':'PK','BD':'BD','BANGLADESH':'BD','LK':'LK','SRI LANKA':'LK','NP':'NP','NEPAL':'NP','AF':'AF','AFGHANISTAN':'AF',
 'SG':'SG','SINGAPORE':'SG','MY':'MY','MALAYSIA':'MY','ID':'ID','INDONESIA':'ID','PH':'PH','PHILIPPINES':'PH','TH':'TH','THAILAND':'TH','VN':'VN','VIETNAM':'VN','JP':'JP','JAPAN':'JP','KR':'KR','SOUTH KOREA':'KR','HK':'HK','HONG KONG':'HK',
 'ZA':'ZA','SOUTH AFRICA':'ZA','NG':'NG','NIGERIA':'NG','KE':'KE','KENYA':'KE','GH':'GH','GHANA':'GH','ET':'ET','ETHIOPIA':'ET','UG':'UG','UGANDA':'UG','TZ':'TZ','TANZANIA':'TZ','EG':'EG','EGYPT':'EG','MA':'MA','MOROCCO':'MA',
 'BR':'BR','BRAZIL':'BR','MX':'MX','MEXICO':'MX','AR':'AR','ARGENTINA':'AR','CO':'CO','COLOMBIA':'CO','CL':'CL','CHILE':'CL','PE':'PE','PERU':'PE'
};
function isoDate(v){if(!v)return null;var d=new Date(v);return isNaN(d.getTime())?null:d.toISOString().split('T')[0];}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function fullDescription(raw){
 if(!raw||!String(raw).trim())return null;
 var s=String(raw).replace(/<script[^>]*>[\s\S]*?<\/script>/gi,'').replace(/<style[^>]*>[\s\S]*?<\/style>/gi,'').trim();
 if(/<(p|ul|li|br)\b/i.test(s))return s;
 return s.split(/\n{2,}/).map(function(p){return '<p>'+esc(p.replace(/\n/g,' '))+'</p>';}).join('');
}
function country(raw,location){
 var r=String(raw||'').trim(); if(r){var u=r.toUpperCase(); if(COUNTRY_ALIASES[u])return COUNTRY_ALIASES[u]; if(/^[A-Z]{2}$/.test(u))return u; return r;}
 var loc=String(location||'').toUpperCase();
 var keys=Object.keys(COUNTRY_ALIASES).filter(function(k){return k.length>2;}).sort(function(a,b){return b.length-a.length;});
 for(var i=0;i<keys.length;i++){if(loc.indexOf(keys[i])>=0)return COUNTRY_ALIASES[keys[i]];}
 return null;
}
function empType(raw){
 var t=String(raw||'').toLowerCase().trim(); if(!t)return null;
 if(/full[ -]?time|permanent/.test(t))return 'FULL_TIME'; if(/part[ -]?time/.test(t))return 'PART_TIME';
 if(/contract|freelance|consult/.test(t))return 'CONTRACTOR'; if(/temporary|temp|seasonal|casual/.test(t))return 'TEMPORARY';
 if(/intern|trainee|apprentice/.test(t))return 'INTERN'; if(/volunteer|unpaid|pro.?bono/.test(t))return 'VOLUNTEER'; if(/per.?diem/.test(t))return 'PER_DIEM';
 return 'OTHER';
}
function remote(job){
 if(String(job.category||'').toLowerCase()==='remote')return true;
 if(/remote/i.test(String(job.workplaceType||'')))return true;
 return /(^|\b)(remote|work from home|work from anywhere|anywhere|worldwide|virtual|telecommute)(\b|$)/i.test(String(job.location||''));
}
function numberToken(s){var m=String(s).toLowerCase().replace(/,/g,'').match(/\d+(?:\.\d+)?\s*k?/g)||[];return m.map(function(x){var k=/k\s*$/i.test(x);var n=parseFloat(x);return k?n*1000:n;}).filter(function(n){return isFinite(n)&&n>0;});}
function salary(job,countryCode){
 if(!job.isEmployerPosted||!job.salary)return null;
 var s=String(job.salary), cur=null, unit=null;
 if(/\bUSD\b|US\$/i.test(s))cur='USD'; else if(/\bEUR\b|€/i.test(s))cur='EUR'; else if(/\bGBP\b|£/i.test(s))cur='GBP';
 else if(/\bCAD\b|CA\$/i.test(s))cur='CAD'; else if(/\bAUD\b|A\$/i.test(s))cur='AUD'; else if(/\bQAR\b/i.test(s))cur='QAR'; else if(/\bAED\b/i.test(s))cur='AED'; else if(/\bSAR\b/i.test(s))cur='SAR'; else if(/\bCHF\b/i.test(s))cur='CHF'; else if(/\bINR\b|₹/i.test(s))cur='INR'; else if(/\bPKR\b/i.test(s))cur='PKR'; else if(/\bSGD\b/i.test(s))cur='SGD';
 else if(/\$/.test(s))cur=countryCode==='CA'?'CAD':countryCode==='AU'?'AUD':'USD';
 if(/per\s*hour|\/\s*(hr|hour)\b|hourly/i.test(s))unit='HOUR'; else if(/per\s*day|\/\s*day\b|daily/i.test(s))unit='DAY'; else if(/per\s*week|\/\s*(wk|week)\b|weekly/i.test(s))unit='WEEK'; else if(/per\s*month|\/\s*(mo|month)\b|monthly/i.test(s))unit='MONTH'; else if(/per\s*year|\/\s*(yr|year)\b|annual|annum|yearly/i.test(s))unit='YEAR';
 if(!cur||!unit)return null; var nums=numberToken(s); if(!nums.length)return null; var q={'@type':'QuantitativeValue','unitText':unit};
 if(nums.length>=2){q.minValue=Math.min(nums[0],nums[1]);q.maxValue=Math.max(nums[0],nums[1]);}else q.value=nums[0];
 return {'@type':'MonetaryAmount','currency':cur,'value':q};
}
function build(job){
 if(!job||!job.id||!job.title||!job.organization)return null;
 var desc=fullDescription(job.description); var posted=isoDate(job.postedAt); if(!desc||!posted)return null;
 var canonical=BASE+'/jobs/detail/'+job.id; var closing=isoDate(job.closingDate); var now=new Date();
 if(closing){var end=new Date(closing+'T23:59:59Z'); if(end.getTime()<now.getTime())return null;}
 var c=country(job.country,job.location), isRemote=remote(job);
 var jp={'@context':'https://schema.org','@type':'JobPosting','@id':canonical+'#jobposting','title':String(job.title).trim(),'description':desc,'datePosted':posted,
   'hiringOrganization':{'@type':'Organization','name':String(job.organization).trim()},
   'identifier':{'@type':'PropertyValue','name':String(job.organization).trim(),'value':String(job.sourceId||job.id)},
   'url':canonical,'directApply':false};
 var et=empType(job.jobType); if(et)jp.employmentType=et; if(closing)jp.validThrough=closing;
 if(isRemote){if(!c)return null; jp.jobLocationType='TELECOMMUTE'; jp.applicantLocationRequirements={'@type':'Country','name':c};}
 else {if(!c)return null; jp.jobLocation={'@type':'Place','address':{'@type':'PostalAddress','addressLocality':String(job.location||c).trim(),'addressCountry':c}};}
 var bs=salary(job,c); if(bs)jp.baseSalary=bs; return jp;
}
function setMeta(selector,attr,value){var el=document.querySelector(selector);if(!el){el=document.createElement('meta');if(selector.indexOf('property=')>=0)el.setAttribute('property',selector.match(/property=["']([^"']+)/)[1]);else el.setAttribute('name',selector.match(/name=["']([^"']+)/)[1]);document.head.appendChild(el);}el.setAttribute(attr,value);}
function sync(job){
 var canonical=BASE+'/jobs/detail/'+job.id, closing=isoDate(job.closingDate), expired=closing&&new Date(closing+'T23:59:59Z').getTime()<Date.now();
 var title=String(job.title||'Job')+' at '+String(job.organization||'Employer')+' | Dev Global Jobs';
 var plain=String(job.description||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim(); var desc=(plain||('Review '+job.title+' at '+job.organization+' on Dev Global Jobs.')).slice(0,157); if(plain.length>157)desc=desc.replace(/\s+\S*$/,'')+'...';
 document.title=title; setMeta('meta[name="description"]','content',desc); setMeta('meta[property="og:title"]','content',title); setMeta('meta[property="og:description"]','content',desc); setMeta('meta[property="og:url"]','content',canonical); setMeta('meta[name="twitter:title"]','content',title); setMeta('meta[name="twitter:description"]','content',desc);
 var rob=expired?'noindex, nofollow':'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'; setMeta('meta[name="robots"]','content',rob); setMeta('meta[name="googlebot"]','content',rob);
 var link=document.querySelector('link[rel="canonical"]'); if(!link){link=document.createElement('link');link.rel='canonical';document.head.appendChild(link);}link.href=canonical;
 document.querySelectorAll('script[type="application/ld+json"]').forEach(function(el){if(el.id==='dgj-jobposting-v24'||el.id==='job-jsonld'||el.id==='dgj-job-graph'||el.id==='dgj-jobposting-schema')el.remove();});
 var schema=expired?null:build(job); if(schema){var sc=document.createElement('script');sc.id='dgj-jobposting-v24';sc.type='application/ld+json';sc.textContent=JSON.stringify(schema);document.head.appendChild(sc);}
 return function(){var e=document.getElementById('dgj-jobposting-v24');if(e)e.remove();};
}
window.DGJGoogleJobsV24={marker:MARK,build:build,sync:sync};
})();
