#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${APP_DIR:-/var/www/devglobaljobs}"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-brand-googlejobs-v24-${STAMP}"
SERVER="$APP_DIR/dist/index.cjs"; INDEX="$APP_DIR/dist/public/index.html"; SPA="$APP_DIR/dist/public/assets/index-DGJ45auth-v11.js"
GJS="$APP_DIR/dist/public/assets/growth-suite.js"; GCS="$APP_DIR/dist/public/assets/growth-suite.css"
COPIED=0; SOURCE_PATCHED=0
fail(){ echo; echo "============================================================"; echo "SAFE STOP: $*"; echo "============================================================"; rollback; exit 1; }
backup_one(){ local rel="$1"; if [ -e "$APP_DIR/$rel" ]; then mkdir -p "$BACKUP/source/$(dirname "$rel")"; cp -a "$APP_DIR/$rel" "$BACKUP/source/$rel"; echo "$rel" >> "$BACKUP/existed.txt"; fi; }
restore_source(){ [ -f "$BACKUP/existed.txt" ] || true; for rel in server/seoMeta.ts server/brandSeo.ts client/index.html client/public/dgj-brand-lock.js client/public/brand-contract.json client/public/llms.txt client/public/robots.txt script/verify-brand-lock.mjs script/sync-brand-contract.mjs client/public/dgj-google-jobs-v24.js script/patch-job-schema-client.mjs script/verify-google-jobs-schema.mjs package.json brand-lock/brand-contract.json brand-lock/BRAND-CONTRACT.sha256; do if grep -Fxq "$rel" "$BACKUP/existed.txt" 2>/dev/null; then mkdir -p "$APP_DIR/$(dirname "$rel")"; cp -a "$BACKUP/source/$rel" "$APP_DIR/$rel"; else rm -f "$APP_DIR/$rel"; fi; done; }
rollback(){ if [ "$COPIED" = 1 ] && [ -d "$BACKUP/runtime" ]; then echo "ROLLBACK: restoring pre-V24 runtime..."; cp -a "$BACKUP/runtime/index.cjs" "$SERVER"; cp -a "$BACKUP/runtime/index.html" "$INDEX"; cp -a "$BACKUP/runtime/index-DGJ45auth-v11.js" "$SPA"; if [ -f "$BACKUP/runtime/dgj-brand-lock.js" ]; then cp -a "$BACKUP/runtime/dgj-brand-lock.js" "$APP_DIR/dist/public/dgj-brand-lock.js"; else rm -f "$APP_DIR/dist/public/dgj-brand-lock.js"; fi; if [ -f "$BACKUP/runtime/brand-contract.json" ]; then cp -a "$BACKUP/runtime/brand-contract.json" "$APP_DIR/dist/public/brand-contract.json"; else rm -f "$APP_DIR/dist/public/brand-contract.json"; fi; if [ -f "$BACKUP/runtime/llms.txt" ]; then cp -a "$BACKUP/runtime/llms.txt" "$APP_DIR/dist/public/llms.txt"; else rm -f "$APP_DIR/dist/public/llms.txt"; fi; if [ -f "$BACKUP/runtime/dgj-google-jobs-v24.js" ]; then cp -a "$BACKUP/runtime/dgj-google-jobs-v24.js" "$APP_DIR/dist/public/dgj-google-jobs-v24.js"; else rm -f "$APP_DIR/dist/public/dgj-google-jobs-v24.js"; fi; pm2 reload devglobaljobs >/dev/null 2>&1 || true; sleep 3; fi; if [ "$SOURCE_PATCHED" = 1 ]; then echo "ROLLBACK: restoring pre-V24 source files..."; restore_source; fi; echo "ROLLBACK COMPLETE."; }
trap 'fail "unexpected deployment error"' ERR
[ "$(id -u)" = 0 ] || fail "Run as root."
for c in curl sha256sum node pm2 python3 grep cp mkdir install stat mv awk; do command -v "$c" >/dev/null 2>&1 || fail "Missing command: $c"; done
for f in "$SERVER" "$INDEX" "$SPA" "$GJS" "$GCS" "$APP_DIR/server/seoMeta.ts" "$APP_DIR/client/index.html" "$APP_DIR/package.json"; do [ -f "$f" ] || fail "Required live/source file missing: $f"; done

echo "============================================================"; echo "1/13 CURRENT LIVE HEALTH"; echo "============================================================"
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy."
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy."
echo "PASS: current website healthy."

echo; echo "============================================================"; echo "2/13 EXACT V19 COLLISION PROTECTION"; echo "============================================================"
[ "$(sha256sum "$SERVER"|awk '{print $1}')" = "96c833718aedcafa5b2d5cc777a24721731e86e155300c99e2bc79891329de79" ] || fail "Live index.cjs is not exact rolled-back V19 baseline."
[ "$(sha256sum "$INDEX"|awk '{print $1}')" = "120bd1d247779dab7c027f453bb7701f7a91b57d787ffba3033b82705fb35bfa" ] || fail "Live index.html is not exact V19 baseline."
[ "$(sha256sum "$SPA"|awk '{print $1}')" = "725d891d23a2567f0f880925d6080ea3633ded4ab67dac3178d6a33d7eebe42b" ] || fail "Live SPA is not exact V19 baseline."
[ "$(sha256sum "$GJS"|awk '{print $1}')" = "d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a" ] || fail "Growth JS changed unexpectedly."
[ "$(sha256sum "$GCS"|awk '{print $1}')" = "4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51" ] || fail "Growth CSS changed unexpectedly."
echo "PASS: exact safe runtime baseline confirmed."

echo; echo "============================================================"; echo "3/13 PACKAGE + CONTRACT VALIDATION"; echo "============================================================"
cd "$SELF_DIR"; sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || fail "Package checksum failure."
node -c dist/index.cjs >/dev/null || fail "V23 server syntax invalid."
node -c dist/public/dgj-brand-lock.js >/dev/null || fail "V23 client brand lock syntax invalid."
node -c dist/public/dgj-google-jobs-v24.js >/dev/null || fail "V24 Google Jobs client syntax invalid."
node --check source/script/patch-job-schema-client.mjs >/dev/null || fail "V24 postbuild patcher syntax invalid."
node --check source/script/verify-google-jobs-schema.mjs >/dev/null || fail "V24 schema verifier syntax invalid."
grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23' dist/index.cjs || fail "V23 server lock marker missing."
grep -Fq 'DGJ_AUTH_MOBILE_V19' dist/index.cjs || fail "V19 mobile auth not preserved."
grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23' dist/public/index.html || fail "V23 index lock marker missing."
grep -Fq 'DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V24' dist/index.cjs || fail "V24 server JobPosting marker missing."
grep -Fq '/dgj-google-jobs-v24.js' dist/public/index.html || fail "V24 Google Jobs loader missing."
! grep -Fq 'dgj-job-seo-engine' dist/public/index.html || fail "Legacy inline Job SEO engine remains."
! grep -Fq 'document.getElementById("job-jsonld")' dist/public/assets/index-DGJ45auth-v11.js || fail "Legacy React JobPosting generator remains."
[ "$(sha256sum brand-lock/brand-contract.json|awk '{print $1}')" = "e0001535d4fa89ceaf5c376e9dc3d1c43f2e8233044dccded67c110377239044" ] || fail "Brand contract SHA mismatch."
python3 - <<'PYC'
import json
c=json.load(open('brand-lock/brand-contract.json'))
assert c['brand']['primaryIdentity']=='International Careers Platform'
assert c['staticRoutes']['/jobs/all']['title']!=c['staticRoutes']['/jobs/international']['title']
assert c['staticRoutes']['/jobs/sponsored']['title'].startswith('Sponsored Jobs') and 'Featured' not in c['staticRoutes']['/jobs/sponsored']['title']
assert c['brand']['featuredRule']['hasSeparateSeoRoute'] is False
forbidden=['Jobs Jobs','Careers Careers','Opportunities Opportunities','EmploymentAgency',"World's #1 International Job Board",'#1 International Job Platform','International Job Board | UN, NGO, Remote & Global Careers']
for m in list(c['staticRoutes'].values())+list(c['privateRoutes'].values()):
    for bad in forbidden:
        assert bad not in m['title'] and bad not in m['description']
PYC
echo "PASS: one authoritative V23 brand contract validated."

echo; echo "============================================================"; echo "4/13 BACKUP RUNTIME + SOURCE FILES"; echo "============================================================"
mkdir -p "$BACKUP/runtime" "$BACKUP/source"; : > "$BACKUP/existed.txt"
cp -a "$SERVER" "$BACKUP/runtime/index.cjs"; cp -a "$INDEX" "$BACKUP/runtime/index.html"; cp -a "$SPA" "$BACKUP/runtime/index-DGJ45auth-v11.js"
for rel in dist/public/dgj-brand-lock.js dist/public/brand-contract.json dist/public/llms.txt dist/public/dgj-google-jobs-v24.js; do [ -f "$APP_DIR/$rel" ] && cp -a "$APP_DIR/$rel" "$BACKUP/runtime/$(basename "$rel")" || true; done
for rel in server/seoMeta.ts server/brandSeo.ts client/index.html client/public/dgj-brand-lock.js client/public/brand-contract.json client/public/llms.txt client/public/robots.txt script/verify-brand-lock.mjs script/sync-brand-contract.mjs client/public/dgj-google-jobs-v24.js script/patch-job-schema-client.mjs script/verify-google-jobs-schema.mjs package.json brand-lock/brand-contract.json brand-lock/BRAND-CONTRACT.sha256; do backup_one "$rel"; done
echo "Backup: $BACKUP"

echo; echo "============================================================"; echo "5/13 INSTALL SOURCE-OF-TRUTH BRAND LOCK"; echo "============================================================"
SOURCE_PATCHED=1
python3 "$SELF_DIR/source/script/apply-brand-lock-source.py" "$APP_DIR" || fail "Source brand-lock installer failed."
cd "$APP_DIR"; node script/verify-brand-lock.mjs || fail "Source brand-lock verification failed."
node script/verify-google-jobs-schema.mjs || fail "Source Google Jobs schema verification failed."
echo "PASS: source contract, server resolver, SPA resolver and build gate installed."

echo; echo "============================================================"; echo "6/13 ATOMIC V24 RUNTIME INSTALL"; echo "============================================================"
COPIED=1
for pair in "dist/index.cjs:$SERVER" "dist/public/index.html:$INDEX" "dist/public/assets/index-DGJ45auth-v11.js:$SPA" "dist/public/dgj-brand-lock.js:$APP_DIR/dist/public/dgj-brand-lock.js" "dist/public/brand-contract.json:$APP_DIR/dist/public/brand-contract.json" "dist/public/llms.txt:$APP_DIR/dist/public/llms.txt" "dist/public/dgj-google-jobs-v24.js:$APP_DIR/dist/public/dgj-google-jobs-v24.js"; do src="${pair%%:*}"; dst="${pair#*:}"; tmp="$dst.v23.${STAMP}.tmp"; install -m 0644 "$SELF_DIR/$src" "$tmp"; mv -f "$tmp" "$dst"; done
echo "PASS: current runtime now uses the same public brand contract."

echo; echo "============================================================"; echo "7/13 PM2 RELOAD + ORIGIN HEALTH"; echo "============================================================"
cd "$APP_DIR"; pm2 reload devglobaljobs; sleep 4
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "API unhealthy after V23 reload."
echo "PASS: PM2 and API healthy."

echo; echo "============================================================"; echo "8/13 CORE BRAND SEMANTICS CHECK"; echo "============================================================"
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYROUTES'
import json,html,re,subprocess,sys
c=json.load(open(sys.argv[1])); routes=['/','/jobs/all','/jobs/international','/jobs/sponsored','/jobs/un','/jobs/ngo','/jobs/remote','/jobs/technology','/jobs/healthcare','/jobs/business','/jobs/education','/jobs/engineering','/jobs/creative','/jobs/sales','/jobs/gig','/jobs/youth','/universities','/post-job','/developers','/about','/pricing','/visa-guide','/eligibility-checker','/volunteers','/tools/country-salary-calculator','/tools/resume-checker','/tools/interview-prep','/tools/ats-keywords','/tools/career-path','/blog']
for route in routes:
    b=subprocess.check_output(['curl','-fsS','-H','Host: devglobaljobs.com','http://127.0.0.1:8080'+route+'?v23=1'],text=True)
    mt=re.search(r'<title[^>]*>(.*?)</title>',b,re.I|re.S); title=html.unescape(mt.group(1).strip()) if mt else ''
    exp=c['staticRoutes'][route]['title']
    if title!=exp: raise SystemExit('%s: expected %r, got %r' % (route,exp,title))
    if any(x in title for x in ['Jobs Jobs','Careers Careers','Opportunities Opportunities']):raise SystemExit('%s: duplicate wording' % route)
print('PASS:',len(routes),'representative public routes match the contract')
PYROUTES

echo; echo "============================================================"; echo "9/13 COUNTRY + CITY + PRIVATE CHECK"; echo "============================================================"
UK="$(curl -fsS -H 'Host: devglobaljobs.com' http://127.0.0.1:8080/jobs/country/uk?v23=1)"; printf '%s' "$UK" | grep -Fq 'Jobs in United Kingdom | Career Opportunities | Dev Global Jobs' || fail "Country metadata mismatch."
CITY="$(curl -fsS -H 'Host: devglobaljobs.com' http://127.0.0.1:8080/jobs/city/dubai?v23=1)"; printf '%s' "$CITY" | grep -Fq 'Jobs in Dubai | Career Opportunities | Dev Global Jobs' || fail "City metadata mismatch."
curl -fsS -D /tmp/dgj-v23-signin.h -H 'Host: devglobaljobs.com' http://127.0.0.1:8080/sign-in?v23=1 -o /tmp/dgj-v23-signin.html || fail "Sign-in fetch failed."
grep -Eiq '^X-Robots-Tag: *noindex, *nofollow' /tmp/dgj-v23-signin.h || grep -Eiq 'content="noindex, ?nofollow"' /tmp/dgj-v23-signin.html || fail "Sign-in noindex missing."
grep -Fq 'DGJ_AUTH_MOBILE_V19' /tmp/dgj-v23-signin.html || fail "V19 mobile auth missing."
rm -f /tmp/dgj-v23-signin.h /tmp/dgj-v23-signin.html
echo "PASS: dynamic locations and private noindex verified."

echo; echo "============================================================"; echo "10/13 PUBLIC MACHINE-READABLE IDENTITY"; echo "============================================================"
curl -fsS https://devglobaljobs.com/brand-contract.json | grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23' || fail "Public brand contract not served."
curl -fsS https://devglobaljobs.com/llms.txt | grep -Fq 'International Careers Platform' || fail "Public llms.txt not served."
PUBLIC="$(curl -fsS -H 'Cache-Control: no-cache, no-store' 'https://devglobaljobs.com/?v23=1')"; printf '%s' "$PUBLIC" | grep -Fq 'Dev Global Jobs | International Jobs, Remote Work & Global Careers' || fail "Public homepage title mismatch."
printf '%s' "$PUBLIC" | grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V23' || fail "Public V23 lock marker missing."
echo "PASS: public brand contract, llms.txt and homepage marker served."

echo; echo "============================================================"; echo "11/13 SOURCE + RUNTIME GATE CHECK"; echo "============================================================"
cd "$APP_DIR"; node script/verify-brand-lock.mjs --dist || fail "Source/runtime brand gate failed."
grep -Fq 'sync-brand-contract.mjs' package.json || fail "prebuild sync missing."
grep -Fq 'verify-brand-lock.mjs --dist' package.json || fail "postbuild gate missing."
echo "PASS: future normal source builds are guarded by contract sync + postbuild verification."


echo; echo "============================================================"; echo "12/13 GOOGLE JOBS STRUCTURED DATA CHECK"; echo "============================================================"
cd "$APP_DIR"; node script/verify-google-jobs-schema.mjs --dist || fail "Google Jobs source/runtime gate failed."
SAMPLE_JSON="$(curl -fsS --max-time 20 'http://127.0.0.1:8080/api/jobs/all?limit=60&offset=0')" || fail "Could not fetch jobs sample."
SAMPLE_ID="$(printf '%s' "$SAMPLE_JSON" | python3 -c 'import json,sys,datetime; d=json.load(sys.stdin); jobs=d.get("jobs",[]) if isinstance(d,dict) else d; now=datetime.datetime.now(datetime.timezone.utc);
for j in jobs:
 p=j.get("postedAt"); desc=j.get("description"); org=j.get("organization"); title=j.get("title"); country=j.get("country"); loc=(j.get("location") or "").lower(); remote=(j.get("category")=="remote" or any(x in loc for x in ["remote","anywhere","worldwide","virtual","telecommute"]));
 if title and org and desc and p and country:
  print(j.get("id")); break')"
[ -n "$SAMPLE_ID" ] || fail "No complete active sample job found for schema smoke test."
JOB_HTML="$(curl -fsS --max-time 20 -H 'Host: devglobaljobs.com' "http://127.0.0.1:8080/jobs/detail/${SAMPLE_ID}?v24=1")" || fail "Sample job page fetch failed."
printf '%s' "$JOB_HTML" | grep -Fq 'id="dgj-jobposting-v24"' || fail "Server JobPosting V24 schema missing on complete sample job."
printf '%s' "$JOB_HTML" | grep -Fq '"@type":"JobPosting"' || fail "JobPosting JSON-LD type missing."
printf '%s' "$JOB_HTML" | grep -Fq '"datePosted"' || fail "Required datePosted missing."
printf '%s' "$JOB_HTML" | grep -Fq '"hiringOrganization"' || fail "Required hiringOrganization missing."
printf '%s' "$JOB_HTML" | grep -Fq '"addressCountry"' || printf '%s' "$JOB_HTML" | grep -Fq '"applicantLocationRequirements"' || fail "Job location eligibility missing."
COUNT="$(printf '%s' "$JOB_HTML" | grep -o '"@type":"JobPosting"' | wc -l | tr -d ' ')"
[ "$COUNT" = "1" ] || fail "Expected one server JobPosting schema, found $COUNT."
echo "PASS: one factual server-rendered JobPosting schema verified on job ID $SAMPLE_ID."

echo; echo "============================================================"; echo "13/13 FINAL PRESERVATION + SAVE"; echo "============================================================"
[ "$(sha256sum "$GJS"|awk '{print $1}')" = "d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a" ] || fail "Growth JS changed unexpectedly."
[ "$(sha256sum "$GCS"|awk '{print $1}')" = "4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51" ] || fail "Growth CSS changed unexpectedly."
curl -fsS https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy."
pm2 save >/dev/null
COPIED=0; SOURCE_PATCHED=0; trap - ERR

echo; echo "============================================================"; echo "SUCCESS: PERMANENT BRAND + GOOGLE JOBS SCHEMA LOCK V24 IS LIVE"; echo "============================================================"
echo "  ✓ One authoritative brand-contract.json controls server + SPA metadata"
echo "  ✓ International Careers Platform is the locked overall identity"
echo "  ✓ All Jobs / International Jobs / Sponsored Jobs remain distinct"
echo "  ✓ Featured remains placement/status only, no standalone SEO route"
echo "  ✓ Categories, industries, countries, cities, tools and resources covered"
echo "  ✓ UN and NGO remain specialist categories only"
echo "  ✓ Organization + WebSite schema aligned; EmploymentAgency removed"
echo "  ✓ One authoritative Google JobPosting contract on individual job pages
  ✓ Full factual description + original datePosted + real employer name
  ✓ Physical jobs require addressCountry; remote jobs require applicant country
  ✓ No fake Worldwide country or synthetic 30-day validThrough
  ✓ Employer salary markup only when currency/pay period are explicit
  ✓ Legacy duplicate React/inline JobPosting generators disabled"
echo "  ✓ Unknown/private routes noindex"
echo "  ✓ llms.txt + public brand contract served"
echo "  ✓ npm prebuild sync + postbuild brand + Google Jobs gates installed in source"
echo "  ✓ V19 mobile auth and existing production features preserved"
echo "  ✓ Database untouched; no npm build; no drizzle-kit push"
echo "Rollback backup: $BACKUP"
echo "============================================================"
