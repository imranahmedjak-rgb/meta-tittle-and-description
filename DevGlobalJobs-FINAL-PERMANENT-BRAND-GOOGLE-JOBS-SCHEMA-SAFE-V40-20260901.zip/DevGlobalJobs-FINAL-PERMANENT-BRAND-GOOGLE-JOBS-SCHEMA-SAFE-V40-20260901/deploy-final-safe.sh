#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/var/www/devglobaljobs}"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/devglobaljobs-brand-googlejobs-v40-${STAMP}"
SERVER="$APP_DIR/dist/index.cjs"
INDEX="$APP_DIR/dist/public/index.html"
SPA="$APP_DIR/dist/public/assets/index-DGJ45auth-v11.js"
GJS="$APP_DIR/dist/public/assets/growth-suite.js"
GCS="$APP_DIR/dist/public/assets/growth-suite.css"
SUCCESS=0
MUTATED=0
BASELINE=""

fail(){
  echo
  echo "============================================================"
  echo "SAFE STOP: $*"
  echo "NOTHING WILL BE FORCED."
  echo "============================================================"
  exit 1
}

restore_rel(){
  local rel="$1"
  if grep -Fxq "$rel" "$BACKUP/existed.txt" 2>/dev/null; then
    mkdir -p "$(dirname "$APP_DIR/$rel")"
    cp -a "$BACKUP/files/$rel" "$APP_DIR/$rel"
  else
    rm -f "$APP_DIR/$rel"
  fi
}

rollback(){
  set +e
  if [ "$MUTATED" = "1" ] && [ -d "$BACKUP" ]; then
    echo
    echo "ROLLBACK: restoring the exact pre-V39 files..."
    while IFS= read -r rel; do
      [ -n "$rel" ] && restore_rel "$rel"
    done < "$BACKUP/touched.txt"
    pm2 reload devglobaljobs --update-env >/dev/null 2>&1 || true
    echo "ROLLBACK COMPLETE."
  fi
}

on_exit(){
  local rc=$?
  trap - EXIT
  if [ "$SUCCESS" != "1" ]; then rollback; fi
  exit "$rc"
}
trap on_exit EXIT

echo "============================================================"
echo "DEV GLOBAL JOBS"
echo "FINAL PERMANENT BRAND + GOOGLE JOBS SCHEMA SAFE V40"
echo "============================================================"

[ "$(id -u)" = "0" ] || fail "Run as root."
[ -d "$APP_DIR" ] || fail "$APP_DIR missing."
[ -f "$APP_DIR/.env" ] || fail "Production .env missing."
for x in curl python3 sha256sum node pm2 grep awk sed cp mkdir mv; do command -v "$x" >/dev/null || fail "Missing command: $x"; done

echo; echo "1/14 CURRENT PRODUCTION HEALTH"
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "Local API unhealthy."
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy."
echo "PASS: current production website healthy."

echo; echo "2/14 EXACT BASELINE DETECTION"
sha(){ sha256sum "$1" | awk '{print $1}'; }
for f in "$SERVER" "$INDEX" "$SPA" "$GJS" "$GCS"; do [ -f "$f" ] || fail "Baseline file missing: $f"; done
SERVER_SHA="$(sha "$SERVER")"; INDEX_SHA="$(sha "$INDEX")"; SPA_SHA="$(sha "$SPA")"; GJS_SHA="$(sha "$GJS")"; GCS_SHA="$(sha "$GCS")"
if [ "$SERVER_SHA" = "96c833718aedcafa5b2d5cc777a24721731e86e155300c99e2bc79891329de79" ] && \
   [ "$INDEX_SHA" = "120bd1d247779dab7c027f453bb7701f7a91b57d787ffba3033b82705fb35bfa" ] && \
   [ "$SPA_SHA" = "725d891d23a2567f0f880925d6080ea3633ded4ab67dac3178d6a33d7eebe42b" ] && \
   [ "$GJS_SHA" = "d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a" ] && \
   [ "$GCS_SHA" = "4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51" ]; then
  BASELINE="V19"
elif [ "$SERVER_SHA" = "1caf0bd60abf77ea759471bd18499dba8dd6659c31d402c7cc054d7011a0c5c3" ] && \
     [ "$INDEX_SHA" = "68c46e06e31e1547d4fc353ce066ccc52af78dc1102d0ab00172b23265c55753" ] && \
     [ "$SPA_SHA" = "bff1f8835e3aeb1be5dea39db3169a0c6a4fa2ae497dabe7a6ff8aa16a2ea352" ] && \
     [ "$GJS_SHA" = "d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a" ] && \
     [ "$GCS_SHA" = "4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51" ]; then
  for rec in \
    "17660b5d7fc13b1dcce75fa653c7409d71aa89ae188572a31cac6b7a0e60d25a|dist/public/brand-contract.json" \
    "1923b10423a8072568d40c289f14f28677514ff6f045f4d2113149a0045e4143|dist/public/dgj-brand-contract-v27.js" \
    "8e32e015dedb7b87a5b84e85c1e5f42e432be6c89d7ef8074929d50aa3f5f422|dist/public/dgj-brand-lock.js" \
    "1b4034732ed22da830c9ba1994863ab8b10dc4d075f0ffcd52dfeedb678a410b|dist/public/dgj-google-jobs-v27.js"; do
      exp="${rec%%|*}"; rel="${rec#*|}"; [ -f "$APP_DIR/$rel" ] || fail "Partial V27 baseline missing $rel"; [ "$(sha "$APP_DIR/$rel")" = "$exp" ] || fail "Partial V27 baseline mismatch at $rel";
  done
  BASELINE="V27-PARTIAL-SAFE-STOP"
else
  fail "Live runtime is neither exact V19 nor the exact V27 partial baseline. Nothing changed. Server SHA: $SERVER_SHA"
fi
echo "PASS: exact recognized baseline = $BASELINE"

echo; echo "3/14 PACKAGE INTEGRITY + SYNTAX"
cd "$SELF_DIR"
sha256sum -c PAYLOAD-SHA256SUMS.txt >/dev/null || fail "Payload checksum mismatch."
[ "$(sha256sum brand-lock/brand-contract.json | awk '{print $1}')" = "00e06a8e7592a5aff18fcfa21492b43a2ad513c46a473d45f45367c7765295b4" ] || fail "Brand contract SHA mismatch."
node -c dist/index.cjs >/dev/null || fail "Server runtime syntax invalid."
node --check dist/public/dgj-brand-contract-v27.js >/dev/null || fail "Brand preload syntax invalid."
node --check dist/public/dgj-brand-lock.js >/dev/null || fail "Brand resolver syntax invalid."
node --check dist/public/dgj-google-jobs-v27.js >/dev/null || fail "Google Jobs client schema syntax invalid."
bash -n "$SELF_DIR/deploy-final-safe.sh" || fail "Deploy script syntax invalid."
python3 -m py_compile source/script/apply-brand-lock-source.py || fail "Source installer syntax invalid."
for f in source/script/*.mjs; do node --check "$f" >/dev/null || fail "Invalid source script: $f"; done
grep -Fq 'dgjJobApplicationContact' dist/index.cjs || fail "Package applicationContact helper missing."
grep -Fq 'schema.applicationContact=applicationContact' dist/index.cjs || fail "Package applicationContact server property missing."
grep -Fq 'if(validThrough)schema.validThrough=validThrough' dist/index.cjs || fail "Package conditional validThrough capability missing."
grep -Fq 'function applicationContact(j)' dist/public/dgj-google-jobs-v27.js || fail "Package applicationContact client helper missing."
grep -Fq 'jp.applicationContact=ac' dist/public/dgj-google-jobs-v27.js || fail "Package applicationContact client property missing."
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYCONTRACT' || fail "Contract quality audit failed."
import json,re,sys
c=json.load(open(sys.argv[1]))
assert c['lockId']=='DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27'
assert c['version']=='27.0.0'
assert len(c['staticRoutes'])==45, len(c['staticRoutes'])
assert len(c['privateRoutes'])==3, len(c['privateRoutes'])
assert len(c['countries'])==17, len(c['countries'])
assert len(c['cities'])==50, len(c['cities'])
assert len(c['blogArticles'])==32, len(c['blogArticles'])
assert c['cities']['washington-dc']=='Washington, DC'
assert c['cities']['abu-dhabi']=='Abu Dhabi'
seen={}
for route,m in {**c['staticRoutes'],**c['privateRoutes']}.items():
    t=m['title']; d=m['description']
    assert not re.search(r'\b(Jobs|Careers|Opportunities)\s+\1\b',t,re.I), (route,t)
    assert '—' not in t and '—' not in d
    if not str(m.get('robots',c['indexRobots'])).startswith('noindex'):
        assert t not in seen,(route,seen.get(t),t);seen[t]=route
assert c['staticRoutes']['/jobs/all']['title'] != c['staticRoutes']['/jobs/international']['title']
assert c['staticRoutes']['/jobs/sponsored']['title'].startswith('Sponsored Jobs')
assert 'Featured' not in c['staticRoutes']['/jobs/sponsored']['title']
print('PASS: 45 static + 17 countries + 50 cities + 32 blog metadata records validated')
PYCONTRACT
echo "PASS: V39 package integrity, syntax and contract quality verified."

echo; echo "4/14 BACKUP EVERY TOUCHED FILE"
mkdir -p "$BACKUP/files"; :>"$BACKUP/existed.txt"; :>"$BACKUP/touched.txt"
TOUCHED=(
'dist/index.cjs' 'dist/public/index.html' 'dist/public/assets/index-DGJ45auth-v11.js'
'dist/public/dgj-brand-contract-v27.js' 'dist/public/dgj-brand-lock.js' 'dist/public/dgj-google-jobs-v27.js' 'dist/public/brand-contract.json' 'dist/public/llms.txt'
'server/seoMeta.ts' 'server/brandSeo.ts' 'client/index.html' 'client/public/robots.txt' 'package.json'
'client/public/dgj-brand-contract-v27.js' 'client/public/dgj-brand-lock.js' 'client/public/dgj-google-jobs-v27.js' 'client/public/brand-contract.json' 'client/public/llms.txt'
'script/apply-brand-lock-source.py' 'script/patch-active-brand-meta.mjs' 'script/patch-job-schema-client.mjs' 'script/patch-runtime-brand-meta.mjs' 'script/sync-brand-contract.mjs' 'script/verify-brand-lock.mjs' 'script/verify-google-jobs-schema.mjs'
'brand-lock/brand-contract.json' 'brand-lock/BRAND-CONTRACT.sha256'
)
for rel in "${TOUCHED[@]}"; do
  echo "$rel" >> "$BACKUP/touched.txt"
  if [ -e "$APP_DIR/$rel" ]; then
    echo "$rel" >> "$BACKUP/existed.txt"
    mkdir -p "$BACKUP/files/$(dirname "$rel")"
    cp -a "$APP_DIR/$rel" "$BACKUP/files/$rel"
  fi
done
echo "Backup: $BACKUP"
MUTATED=1

echo; echo "5/14 INSTALL IDEMPOTENT SOURCE-OF-TRUTH LOCK"
cd "$APP_DIR"
python3 "$SELF_DIR/source/script/apply-brand-lock-source.py" "$APP_DIR" || fail "Source brand lock installer failed."
node script/verify-brand-lock.mjs || fail "Source brand verifier failed."
node script/verify-google-jobs-schema.mjs || fail "Source Google Jobs verifier failed."
# Run installer a second time as an idempotence test. It must not duplicate loaders or lifecycle gates.
python3 "$SELF_DIR/source/script/apply-brand-lock-source.py" "$APP_DIR" >/dev/null || fail "Source lock is not idempotent."
node script/verify-brand-lock.mjs || fail "Source lock failed after idempotence re-check."
node script/verify-google-jobs-schema.mjs || fail "Google Jobs source lock failed after idempotence re-check."
echo "PASS: permanent source/build gates installed and idempotent."

echo; echo "6/14 ATOMIC V39 RUNTIME INSTALL"
copy_atomic(){ local src="$1" dst="$2" tmp="${2}.v39tmp.$$"; mkdir -p "$(dirname "$dst")"; cp -a "$src" "$tmp"; mv -f "$tmp" "$dst"; }
copy_atomic "$SELF_DIR/dist/index.cjs" "$SERVER"
copy_atomic "$SELF_DIR/dist/public/index.html" "$INDEX"
copy_atomic "$SELF_DIR/dist/public/assets/index-DGJ45auth-v11.js" "$SPA"
for f in dgj-brand-contract-v27.js dgj-brand-lock.js dgj-google-jobs-v27.js brand-contract.json llms.txt; do copy_atomic "$SELF_DIR/dist/public/$f" "$APP_DIR/dist/public/$f"; done
node -c "$SERVER" >/dev/null || fail "Live server syntax invalid after atomic copy."
echo "PASS: reviewed runtime and SEO/schema assets installed atomically."

echo; echo "7/14 RELOAD ONLY MAIN APP + HEALTH"
pm2 reload devglobaljobs --update-env
sleep 2
PM2_DESC="$(pm2 describe devglobaljobs)"; grep -q 'online' <<<"$PM2_DESC" || fail "PM2 app not online."
curl -fsS --max-time 20 http://127.0.0.1:8080/api/jobs/stats >/dev/null || fail "API unhealthy after reload."
echo "PASS: PM2 and API healthy."

echo; echo "8/14 ALL LOCKED PUBLIC METADATA + NO LIST JOBPOSTING"
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYROUTES' || fail "Public route metadata audit failed."
from html.parser import HTMLParser
import html,json,re,subprocess,sys
c=json.load(open(sys.argv[1],encoding='utf-8')); base='http://127.0.0.1:8080'
class HeadAuditParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_title=False; self.title_parts=[]; self.description=''; self.canonical=''
    def handle_starttag(self,tag,attrs):
        tag=tag.lower(); a={str(k).lower(): (v or '') for k,v in attrs}
        if tag=='title': self.in_title=True
        elif tag=='meta' and a.get('name','').lower()=='description' and not self.description:
            self.description=a.get('content','').strip()
        elif tag=='link' and 'canonical' in a.get('rel','').lower().split() and not self.canonical:
            self.canonical=a.get('href','').strip()
    def handle_data(self,data):
        if self.in_title:self.title_parts.append(data)
    def handle_endtag(self,tag):
        if tag.lower()=='title':self.in_title=False
    def values(self):
        return html.unescape(''.join(self.title_parts).strip()),html.unescape(self.description),html.unescape(self.canonical)
def fetch(route):
    sep='&' if '?' in route else '?'
    return subprocess.check_output(['curl','-fsS','--max-time','20','-H','Host: devglobaljobs.com',base+route+sep+'v39=1'],text=True)
def parsedoc(body):
    p=HeadAuditParser();p.feed(body);return p.values()
def check(ok, route, field, actual='', expected=''):
    if ok:return
    print(f'ROUTE AUDIT FAIL: {route} :: {field}',file=sys.stderr)
    if actual!='':print('  actual  =',repr(actual),file=sys.stderr)
    if expected!='':print('  expected=',repr(expected),file=sys.stderr)
    raise SystemExit(1)
def has_jobposting(body):
    for raw in re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',body,re.I|re.S):
        try:v=json.loads(html.unescape(raw))
        except Exception:continue
        stack=[v]
        while stack:
            x=stack.pop()
            if isinstance(x,dict):
                t=x.get('@type')
                if t=='JobPosting' or (isinstance(t,list) and 'JobPosting' in t):return True
                stack.extend(x.values())
            elif isinstance(x,list):stack.extend(x)
    return False
# Regression test for the exact V28 false stop: apostrophes inside a double-quoted meta description must parse fully.
probe='<html><head><title>A &amp; B</title><meta name="description" content="Complete beginner\'s guide &amp; career advice."><link rel="canonical" href="https://devglobaljobs.com/probe"></head></html>'
pt,pd,pc=parsedoc(probe)
check(pt=='A & B','[parser-regression]','title',pt,'A & B')
check(pd=="Complete beginner's guide & career advice.",'[parser-regression]','description',pd,"Complete beginner's guide & career advice.")
check(pc=='https://devglobaljobs.com/probe','[parser-regression]','canonical',pc,'https://devglobaljobs.com/probe')
count=0
for route,exp in c['staticRoutes'].items():
    body=fetch(route); t,d,can=parsedoc(body)
    expected_can='https://devglobaljobs.com' if route=='/' else 'https://devglobaljobs.com'+route
    check(t==exp['title'],route,'title',t,exp['title'])
    check(d==exp['description'],route,'description',d,exp['description'])
    check(can==expected_can,route,'canonical',can,expected_can)
    check(not has_jobposting(body),route,'JobPosting must not exist on list/content page')
    count+=1
for slug,name in c['countries'].items():
    route='/jobs/country/'+slug;p=c['dynamicPatterns']['country'];body=fetch(route);t,d,can=parsedoc(body)
    et=p['title'].replace('{Country}',name);ed=p['description'].replace('{Country}',name);ec='https://devglobaljobs.com'+route
    check(t==et,route,'title',t,et);check(d==ed,route,'description',d,ed);check(can==ec,route,'canonical',can,ec);check(not has_jobposting(body),route,'JobPosting must not exist');count+=1
for slug,name in c['cities'].items():
    route='/jobs/city/'+slug;p=c['dynamicPatterns']['city'];body=fetch(route);t,d,can=parsedoc(body)
    et=p['title'].replace('{City}',name);ed=p['description'].replace('{City}',name);ec='https://devglobaljobs.com'+route
    check(t==et,route,'title',t,et);check(d==ed,route,'description',d,ed);check(can==ec,route,'canonical',can,ec);check(not has_jobposting(body),route,'JobPosting must not exist');count+=1
for slug,exp in c['blogArticles'].items():
    route='/blog/'+slug;body=fetch(route);t,d,can=parsedoc(body);ec='https://devglobaljobs.com'+route
    check(t==exp['title'],route,'title',t,exp['title']);check(d==exp['description'],route,'description',d,exp['description']);check(can==ec,route,'canonical',can,ec);check(not has_jobposting(body),route,'JobPosting must not exist');count+=1
print('PASS:',count,'indexed public landing/content routes checked; apostrophe-safe metadata parser; JobPosting absent from all non-job pages')
PYROUTES

echo; echo "9/14 PRIVATE NOINDEX + V19 MOBILE AUTH"
python3 - "$SELF_DIR/brand-lock/brand-contract.json" <<'PYPRIVATE' || fail "Private noindex audit failed."
import json,re,subprocess,sys
c=json.load(open(sys.argv[1]));base='http://127.0.0.1:8080'
for route in c['privateRoutes']:
 h=subprocess.run(['curl','-fsS','--max-time','20','-D','-','-H','Host: devglobaljobs.com',base+route+'?v39=1'],text=True,capture_output=True,check=True).stdout
 if not (re.search(r'X-Robots-Tag:\s*noindex,?\s*nofollow',h,re.I) or re.search(r'<meta\s+name=["\'](?:robots|googlebot)["\'][^>]+content=["\']noindex,?\s*nofollow',h,re.I)):
  raise SystemExit(f'{route} private noindex missing')
print('PASS:',len(c['privateRoutes']),'private routes noindex')
PYPRIVATE
curl -fsS --max-time 20 -H 'Host: devglobaljobs.com' http://127.0.0.1:8080/sign-in?v39=1 -o /tmp/dgj-v40-signin.html || fail "Sign-in fetch failed."
grep -Fq 'DGJ_AUTH_MOBILE_V19' /tmp/dgj-v40-signin.html || fail "V19 mobile auth marker missing."
rm -f /tmp/dgj-v40-signin.html
echo "PASS: private noindex and V19 mobile auth preserved."

echo; echo "10/14 PUBLIC BRAND + LLM IDENTITY"
BRAND_JSON="$(curl -fsS --max-time 20 https://devglobaljobs.com/brand-contract.json)"; grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27' <<<"$BRAND_JSON" || fail "Public brand contract missing."
BRAND_JS="$(curl -fsS --max-time 20 https://devglobaljobs.com/dgj-brand-contract-v27.js)"; grep -Fq 'DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27' <<<"$BRAND_JS" || fail "Public brand preload missing."
LLMS_TXT="$(curl -fsS --max-time 20 https://devglobaljobs.com/llms.txt)"; grep -Fq 'International Careers Platform' <<<"$LLMS_TXT" || fail "llms.txt identity missing."
echo "PASS: machine-readable International Careers identity served publicly."

echo; echo "11/14 GOOGLE JOBS SOURCE + ACTIVE-RUNTIME GATES"
cd "$APP_DIR"
node script/verify-brand-lock.mjs --dist || fail "Runtime brand gate failed."
node script/verify-google-jobs-schema.mjs --dist || fail "Runtime Google Jobs gate failed."
grep -Fq 'dgjEmployerSameAs' "$SERVER" || fail "Employer sameAs support missing from runtime."
grep -Fq 'hiringOrganization.sameAs' "$SERVER" || fail "Conditional hiringOrganization.sameAs behavior missing from runtime."
echo "PASS: conditional employer sameAs support is present without fabricating organization URLs."
echo "PASS: source, active SPA bundle and built Google Jobs architecture gates passed."

echo; echo "12/14 LIVE JOBPOSTING FACTUAL SAMPLE AUDIT"
curl -fsS --max-time 30 'http://127.0.0.1:8080/api/jobs/all?limit=100&offset=0' -o /tmp/dgj-v40-jobs.json || fail "Jobs API sample failed."
python3 - /tmp/dgj-v40-jobs.json <<'PYJOBS' || fail "Live JobPosting sample audit failed."
import datetime,html,json,re,subprocess,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
jobs=d.get('jobs',[]) if isinstance(d,dict) else d
bad={'worldwide','global','remote','anywhere','international',''}
def eligible(j):
    if not all(j.get(x) for x in ('id','title','organization','description','postedAt')): return False
    if not (j.get('url') or j.get('applyEmail') or j.get('isEmployerPosted')): return False
    c=str(j.get('country') or '').strip().lower()
    if c in bad: return False
    closing=j.get('closingDate')
    if closing:
      try:
        dt=datetime.datetime.fromisoformat(str(closing).replace('Z','+00:00'))
        if dt.tzinfo is None:dt=dt.replace(tzinfo=datetime.timezone.utc)
        if dt < datetime.datetime.now(datetime.timezone.utc):return False
      except Exception: pass
    return True
samples=[j for j in jobs if eligible(j)][:12]
if not samples: raise SystemExit('No complete active sample job available')
remote_seen=physical_seen=0
for j in samples:
    route=f"/jobs/detail/{j['id']}"
    h=subprocess.check_output(['curl','-fsS','--max-time','20','-H','Host: devglobaljobs.com','http://127.0.0.1:8080'+route+'?v39=1'],text=True)
    blocks=re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',h,re.I|re.S)
    postings=[]
    def walk(v):
      if isinstance(v,dict):
        t=v.get('@type')
        if t=='JobPosting' or (isinstance(t,list) and 'JobPosting' in t):postings.append(v)
        for x in v.values():walk(x)
      elif isinstance(v,list):
        for x in v:walk(x)
    for raw in blocks:
      try:walk(json.loads(raw))
      except Exception:pass
    assert len(postings)==1,(route,'JobPosting count',len(postings))
    s=postings[0]
    assert s.get('title')==str(j['title']).strip(),(route,'title mismatch')
    assert s.get('description') and len(re.sub('<[^>]+>',' ',s['description']).strip())>0,(route,'description')
    expected_date=datetime.datetime.fromisoformat(str(j['postedAt']).replace('Z','+00:00')).date().isoformat()
    assert s.get('datePosted')==expected_date,(route,'datePosted',s.get('datePosted'),expected_date)
    assert s.get('hiringOrganization',{}).get('name')==str(j['organization']).strip(),(route,'hiringOrganization')
    same=s.get('hiringOrganization',{}).get('sameAs')
    if same:
      from urllib.parse import urlparse
      u=urlparse(same); assert u.scheme in ('http','https') and u.netloc,(route,'sameAs URL')
      assert 'devglobaljobs.com' not in u.netloc.lower(),(route,'sameAs cannot be publisher URL')
      assert j.get('isEmployerPosted') is True,(route,'sameAs provenance')
    assert s.get('identifier',{}).get('value')==str(j.get('sourceId') or j['id']),(route,'identifier')
    assert s.get('url')=='https://devglobaljobs.com'+route,(route,'url')
    assert s.get('directApply') is False,(route,'directApply')
    assert j.get('url') or j.get('applyEmail') or j.get('isEmployerPosted'),(route,'application path')
    # applicationContact is supplementary Schema.org data, not a Google-required field.
    # Match the runtime helper exactly: only an absolute HTTP(S) URL can become
    # applicationContact.url. A relative/non-HTTP stored apply URL can still be a
    # usable visible page apply path, but must not make this audit falsely fail.
    from urllib.parse import urlsplit
    def absolute_http_url(raw):
      value=str(raw or '').strip()
      if not value:return None
      try:
        u=urlsplit(value)
      except Exception:
        return None
      if u.scheme.lower() not in ('http','https') or not u.netloc:return None
      return u
    def canonical_http_key(u):
      # WHATWG URL serialization drops default ports (https:443 / http:80).
      # Compare semantic URL identity rather than raw netloc text so the live
      # validator mirrors the browser/runtime without weakening host/path checks.
      try:
        host=(u.hostname or '').lower()
        port=u.port
      except Exception:
        return None
      if not host:return None
      scheme=u.scheme.lower()
      if (scheme=='https' and port==443) or (scheme=='http' and port==80):
        port=None
      authority=host if port is None else f'{host}:{port}'
      return (scheme,authority,u.path or '/',u.query,u.fragment)
    def valid_email(raw):
      return bool(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',str(raw or '').strip()))
    ac=s.get('applicationContact')
    raw_url=str(j.get('url') or '').strip()
    expected_url=absolute_http_url(raw_url)
    if expected_url:
      assert ac and ac.get('url'),(route,'applicationContact absolute URL missing')
      actual_url=absolute_http_url(ac.get('url'))
      assert actual_url,(route,'applicationContact URL invalid')
      expected_key=canonical_http_key(expected_url)
      actual_key=canonical_http_key(actual_url)
      assert expected_key and actual_key,(route,'applicationContact URL canonicalization failed')
      assert actual_key==expected_key,(route,'applicationContact URL mismatch',ac.get('url'),raw_url)
    if valid_email(j.get('applyEmail')):
      assert ac and ac.get('email')==str(j.get('applyEmail')).strip(),(route,'applicationContact email')
    if ac and ac.get('url'):
      assert absolute_http_url(ac.get('url')),(route,'applicationContact emitted non-HTTP URL')
    if s.get('jobLocationType')=='TELECOMMUTE':
      remote_seen+=1; assert s.get('applicantLocationRequirements',{}).get('name'),(route,'remote applicant location')
    else:
      physical_seen+=1; assert s.get('jobLocation',{}).get('address',{}).get('addressCountry'),(route,'physical addressCountry')
    closing_raw=j.get('closingDate')
    expected_valid=None
    if closing_raw:
      try:
        expected_valid=datetime.datetime.fromisoformat(str(closing_raw).replace('Z','+00:00')).date().isoformat()
      except Exception:
        expected_valid=None
    if expected_valid:
      assert s.get('validThrough')==expected_valid,(route,'validThrough',s.get('validThrough'),expected_valid)
    else:
      assert not s.get('validThrough'),(route,'synthetic validThrough',s.get('validThrough'))
    if s.get('baseSalary'):
      assert j.get('isEmployerPosted') and j.get('salary'),(route,'salary provenance')
print(f'PASS: {len(samples)} live eligible jobs validated; physical={physical_seen}, remote={remote_seen}; exactly one factual JobPosting each')
PYJOBS
rm -f /tmp/dgj-v40-jobs.json

echo; echo "13/14 CANONICAL SITEMAP + GOOGLE JOB URL COVERAGE"
# The fresh local Node origin is the source of truth immediately after PM2 reload.
# Public CDN XML may legitimately remain stale for its cache TTL. CDN propagation lag
# must not roll back an otherwise healthy origin deployment.
LOCAL_SM="$(curl -fsS --max-time 30 -H 'Host: devglobaljobs.com' http://127.0.0.1:8080/sitemap-index.xml)" || fail "Local canonical sitemap index unavailable."
PUBLIC_SM="$(curl -fsS --max-time 30 https://devglobaljobs.com/sitemap-index.xml)" || fail "Public canonical sitemap index unavailable."
grep -Fq '<sitemapindex' <<<"$LOCAL_SM" || fail "Local sitemap-index.xml is not a sitemap index."
grep -Fq '<sitemapindex' <<<"$PUBLIC_SM" || fail "Public sitemap-index.xml is not a sitemap index."

LOCAL_SM_FILE="/tmp/dgj-v40-sitemap-index-local.xml"
PUBLIC_SM_FILE="/tmp/dgj-v40-sitemap-index-public.xml"
printf '%s' "$LOCAL_SM" > "$LOCAL_SM_FILE"
printf '%s' "$PUBLIC_SM" > "$PUBLIC_SM_FILE"

python3 - "$LOCAL_SM_FILE" <<'PYSITEMAPLOCAL' || fail "Local canonical sitemap index structure/coverage invalid."
import re,sys
xml=open(sys.argv[1],encoding='utf-8').read()
locs=re.findall(r'<loc>\s*(https://devglobaljobs\.com/[^<]+)\s*</loc>',xml,re.I)
assert locs, 'no sitemap locations found'
required={
 'https://devglobaljobs.com/sitemap-pages.xml',
 'https://devglobaljobs.com/sitemap-jobs-latest.xml',
 'https://devglobaljobs.com/sitemap-jobs-uk.xml',
 'https://devglobaljobs.com/sitemap-jobs-us.xml',
 'https://devglobaljobs.com/sitemap-jobs-canada.xml',
 'https://devglobaljobs.com/sitemap-jobs-australia.xml',
 'https://devglobaljobs.com/sitemap-jobs-germany.xml',
 'https://devglobaljobs.com/sitemap-jobs-france.xml',
 'https://devglobaljobs.com/sitemap-jobs-india.xml',
 'https://devglobaljobs.com/sitemap-jobs-brazil.xml',
 'https://devglobaljobs.com/sitemap-jobs-south-africa.xml',
 'https://devglobaljobs.com/sitemap-jobs-netherlands.xml',
 'https://devglobaljobs.com/sitemap-jobs-poland.xml',
 'https://devglobaljobs.com/sitemap-jobs-italy.xml',
 'https://devglobaljobs.com/sitemap-jobs-belgium.xml',
 'https://devglobaljobs.com/sitemap-jobs-austria.xml',
 'https://devglobaljobs.com/sitemap-jobs-switzerland.xml',
 'https://devglobaljobs.com/sitemap-jobs-new-zealand.xml',
 'https://devglobaljobs.com/sitemap-jobs-singapore.xml',
}
missing=sorted(required-set(locs))
assert not missing, 'missing origin sitemap entries: '+', '.join(missing)
numbered=[u for u in locs if re.fullmatch(r'https://devglobaljobs\.com/sitemap-jobs-[1-9][0-9]*\.xml',u)]
assert numbered, 'numbered job sitemap missing'
print('PASS: fresh local origin contains full pages/latest/country/numbered sitemap architecture')
PYSITEMAPLOCAL

python3 - "$PUBLIC_SM_FILE" <<'PYSITEMAPPUBLIC' || fail "Public canonical sitemap index core structure invalid."
import re,sys
xml=open(sys.argv[1],encoding='utf-8').read()
locs=re.findall(r'<loc>\s*(https://devglobaljobs\.com/[^<]+)\s*</loc>',xml,re.I)
assert locs, 'no public sitemap locations found'
core={'https://devglobaljobs.com/sitemap-pages.xml','https://devglobaljobs.com/sitemap-jobs-latest.xml'}
missing_core=sorted(core-set(locs))
assert not missing_core, 'missing public core sitemap entries: '+', '.join(missing_core)
expected={'uk','us','canada','australia','germany','france','india','brazil','south-africa','netherlands','poland','italy','belgium','austria','switzerland','new-zealand','singapore'}
present={m.group(1) for u in locs if (m:=re.fullmatch(r'https://devglobaljobs\.com/sitemap-jobs-([a-z-]+)\.xml',u))}
missing=sorted(expected-present)
if missing:
    print('WARN: public sitemap-index CDN cache has not refreshed all country entries yet:', ', '.join(missing))
else:
    print('PASS: public sitemap-index already exposes all country sitemap entries')
PYSITEMAPPUBLIC

FIRST_NUMBERED="$(python3 - "$LOCAL_SM_FILE" <<'PYFIRST'
import re,sys
xml=open(sys.argv[1],encoding='utf-8').read()
locs=re.findall(r'<loc>\s*(https://devglobaljobs\.com/[^<]+)\s*</loc>',xml,re.I)
for u in locs:
    if re.fullmatch(r'https://devglobaljobs\.com/sitemap-jobs-[1-9][0-9]*\.xml',u):
        print(u);break
PYFIRST
)"
[ -n "$FIRST_NUMBERED" ] || fail "No numbered job sitemap extracted from fresh origin index."

PAGES_XML="$(curl -fsS --max-time 30 https://devglobaljobs.com/sitemap-pages.xml)" || fail "sitemap-pages.xml unavailable."
LATEST_XML="$(curl -fsS --max-time 30 https://devglobaljobs.com/sitemap-jobs-latest.xml)" || fail "sitemap-jobs-latest.xml unavailable."
COUNTRY_US_XML="$(curl -fsS --max-time 30 https://devglobaljobs.com/sitemap-jobs-us.xml)" || fail "sitemap-jobs-us.xml unavailable."
COUNTRY_UK_XML="$(curl -fsS --max-time 30 https://devglobaljobs.com/sitemap-jobs-uk.xml)" || fail "sitemap-jobs-uk.xml unavailable."
COUNTRY_CA_XML="$(curl -fsS --max-time 30 https://devglobaljobs.com/sitemap-jobs-canada.xml)" || fail "sitemap-jobs-canada.xml unavailable."
NUMBERED_XML="$(curl -fsS --max-time 30 "$FIRST_NUMBERED")" || fail "First declared numbered job sitemap unavailable."
for pair in PAGES_XML LATEST_XML COUNTRY_US_XML COUNTRY_UK_XML COUNTRY_CA_XML NUMBERED_XML; do
  value="${!pair}"
  grep -Fq '<urlset' <<<"$value" || fail "$pair is not a valid urlset sitemap."
done
DETAIL_TOTAL="$( { grep -Eo 'https://devglobaljobs.com/jobs/detail/[0-9]+' <<<"$LATEST_XML" || true; grep -Eo 'https://devglobaljobs.com/jobs/detail/[0-9]+' <<<"$NUMBERED_XML" || true; } | sort -u | wc -l | tr -d ' ')"
[ "$DETAIL_TOTAL" -gt 0 ] || fail "Representative job sitemaps expose zero canonical job-detail URLs."

LOCAL_ROBOTS="$(curl -fsS --max-time 20 -H 'Host: devglobaljobs.com' http://127.0.0.1:8080/robots.txt)" || fail "Local robots.txt unavailable."
PUBLIC_ROBOTS="$(curl -fsS --max-time 20 https://devglobaljobs.com/robots.txt)" || fail "Public robots.txt unavailable."
grep -Fq 'Sitemap: https://devglobaljobs.com/sitemap-index.xml' <<<"$LOCAL_ROBOTS" || fail "Fresh origin robots.txt does not advertise canonical sitemap-index.xml."
if ! grep -Fq 'Sitemap: https://devglobaljobs.com/sitemap-index.xml' <<<"$PUBLIC_ROBOTS"; then
  echo "WARN: public robots.txt appears CDN-cached; fresh origin robots.txt is correct."
fi
rm -f "$LOCAL_SM_FILE" "$PUBLIC_SM_FILE"
echo "PASS: origin sitemap architecture + public pages/latest/US/UK/Canada/numbered delivery + $DETAIL_TOTAL representative job-detail URLs verified."

echo; echo "14/14 PRESERVATION + SAVE"
[ "$(sha "$GJS")" = "d432da49d0c263a9e43a1d58947e4822ee8ce010959f49124c681903e969b44a" ] || fail "Growth JS changed unexpectedly."
[ "$(sha "$GCS")" = "4803199ca393beaa6c6a6796605651f8f3f16d9ed7768042b47f82d25add4a51" ] || fail "Growth CSS changed unexpectedly."
curl -fsS --max-time 20 https://devglobaljobs.com/ >/dev/null || fail "Public website unhealthy at final check."
pm2 save >/dev/null
SUCCESS=1
MUTATED=0
trap - EXIT

echo
echo "============================================================"
echo "SUCCESS: PERMANENT BRAND + GOOGLE JOBS SCHEMA SAFE V40 IS LIVE"
echo "============================================================"
echo "  ✓ Permanent International Careers source-of-truth brand contract"
echo "  ✓ 45 static routes + 17 countries + 50 cities + 32 article metadata checks"
echo "  ✓ All Jobs / International Jobs / Sponsored Jobs remain separate"
echo "  ✓ Featured remains placement/status only"
echo "  ✓ Google JobPosting only on eligible individual job-detail pages"
echo "  ✓ Required factual title, description, datePosted, employer and location guarded"
echo "  ✓ Jobs without a usable application path are suppressed from JobPosting markup"
echo "  ✓ V19 applicationContact capability preserved for real application URL/email"
echo "  ✓ hiringOrganization.sameAs preserved only when a factual employer-owned URL can be inferred safely"
echo "  ✓ Remote jobs require TELECOMMUTE + factual applicant country"
echo "  ✓ No fake Worldwide country, synthetic posting date or synthetic expiry"
echo "  ✓ Salary markup only from explicit employer-posted currency + pay period data"
echo "  ✓ Exactly one JobPosting checked on live eligible samples"
echo "  ✓ Job sitemap architecture preserved"
echo "  ✓ V19 mobile auth / OTP / application functionality preserved"
echo "  ✓ Database untouched; no npm build; no drizzle-kit push"
echo "Rollback backup: $BACKUP"
echo "============================================================"
